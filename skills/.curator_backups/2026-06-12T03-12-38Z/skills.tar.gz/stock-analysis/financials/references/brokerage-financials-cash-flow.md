# Brokerage / Fintech Cash-Flow Caveats for `!financials`

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` extraction/sector handling and defers to `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`, `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`, `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`, `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`. This file is not global MIDAS policy and must not override command `SKILL.md` or `OUTPUT.md`.

Use this reference when analyzing brokerage, market-maker-adjacent, crypto-platform, clearing, custody, or fintech companies where operating cash flow can be dominated by client/custody balance-sheet movements.

## Why this matters

For brokerages and custody-heavy fintechs, GAAP operating cash flow can swing because of:

- payables to users or customers
- segregated cash and securities required by regulation
- securities borrowed / securities loaned
- receivables from users, brokers, dealers, or clearing organizations
- deposits with clearing organizations
- credit-card receivable purchase / collection flows
- fractional-share obligations or similar pass-through liabilities

These items can make CFO and FCF look unusually strong or weak without matching recurring owner earnings.

## FCF handling

Default FCF remains filing cash flow unless a company-defined FCF metric is explicitly used and labeled.

For software-heavy fintechs, when both are disclosed, calculate a conservative filing-based FCF as:

```text
FCF = Net cash provided by operating activities
      - purchases of property, software, and equipment
      - capitalization of internally developed software
```

If only generic capex is available, use CFO minus capex and say capitalized software was not separately available.

## Output language

Compact mode should not overstate FCF quality. Use wording like:

```text
FCF is filing-based cash flow, not clean owner earnings, because operating cash flow is materially affected by brokerage/client balance-sheet movements.
```

In standard/full mode, identify the largest cash-flow swing items and separate reported cash flow from recurring earnings quality.

## Revenue / metric-quality checks for trading platforms

For brokerages, market-maker-adjacent trading platforms, crypto platforms, and order-routing businesses, do not stop at total revenue growth. Check whether the latest 10-K/10-Q discloses:

- revenue by activity type such as options, equities, crypto, event contracts, net interest, securities lending, subscriptions, or proxy/other revenue;
- market-maker, exchange, partner, payment-for-order-flow, routing, or liquidity-provider concentration as a percentage of total net revenue;
- whether routing / transaction-based revenue was identified as a critical audit matter or otherwise depends on complex internal data inputs;
- whether a headline growth driver is cyclical or activity-sensitive, such as crypto/options volume, event-contract adoption, margin balances, or rate-sensitive interest income;
- adjusted EBITDA or other non-GAAP metrics that exclude SBC while buybacks are being used to offset dilution.

When any of these are material, put the caveat in `## GAAP vs Non-GAAP / Metric Quality` or `## Source Limitations`, not only in a business-model section.

## Verification checklist

- Check the cash-flow statement for client/custody working-capital lines.
- Check the balance sheet for segregated cash, user payables, securities borrowed/loaned, and receivables from users/clearing organizations.
- Check revenue disaggregation and concentration tables for market-maker, exchange, routing, crypto, options, event-contract, net-interest, or partner concentration.
- Check the auditor critical audit matters for transaction-based revenue complexity when the company relies on routing/order-flow revenue.
- If the company has embedded credit-card, lending, or receivables-trust activity, separate corporate debt/revolver liquidity from trust or secured-facility borrowings; note whether creditors have recourse to the parent and whether the activity still creates scaling/credit-quality risk.
- If repurchases and SBC are material, show both rather than treating buybacks as fully offsetting dilution.
- Do not use brokerage FCF margin as a clean cross-sector comparison without caveats.
