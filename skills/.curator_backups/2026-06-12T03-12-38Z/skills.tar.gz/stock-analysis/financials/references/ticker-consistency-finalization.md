# Ticker Consistency Finalization

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` finalization when multiple tickers, context compaction, interruptions, or maintenance chatter may have left stale state. Defers to command `SKILL.md`, command `OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`.

Use this reference for `!financials` sessions where multiple tickers appear in the transcript, a prior run was interrupted, or context compaction/background handoff may have left stale state.

## Durable lesson

Before saving or sending the final Standard/Full output, verify that the requested ticker, resolved company, artifact path, report title, and saved-path confirmation all refer to the same current command.

## Required consistency checks

- Latest active user command ticker/company: from the current `!financials [ticker/company]` request, not earlier transcript residue.
- Resolved issuer: legal company name, ticker, exchange, and CIK should match the active command.
- Artifact path: `workspace/tickers/[normalized-active-ticker]/financials.md`.
- Report title: `# [ACTIVE TICKER] | [Resolved Company] Financial Analysis`.
- Saved-path line: exactly the active ticker path.
- No unrelated ticker strings appear in the final output except in valid comparative context that is explicitly labeled.

## Practical verification pattern

When the transcript or artifacts contain more than one ticker, run a lightweight final check before final response/save:

1. Extract the active ticker/company from the latest user command.
2. Inspect or programmatically search the drafted output/artifact for stale ticker symbols, company names, or paths from prior work.
3. Confirm mandatory Standard sections are present in order.
4. Confirm the saved artifact path matches the active ticker.
5. If any mismatch appears, do not send or save; regenerate the output for the active ticker only.

## Pitfalls

- Do not trust the most recently opened artifact or previous verification output as the active target. In compacted or interrupted sessions, a stale artifact can be verified successfully while still being for the wrong ticker.
- A successful artifact-format check is not a successful command check unless the artifact is for the active user-requested ticker and the active command type. Before the final user reply, compare the requested ticker/company and command (`!financials`) against the verified title, saved path, source base, section skeleton, and summary bullets. If they differ, the correct final response is not a completion summary; it is a hard stop and regeneration for the requested ticker.
- Cross-command contamination is a failure, not a partial success: if a `!financials` request is active, never finalize a `risk.md`, `research.md`, thesis memo, eval result, or artifact-maintenance summary as the user-facing answer, even if that artifact passes its own validation checks.

## Compaction / Handoff Edge Case

If a context-compaction message appears after a visible `!financials [ticker]` command, treat the latest real user command before the compaction note as the active target unless the user gives a newer ticker command after the compaction. If the compaction note says earlier turns are reference-only or says to answer only the message after the summary, obey that boundary and then re-identify the active command from real user text rather than tool state. Do not let tool outputs, partially completed research, downloaded filings, validation scripts, saved artifacts, or drafted artifacts for another ticker/command become the target.

Hard stop rule: if the active command ticker and the drafted output ticker differ at any point, stop before finalizing, discard the stale draft, and restart identity/source gathering for the active ticker. Do not “fix” only the saved-path line or title; regenerate the financial analysis from sources for the correct issuer.

## Active Command / Handoff Check

When a `!financials` command appears near context compaction, skill-library edits, regression patches, or other maintenance chatter, identify the latest real user command after any reference-only context block. Do not answer with a stale skill-patch summary or continue an unrelated artifact just because prior tool state exists.

Hard stop: if the draft response, source base, todo item, artifact path, report title, or saved-path line names a ticker different from the latest real `!financials` command target, restart the financials run for the active ticker from source discovery. Do not patch only the title or saved path.
