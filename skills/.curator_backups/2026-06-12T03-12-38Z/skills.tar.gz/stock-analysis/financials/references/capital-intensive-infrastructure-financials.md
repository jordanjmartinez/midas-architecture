# Capital-Intensive Infrastructure Financials Notes

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` extraction/sector handling and defers to `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`, `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`, `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`, `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`. This file is not global MIDAS policy and must not override command `SKILL.md` or `OUTPUT.md`.

Use this reference inside `!financials` for companies whose reported growth depends on heavy physical/digital infrastructure buildout: bitcoin miners, AI/HPC data-center operators, GPU cloud providers, colocation/power-capacity developers, and other capex-heavy pivots.

## Why this matters

These companies can show strong revenue growth, high direct gross margins, and rising operating cash flow while still being financially fragile because capex, depreciation, leases, convertible debt, asset impairments, and dilution dominate the real funding picture.

## Extraction checklist

Prioritize these filing-backed items in addition to the normal Standard/Full template:

1. Revenue mix and segment shift
   - Split legacy segment revenue from new infrastructure/cloud/data-center revenue when disclosed.
   - Show whether the growth segment is still small as a percent of total revenue.
   - For pivots, compare headline revenue growth to mix-adjusted reality.

2. Gross margin caveat
   - If cost of revenue excludes depreciation/amortization, label gross margin as direct-cost or segment gross margin.
   - State that it does not capture full infrastructure economics.

3. FCF and funding gap
   - Use filing-based FCF = CFO minus purchases of property, plant and equipment unless a company-specific definition is explicitly requested.
   - If FCF is negative across multiple periods, do not calculate FCF CAGR; describe the trend and funding gap.
   - Compare operating cash flow to capex to show whether growth is self-funding.

4. Balance-sheet leverage
   - Include cash and equivalents, total liabilities, stockholders’ equity, convertible notes, finance leases, and operating leases where material.
   - For GPU/cloud/data-center companies, finance leases may be economically important even if current maturities are manageable.
   - Useful calculated metric: simplified net obligations = convertible notes + finance leases - cash. Label as simplified, not official net debt.

5. Dilution and capital access
   - Track shares outstanding at latest filing date, weighted-average shares, ATM issuance, registered direct offerings, and new shelf/ATM capacity.
   - Include SBC as a percentage of revenue when SBC is material.

6. Contract visibility / RPO
   - Include RPO and deferred revenue when disclosed.
   - For staged infrastructure contracts, check whether future undelivered/unaccepted tranches are excluded from RPO.
   - Do not treat headline total contract value as revenue backlog unless the filing says it is included in RPO or otherwise enforceable/recognized.

7. Accounting-quality watchpoints
   - Flag fair-value gains/losses, capped calls, convertible-note accounting, debt conversion inducement expense, asset impairments, and useful-life changes.
   - If a strategic pivot displaces legacy assets, impairment is evidence of real transition cost.

## Suggested language

- `Direct gross margins look strong, but they exclude depreciation/amortization and do not prove full-cycle infrastructure economics.`
- `The key question is not whether the company can generate gross profit; it is whether growth can become self-funding after capex, leases, depreciation, financing costs, and dilution.`
- `Headline contract value should not be treated as RPO unless delivered/accepted tranches are included under the company’s revenue-recognition policy.`

## Artifact / final-response note

Full mode follows `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md` and the financials `OUTPUT.md` contract: Full mode means expanded report output. Do not replace a Full user-facing response with an executive summary, artifact receipt, or key-points summary. If the user wants a shorter output, use Compact mode.