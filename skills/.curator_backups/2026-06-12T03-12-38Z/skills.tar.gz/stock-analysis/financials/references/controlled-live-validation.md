# Controlled Live Validation for `!financials`

Use this reference when the user asks for limited live validation of `!financials` behavior without activating or permanently replacing artifacts.

## Purpose

Validate a live Standard/Compact/Full run against the command contract while preserving command status, eval lifecycle, watchlists, and pre-existing workspace artifacts.

## Controlled validation pattern

1. **Scope first**
   - Treat the run as validation, not activation.
   - Do not promote command status or mark eval cases Active.
   - Do not patch SKILL/OUTPUT/registry/eval files unless the user explicitly requests a cleanup stage.
   - Do not run adjacent commands (`!research`, `!thesis`, `!risk`, `!full`, `!gems`, `!track`, `!updates`).
   - Do not fetch live market data unless explicitly requested or required by the command contract; if used, as-of date it and keep it separate from filing evidence.

2. **Snapshot before the run**
   - Check whether the target canonical artifact exists:
     - Standard/Full: `workspace/tickers/[ticker]/financials.md`
     - Compact saved test: `workspace/tickers/[ticker]/financials.compact.md`
   - Record existence, size, mtime, and checksum.
   - Also checksum watchlists if the validation constraints mention them.

3. **Run only the requested mode**
   - Default `!financials [ticker]` must validate Standard mode only.
   - Do not exercise Compact or Full aliases during a Standard-only validation.
   - Retrieve only bounded live evidence needed for the mode: identity, latest relevant annual/interim filings, filing metadata, targeted financial tables, and metric inputs.
   - Avoid full filing dumps and endless retries.

4. **Write only after complete output**
   - Standard/Full may write the canonical artifact only after the report reaches complete final output.
   - Verify the saved-path line appears exactly once and is the final line.
   - Verify no legacy path such as `workspace/[ticker]/financials.md` was used.
   - If filing retrieval fails or output is incomplete, return Partial/Blocked and do not save `financials.md`.

5. **Verify the artifact**
   - Re-read or programmatically verify the written artifact for title, ticker, source base, section order, GAAP/non-GAAP language, guardrail absence, and saved-path line.
   - Validate the expected mode behavior and absence of adjacent-command drift.

6. **Restore workspace state unless approved to keep**
   - If the canonical artifact existed before validation, restore its original content after verification unless the user explicitly approves permanent replacement.
   - If the canonical artifact did not exist before validation, remove the test artifact after verification unless the user explicitly approves keeping it.
   - Restore mtime when the user specifically requested final workspace-state restoration; content checksum is the main correctness check, but mtime restoration prevents noisy dirty-state confusion.

7. **Post-run verification**
   - Confirm command status/eval status remained unchanged.
   - Confirm watchlists were unchanged if in scope.
   - Confirm no command files were patched.
   - When the worktree already has dirty command-maintenance files, record pre-run checksums for the scoped registry/SKILL/OUTPUT/eval files and compare them post-run; do not rely on `git status` alone to prove the validation did not patch them.
   - For Compact mode, explicitly verify no-write behavior: canonical `financials.md` checksum/content and mtime unchanged, no `financials.compact.md` created unless it existed before, and any pre-existing compact artifact checksum/mtime unchanged.
   - For Full or Standard controlled writes, verify the written artifact before restoration for title/ticker/source/path consistency, required section order, saved-path line exactly once/final, guardrail absence, and no legacy path. If the write tool warns about stale reads or external edits, treat it as a finalization-risk signal and re-verify the saved artifact before claiming pass.
   - Restore both original content and metadata when the user asks for final workspace-state restoration; content checksum is the main correctness check, but restoring mtime prevents noisy artifact-state diffs.
   - Run scoped `git diff --check` on files/artifacts involved in the validation.
   - Report pre/write/post artifact checksum, whether the test artifact was preserved or restored, and whether Stage advancement is safe.

## Reporting shape

Return a validation summary with:

- Result: Pass / Partial / Fail / Blocked
- Target and mode used
- Sources retrieved and latest filing metadata
- Section-order result
- Metric / GAAP / non-GAAP result
- Artifact write result and saved-path verification
- Workspace restoration/preservation result
- P0 failures, if any
- Whether the next validation stage is safe
- Confirmation no command files, watchlists, eval statuses, or adjacent commands changed
