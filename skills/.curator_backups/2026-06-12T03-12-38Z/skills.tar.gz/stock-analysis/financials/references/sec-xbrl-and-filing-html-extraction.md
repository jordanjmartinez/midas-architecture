# SEC XBRL + Filing HTML Extraction Notes for `!financials`

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` extraction/sector handling and defers to `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`, `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`, `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`, `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`. This file is not global MIDAS policy and must not override command `SKILL.md` or `OUTPUT.md`.

Use this reference when producing filing-backed financial reviews from SEC filings where standard financial statement facts are available but segment/revenue-mix detail is embedded in filing HTML.

## Durable workflow pattern

1. Resolve ticker to CIK using SEC `company_tickers.json`.
2. Use `data.sec.gov/submissions/CIK##########.json` to identify latest 10-K / 10-Q, filing dates, report periods, accessions, and primary documents.
3. Check for nearby amended filings (`10-K/A`, `10-Q/A`) and note their existence when relevant. Do not assume the original filing is final for amended items.
4. Pull SEC Company Facts / Inline XBRL for core GAAP totals:
   - `Revenues`
   - `NetIncomeLoss`
   - `IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest` when operating income is not available
   - `NetCashProvidedByUsedInOperatingActivities`
   - `CashAndCashEquivalentsAtCarryingValue`
   - `Assets`, `Liabilities`
   - `WeightedAverageNumberOfSharesOutstandingBasic`
   - `WeightedAverageNumberOfDilutedSharesOutstanding`
   - `ShareBasedCompensation`
   - buyback / repurchase concepts when available
5. Use filing HTML text extraction for tables not easily represented as common US-GAAP concepts:
   - revenue disaggregation by product/source
   - segment tables and product/service splits
   - subscription / professional-services mix, ARR, dollar-based net retention, RPO, deferred revenue, and region tables for software companies
   - backlog / remaining performance obligation tables and recognition timing
   - customer concentration / accounts receivable concentration tables
   - key operating metrics
   - credit facilities / liquidity footnotes
   - senior notes, convertible notes, conversions, capped calls, and debt extinguishment footnotes
   - stock-based compensation by function, buyback authorizations, subsequent repurchases, and post-period acquisition cash outflows
   - ATM/equity offering, forward-sale, share-count, warrant, and equity award footnotes
   - post-quarter financing filings when they materially alter liquidity/dilution capacity
   - earnings-release exhibits (`EX-99.1`) for sequential-quarter comparison, non-GAAP reconciliation tables, guidance/outlook tables, and recent business highlights; label outlook/guidance as forward-looking and do not treat it as realized performance
   - foreign private issuer 6-K exhibits: when the primary 6-K is only a cover page, fetch the SEC archive index and parse result exhibits such as `EX-99.1` press releases and `EX-99.2` MD&A / operating results for interim income statement, balance sheet, cash-flow, channel, region, product, and non-IFRS reconciliation tables
6. When SEC Company Facts has sparse or issuer-specific XBRL tags, do not stall on the API. Fall back to the latest filing HTML and extract targeted statement/footnote tables with filing date, accession, URL, and local line/table evidence. Capital-intensive/custom-tag issuers often disclose the useful financial story in inline tables even when standard facts are incomplete.
7. If a table parser dependency such as pandas is unavailable, do not stop or save a thin artifact. Use plain filing text extraction instead: fetch the SEC filing HTML, strip it with BeautifulSoup or similar, search for distinctive headings/phrases, and extract bounded snippets around the relevant tables. For SEC HTML tables, a reliable fallback is to iterate `<table>` tags with BeautifulSoup, flatten each row's `<td>/<th>` text, then keyword-filter tables for terms such as `Revenues`, `Cash flows`, `Debt`, `Deferred revenue`, `Weighted average`, `Share-based compensation`, and segment names. The durable lesson is the fallback pattern, not the missing dependency.
8. When fetching SEC JSON or HTML with custom `Accept-Encoding`, handle compressed responses explicitly before decoding. If raw bytes start with gzip magic bytes (`1f 8b`) or the response header says `Content-Encoding: gzip`, decompress with `gzip.decompress(raw)` before JSON parsing / text decoding. This prevents false source-acquisition failures caused by compressed SEC responses.
9. For software/subscription companies, explicitly bridge GAAP results to cash-flow quality:
   - compare revenue growth with ARR/RPO/deferred-revenue growth when disclosed
   - separate GAAP operating/net losses from CFO/FCF strength
   - calculate SBC as a percentage of revenue when SBC is material
   - caveat CFO/FCF when deferred revenue and subscription billing mechanics are a major source of cash conversion
   - treat repurchase authorization as dilution mitigation only after checking actual repurchase activity and share-count/SBC trends
9. Calculate only simple, explicitly labeled metrics:
   - revenue growth
   - gross margin when cost of revenue/gross profit is clearly disclosed
   - operating margin and net margin when operating loss/net loss are disclosed
   - segment gross margins when segment revenue and cost/gross profit are disclosed
   - expense ratio when useful
   - FCF = CFO minus property/software/equipment purchases minus capitalized internal software, if both are disclosed; if capex line is titled “purchases of property, equipment and software,” use that exact label and state the formula
   - net cash/liquidity = cash + marketable securities minus balance-sheet borrowings when useful
   - dilution = weighted-average shares YoY and/or period-end shares sequentially when equity issuance is material
8. Preserve period/source labels for every material number.

## Important pitfall: financial / brokerage platforms

For brokerages, fintech platforms, banks, insurers, and other balance-sheet businesses, do not treat CFO / FCF like industrial or software owner earnings without a caveat. User payables, segregated cash, securities borrowed/loaned, margin lending, credit-card receivables, and other balance-sheet flows can dominate reported CFO.

Preferred wording:

> FCF is mechanically positive/negative by CFO minus capex, but cash-flow quality is affected by brokerage balance-sheet mechanics and should not be read like simple owner earnings.

## Important pitfall: no standard gross margin

Some financial platforms report net revenues and operating expenses rather than cost of revenue / gross profit. If cost of revenue is not clearly disclosed, say gross margin is not meaningful rather than forcing a software-style gross margin.

## Important pitfall: growth funded by equity issuance

For unprofitable issuers using ATM programs, converts, forward sales, or repeated equity offerings, separate liquidity strength from internally generated financial strength. A large cash balance can be real and useful, but if it was created by equity issuance while CFO/FCF remain negative, the financial read should explicitly discuss dilution, share-count growth, and whether backlog/revenue conversion is reducing dependence on capital markets.

Checklist:

- Compare cash + marketable securities to debt / convertible notes.
- Show recent ATM proceeds and share issuance when disclosed.
- Check post-quarter prospectus supplements / 8-Ks for new ATM capacity.
- For small-cap/SPAC-origin issuers, also scan post-quarter 8-Ks for completed ATM sales, PIPEs, registered directs, warrant/earnout/triggering-event share issuances, and other non-cash common-stock issuances that materially change dilution after the latest 10-Q balance-sheet date.
- Calculate weighted-average share growth YoY and/or period-end share growth sequentially when material; when post-quarter issuances are disclosed, estimate them as a percentage of the latest period-end share count and label the timing mismatch.
- Frame strong liquidity as a positive while flagging equity-funded liquidity as a quality caveat.

## Important pitfall: amended annual filings may not amend financials

When a recent `10-K/A` exists, inspect the explanatory note before treating it as a financial-statement update. Many annual amendments are Part III / proxy-information amendments only and explicitly do not update the original Form 10-K financial statements. If so, cite the original 10-K for financial numbers and mention the 10-K/A only as a source limitation / governance-information update.

## Important pitfall: GAAP gross margin basis can differ between statements and earnings releases

For semiconductor, hardware, or acquisition-heavy issuers, the income-statement cost-of-revenue line may exclude amortization of acquired intangibles while an earnings-release GAAP gross-margin reconciliation includes that amortization in GAAP gross profit. Do not mix these bases silently. Label the statement-line gross margin separately from release-presented GAAP and non-GAAP gross margin, and use the reconciliation table when discussing adjusted gross margin quality.

## Important pitfall: earnings releases may update income statement / balance sheet but not cash flow

For issuers with a post-quarter Form 8-K / EX-99.1 that reports fiscal-year or quarterly results before the next 10-K/10-Q is filed, inspect which statements are actually included. If the release includes an income statement, balance sheet, non-GAAP reconciliations, or guidance but omits a full cash-flow statement, use the release for those disclosed items only and keep CFO/FCF calculations anchored to the latest filed cash-flow statement. State the timing mismatch clearly: revenue/margins/earnings may be updated through the release date, while CFO/FCF remain as of the latest filed 10-Q/10-K period. Do not infer full-year CFO or FCF from net income, cash-balance changes, or partial cash-flow lines.

## Important pitfall: anonymized customer concentration is still material

Some filings disclose concentration by `Customer A`, `Customer B`, distributor labels, or similar anonymized identifiers. Do not invent identities or imply the customers are known from the filing. Quantify concentration by disclosed labels, period, and percentage; then frame it as a collection/revenue-durability watchpoint, especially when accounts receivable rises quickly or a single customer/distributor exceeds 20% of revenue.

## Output discipline

- If a Form 10-K/A or 10-Q/A exists, either use the amended filing for affected claims or explicitly state that the amendment was only noted and not separately parsed.
- Do not include valuation unless market data was gathered with as-of dates.
- Do not save incomplete output as `financials.md`.
