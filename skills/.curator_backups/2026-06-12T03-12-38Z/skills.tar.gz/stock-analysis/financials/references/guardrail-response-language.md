# Guardrail Response Language for `!financials`

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` edge-case handling and defers to `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`, `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`, `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`, `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` as applicable. This file is not global MIDAS policy and must not override command `SKILL.md` or `OUTPUT.md`.

Use this reference when the user asks whether to buy, sell, hold, size, or requests a price target after a financials review.

## Core behavior

- Do not provide buy/sell/hold instructions.
- Do not provide price targets.
- Do not provide position sizing.
- Reframe the answer as financial-quality research and information-gap triage.
- Avoid wording that sounds like MIDAS is advising a personal investment decision.

## Preferred phrases

Use:

```text
What prevents the financials from being decisive by themselves:
```

Instead of:

```text
What stops me from calling...
```

Use:

```text
Best next research command:
```

Instead of:

```text
Best next diligence before any decision:
```

## Good response shape

```md
I can’t provide buy/sell/hold instructions, position sizing, or a price target. I can frame what the financials do and do not support as research evidence.

Financial-quality read-through:
- [What the filings support]
- [What remains uncertain]

What prevents the financials from being decisive by themselves:
- [Valuation not checked]
- [Durability / cyclicality / metric-quality caveat]
- [Business-model or risk item requiring another command]

Research conclusion:
- [Worth deeper research / not enough evidence / financially fragile], without recommendation language.

Best next research command: `[command]`
```

## Pitfalls

- Avoid personal-capital language such as “before any decision,” “I would buy,” “I would not buy,” or “this is/is not a buy.”
- Avoid implying that a strong financial snapshot alone is an investment decision.
- If valuation has not been checked, explicitly say the financials do not answer whether the market already prices in the improvement.
