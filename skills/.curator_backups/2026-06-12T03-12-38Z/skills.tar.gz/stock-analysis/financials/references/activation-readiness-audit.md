# !financials Activation Readiness Audit

Use this reference when the user asks for a read-only activation audit, pre-validation audit, Stage 0 review, or status-sync review for `!financials`.

## Read-only discipline

- Do not patch files during a Stage 0/read-only audit.
- Do not promote command status.
- Do not mark eval cases Active.
- Do not run live financials research or fetch filings.
- Do not create artifacts or modify `workspace/tickers/`.
- Do not modify watchlists or run adjacent MIDAS commands.

## Required audit passes

1. Confirm required files exist:
   - `docs/COMMAND_REGISTRY.md`
   - `skills/stock-analysis/financials/SKILL.md`
   - `skills/stock-analysis/financials/OUTPUT.md`
   - `evals/financials.eval.md`
   - `skills/stock-analysis/financials/references/`, if present
2. Compare registry row against `SKILL.md`, `OUTPUT.md`, and eval metadata:
   - command, aliases, category, status, paths, classification/scoring/metrics usage, artifact behavior.
3. Check `!commands` visible menu status only if the user asks for related status assumptions.
4. Check output-contract readiness:
   - Standard default for every ticker.
   - Compact/Full only on explicit mode tokens outside the ticker/company target.
   - Required Standard/Full section order.
   - No default compact-style output, valuation conclusion, PEG, price target, or Buy/Sell/Hold.
5. Check parser/mode edge cases:
   - `NOW` is a ticker, not a time/mode shorthand.
   - `DEEP` is a ticker unless a separate explicit Full token follows.
   - No ticker-specific parser exceptions.
6. Check metric discipline:
   - metrics required, FCF definition clear, non-GAAP labeled, no FCF CAGR across zero/negative FCF, stale market data not presented as current.
7. Check artifact behavior:
   - Standard/Full save to `workspace/tickers/[ticker]/financials.md` only after complete output.
   - Compact does not save/overwrite by default; explicit compact save uses `financials.compact.md`.
   - No legacy `workspace/[ticker]/financials.md`; no false save claims; state isolation prevents prior ticker contamination.
8. Check eval coverage and stale eval expectations.
9. Check guardrails and prompt-injection resistance.
10. Classify each finding as P0 blocker, non-critical cleanup, activation caveat, or no issue.

## Known high-value drift check

After output-contract updates, eval text can lag behind. Specifically verify that eval cases do not preserve stale `Best Next Command:` inline expectations if the current `OUTPUT.md`/`SKILL.md` contract requires:

```md
## Best Next Command

`!command TICKER` — Reason.
```

If eval cases still require Best Next Command to live inside another section or use inline `Best Next Command:` in Standard/Full mode, classify that as a P0 blocker before validation because correct current output could fail stale eval expectations.

When validating cleanup, scan all eval sections, not just the obvious regression case. Guardrail or boundary cases can preserve stale `Must Include` lines such as `` `Best Next Command:` when a next command is useful `` even after the main Standard-output regression is fixed. Anchor extraction on the specific eval case ID being checked, confirm the replacement line uses `` `## Best Next Command`, when a next command is useful `` for Standard/Full cases, and run a global stale-pattern scan for embedded-only or inline-only Best Next Command wording before declaring Stage 3 fixture validation safe.

## Stage 5 / activation-readiness specifics

When the user asks whether `!financials` is ready for a later status-only activation patch after staged validations:

- Keep the review read-only unless activation is explicitly requested.
- In addition to `SKILL.md`, `OUTPUT.md`, `evals/financials.eval.md`, and the registry row, inspect the visible `!commands` menu status in `skills/stock-analysis/commands/OUTPUT.md`; if activation is later approved, this visible menu line must be synced from Draft to Active.
- Search `evals/commands.eval.md` for `!financials`; patch it during activation only if stale expected menu/status metadata exists. Do not invent command lookup behavior or new eval cases for `!commands` unless needed for status consistency.
- Check whether `evals/financials.eval.md` has a Manual Eval Run Log. If staged fixture/live/artifact validations passed and activation is approved, add a concise run-log entry documenting those passes; do not edit run logs during read-only readiness review.
- Report the exact activation patch surface separately from current readiness: normally registry status, `SKILL.md` status, `OUTPUT.md` status, eval metadata/case statuses, financials Manual Eval Run Log, and `!commands` visible menu status.
- Do not treat pre-existing unrelated worktree diffs as activation blockers unless they touch the reviewed command’s behavior, artifacts, watchlists, or allowed status-sync files. Mention them as caveats only when useful.
- If `workspace/tickers/` and watchlists are unchanged, explicitly say so; do not inspect or mutate artifacts beyond diff/name checks.

## Reporting shape

Use a concise activation-audit report with:

1. Current status
2. Existing files
3. Missing files
4. Registry / metadata consistency
5. Output-contract readiness
6. Eval coverage strength
7. Runtime / parser risks
8. Artifact risks
9. Guardrail risks
10. Cleanup needed before validation
11. Recommended next stage
12. Whether Stage 1 cleanup is needed or Stage 2 validation can start directly
13. For Stage 5 activation-readiness reviews: activation verdict, blockers/caveats, exact files needing status updates, eval cases to mark Active, Manual Eval Run Log decision, and whether a status-only activation patch is safe

Do not run validation or patch cleanup unless the user explicitly requests the next stage.
