# Non-SEC Issuer Financials Workflow

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` edge-case handling and defers to `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`, `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`, `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`, `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` as applicable. This file is not global MIDAS policy and must not override command `SKILL.md` or `OUTPUT.md`.

Use when `!financials [ticker/company]` does not resolve to an SEC CIK or when the primary listing is outside the U.S. / OTC is a secondary line.

## Trigger examples

- Canadian TSXV / CSE / TSX issuers.
- OTC tickers that correspond to a foreign primary listing.
- Issuer financials are hosted on a company investor page, SEDAR+, exchange disclosure pages, or official PDFs rather than EDGAR HTML/XBRL.

## Workflow

1. **Resolve identity before analysis.** If SEC ticker lookup returns no match, search for the issuer name/ticker and identify legal name, primary exchange ticker, and any OTC ticker. State the normalization in the artifact, e.g. `User input ticker: DMG; normalized public ticker used: DMGI.V / DMGGF`.
2. **Prefer issuer / regulator sources.** Use the issuer financials page, SEDAR+ filing pages, exchange releases, annual reports, and interim reports. Company-hosted Google Drive PDFs are acceptable if linked from the official issuer site; cite both the issuer page and direct document URLs.
3. **Collect the latest annual + interim set.** For Canadian issuers, this often means audited annual financial statements + annual MD&A, plus latest interim financial statements + interim MD&A. Do not rely only on a press release when statements/MD&A are available.
4. **Extract targeted evidence.** Pull statement tables and MD&A sections for revenue drivers, BTC/commodity/production metrics, cash flow, liquidity, debt/collateral, share count, and subsequent events. Avoid dumping whole PDFs.
5. **If PDFs are not text-friendly, convert locally.** A durable pattern is downloading official PDFs and extracting text with any available PDF text extractor (`pypdf`, `PyPDF2`, `pdfplumber`, or another local parser). Treat extractor choice as interchangeable; do not encode a specific missing-package failure as a rule.
6. **Use market-data context carefully.** If the listing is non-U.S., use the primary listing for CAD/native-currency valuation when possible and label source/as-of. OTC quotes can be secondary context.
7. **Save under the normalized primary ticker.** Use the canonical artifact path `workspace/tickers/[normalized-lowercase-primary-ticker]/financials.md` when the primary ticker is clear. For DMG Blockchain, `DMGI.V` normalized to `dmgi`.

## Output notes

- Make non-SEC source limitations explicit: no SEC accession/XBRL; filings may be PDFs; line citations may be unavailable.
- Keep the same Standard `!financials` section skeleton. Non-SEC source friction does not justify compact output unless the user explicitly requested compact mode.
- In the Source Limitations section, distinguish official issuer/regulatory documents from market-data sources.

## Metric pitfalls

- For miners / commodity-linked issuers, separate reported revenue growth from production-unit trends and price effects.
- Flag one-time incentives, fair-value revaluation, and collateralized debt separately from operating profitability.
- If digital assets or inventory-like commodities dominate assets/liquidity, present cash-only liquidity as well as broader liquid-asset coverage.
