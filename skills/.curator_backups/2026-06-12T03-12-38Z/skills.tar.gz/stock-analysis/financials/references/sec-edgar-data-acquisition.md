# SEC EDGAR data acquisition notes for !financials

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` extraction/sector handling and defers to `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`, `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`, `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`, `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`. This file is not global MIDAS policy and must not override command `SKILL.md` or `OUTPUT.md`.

This command-local reference supports `!financials [TICKER]` source acquisition. It is not a cross-command source, metric, or artifact policy.

Defer to the global rules first:

- Source standards: `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`
- Metric standards: `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`
- Artifact standards: `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

## Company / filing discovery

For SEC filers:

1. Resolve ticker to legal company name, exchange, and SEC CIK.
2. Pull recent filing metadata from SEC submissions JSON when useful:
   - `https://data.sec.gov/submissions/CIK##########.json`
   - Use a clear SEC-compliant User-Agent. Do not include personal contact details in reusable examples.
3. Select the latest relevant annual and interim filing for the issuer type:
   - U.S. domestic issuers: latest Form `10-K` and Form `10-Q` unless a newer company filing, earnings release, or amendment supersedes the data for a specific claim.
   - Foreign private issuers: latest Form `20-F` for annual financials and the latest results-oriented Form `6-K` for interim financials. Do not assume the primary 6-K document contains the financial statements; inspect the filing index for exhibits such as `EX-99.1` press release and `EX-99.2` MD&A / operating results.
4. Record:
   - Form type
   - Filing date
   - Report date / period covered
   - Accession number
   - SEC archive index URL or source URL

SEC archive index URL pattern:

```text
https://www.sec.gov/Archives/edgar/data/[CIK_NO_LEADING_ZEROES]/[ACCESSION_NO_DASHES]/[ACCESSION]-index.html
```

For non-SEC filers, use the best primary-source equivalents under `rules/SOURCES.md`, such as annual reports, interim reports, exchange filings, regulatory filings, and official company financial disclosures.

## Targeted filing areas

Prioritize targeted extraction over full filing dumps. High-value areas for `!financials` include:

- Income statement / consolidated statements of operations: revenue, costs, operating income, net income, EPS.
- Balance sheet: cash, assets, liabilities, debt, equity, shares outstanding.
- Cash-flow statement: operating cash flow, capex, capitalized software, buybacks, dividends, debt issuance/repayment.
- Segment tables: segment revenue, segment profit/loss, geographic split, and segment margin where disclosed.
- MD&A financial drivers: revenue drivers, margin bridge, operating expense changes, liquidity narrative.
- Debt and liquidity notes: maturities, revolving facilities, covenants, going-concern language, restricted cash.
- Share-count and equity footnotes: dilution, RSUs/options, warrants, converts, ATM programs, offerings, repurchases.
- Non-GAAP reconciliations: adjusted EBITDA, adjusted EPS, company-defined FCF, organic revenue, adjusted margins.
- Accounting-quality areas: revenue recognition, critical estimates, impairments, internal controls, restatements, auditor changes.

## Citation handling

Use line citations when they are readily available and reliable.

If line citations are not available or would make the run unbounded, cite by filing/report name, filing date, report period, section/table, accession number, and URL when available.

Do not keep retrying line-number extraction indefinitely. A bounded source limitation is better than an incomplete or stalled report.

## Optional market-data context

Market data is optional for `!financials` and should be used only when the user asks for valuation context or when limited valuation context is clearly needed.

If market data is used:

- Preserve the source and as-of date.
- Pair market data with the latest reliable share-count, cash, and debt sources.
- State timing mismatches between current market data and lagging filing data.
- Do not use market data to create default cheap/expensive/reasonable conclusions.
- Do not include PEG as a default metric.

Lightweight market-data helpers such as public chart APIs may be used as context if accessible, but they are not primary proof for financial statement metrics and should not replace company filings or official market-data sources.

## Artifact pointer

Artifact behavior is defined globally and in the command contract:

- `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`
- `/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/SKILL.md`
- `/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/OUTPUT.md`

Canonical Standard/Full artifact path:

```text
/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/financials.md
```

Compact output is not saved by default. If explicitly saved, use:

```text
/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/financials.compact.md
```
