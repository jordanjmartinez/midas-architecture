---
name: financials
description: Use when the user invokes !financials [company name or ticker] to produce a filing-backed financial statement and metric-quality review.
version: 2.0.0
author: Midas / Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [stocks, equity-research, sec-filings, financial-analysis, metric-quality]
    related_skills: [research, thesis, risk, full]
---

# MIDAS Command Skill — !financials

## Command

`!financials`

## Registry Metadata

Command: `!financials`
Aliases: `None`
Category: `Financial Analysis`
Status: `Active`
Skill Path: `skills/stock-analysis/financials/SKILL.md`
Output Path: `skills/stock-analysis/financials/OUTPUT.md`
Eval File: `evals/financials.eval.md`
Uses Classification: `Optional`
Uses Scoring: `Optional`
Uses Metrics: `Required`
Writes Artifacts: `Yes`
Primary Global Rules: `GLOBAL.md, COMMAND_INTERFACE.md, SOURCES.md, MARKET_DATA.md, METRICS.md, OUTPUT.md, ARTIFACTS.md, CLASSIFICATIONS.md, SCORING.md`

## Purpose

`!financials` reviews a public company’s financial statements and metric quality. It helps the user understand revenue trends, margins, profitability, cash generation, balance-sheet strength, dilution, capital returns, GAAP/non-GAAP quality, segment financials, financial red flags, and the best next diligence command.

This command is a filing-backed financial-statement review, not a full business-model report, thesis, downside-only risk memo, full MIDAS packet, hidden-gem ranking, price target, or buy/sell recommendation.

---

## When To Use

Use this command when:

- The user invokes `!financials [company or ticker]`.
- The user asks for a company’s financial statements, margins, cash flow, FCF, balance sheet, debt, liquidity, dilution, capital returns, or metric quality.
- The user needs financial-statement diligence before `!thesis`, `!risk`, or `!full`.

Do not use this command when:

- The user wants a full business-model report. Use `!research`.
- The user wants bull/base/bear cases or a thesis debate. Use `!thesis`.
- The user wants a downside-only pressure test. Use `!risk`.
- The user wants a complete MIDAS packet. Use `!full`.
- The user wants hidden-gem discovery or ranking. Use `!gems`.
- The user asks for buy/sell/hold instructions, position sizing, or a price target. Reframe as financial-quality research.

---

## Inputs

### Required Inputs

- Company name or ticker.

### Optional Inputs

- Output mode: `compact`, `standard`, or `full`. Compact and Full modes require an explicit mode word or flag after the ticker/company input.
- Request to include limited valuation context.
- Request to classify or score the setup.
- Request to save compact output.
- Specific period, filing, segment, or metric focus.

### Input Clarification Rules

Ask for clarification only when missing or ambiguous identity would materially change the result. If a ticker or company name is ambiguous, resolve the legal company name, ticker, exchange, and SEC CIK where applicable; if multiple plausible matches remain, ask the user to clarify before analysis.

---

## Aliases

Command aliases: `None`

---

## Output Modes

- Inherits shared mode behavior from `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md`.
- Supported modes: Compact, Standard, Full.
- Default mode: Standard.
- Compact-only summary intent is valid: a request such as `!financials [ticker] summary` or `!financials [ticker] compact` should run Compact mode, not fail. Only Compact + Full tokens together are a mode conflict.
- Command-specific exceptions: None.

Short maintenance references:

- `references/ticker-consistency-finalization.md` — use only for stale-state risk from multiple tickers, context compaction, interruptions, or nearby maintenance chatter.
- `references/activation-readiness-audit.md` — use during read-only activation audits or pre-validation reviews to check registry/status consistency, output-contract drift, stale eval expectations, parser/mode risks, artifact rules, and guardrail coverage before promoting or validating the command. For read-only validation, avoid unrelated worktree caveats unless they block the command under review; verify actual eval heading IDs and exact contract text instead of relying on expected names; scan all eval sections for stale inline-vs-section formatting requirements, especially `Best Next Command` wording.
- `references/controlled-live-validation.md` — use when the user asks for constrained live validation without activation, especially when canonical artifacts may be temporarily written and then restored.

---

## Global Rules

This command must follow:

- `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`
- `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md`
- `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`
- `/home/jordan/.hermes/profiles/midas/rules/MARKET_DATA.md` only for optional market / valuation context
- `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`
- `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`
- `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

Use when applicable:

- `/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md`
- `/home/jordan/.hermes/profiles/midas/rules/SCORING.md`

Do not duplicate global rule content inside this command. Reference global rules instead.

---

## Workflow

Follow this command-specific workflow:

1. Parse the user request using `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md`; default mode is Standard unless an explicit mode token outside the ticker/company target requests Compact or Full.
2. Confirm the active requested ticker/company is the latest real user command target after any context-compaction or reference-only block; do not inherit ticker, artifact path, todo status, tool output, verification state, final-summary draft, or prior skill-maintenance summaries from interrupted/compacted runs. If the transcript contains recent skill-library edits, regression-patch chatter, stale tool/todo state for another ticker, or a saved-path/title mismatch, use `references/ticker-consistency-finalization.md` before drafting the user-facing response. If the immediately preceding work was command maintenance, eval/contract cleanup, artifact-format verification, or another non-report task, and the user says only `continue`, do not silently resume an older `!financials [ticker]` report; continue the visible active todo/maintenance thread when available, or ask a brief clarification if the intended continuation is materially ambiguous.
3. Resolve the company identity: legal company name, ticker, exchange, and SEC CIK where applicable. If no SEC CIK resolves or the issuer is primarily non-U.S./OTC-linked, use `references/non-sec-issuer-financials.md` before gathering documents.
3. Determine whether the command has enough input to proceed; clarify only if ambiguity remains material.
4. Gather source evidence using `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md` and the command-specific source needs below.
5. Identify the latest relevant annual and interim financial sources.
6. Record filing dates, report periods, accession numbers, URLs, and source identifiers.
7. Extract targeted financial evidence rather than dumping full filings.
8. Review revenue trends and disclosed drivers.
9. Review gross margin, operating margin, net margin, and profitability where meaningful.
10. Review operating cash flow and free cash flow; state the FCF definition used.
11. Review balance sheet, cash, debt, liquidity, solvency risk, maturities, and covenants where disclosed.
12. Review share count, dilution, buybacks, dividends, and whether capital returns appear covered by earnings or cash flow.
13. Review segment financials when disclosed.
14. Review GAAP vs non-GAAP metrics, reconciliations, changes in definitions, and metric quality.
15. Identify financial red flags/watchpoints separately from source, citation, missing-data, stale-data, and unavailable-metric limitations.
16. Include limited market / valuation context only if the user asks for valuation or current market context, explicit Full mode intentionally includes valuation/rerating context, or market cap / EV / liquidity is materially needed to frame financial scale. Interpret scale framing narrowly; do not use it to justify default market-data fetching in every Standard report. If market data is used, follow `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md` `Market-Data Display Rule` for chat display and `/home/jordan/.hermes/profiles/midas/rules/MARKET_DATA.md` for helper/source behavior. Call the canonical helper directly, keep the financial/valuation read-through first, show one compact provider/date line in chat, and preserve exact timestamp/timezone, provider limitations, unavailable fields, helper/tool detail if useful, and timing mismatch in the saved artifact when needed. Do not call or parse `!market` user-facing output text.
17. Apply Setup Classification only if the user asks or the output explicitly includes a final setup view.
18. Include the required Standard `## Financial Quality Score` as a concise financial-quality research score/grade when evidence supports it. This is not a full Global Research Score and must not become a recommendation; if evidence is insufficient, state the limitation inside that section.
19. Produce output using `/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/OUTPUT.md` and `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`. In normal/default mode, use the mandatory Standard template in `OUTPUT.md`; do not invent a ticker-specific abbreviated structure.
20. Save artifacts according to this command’s artifact behavior and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`.
21. Before saving or sending a Standard/Full output, run a ticker-consistency finalization check. The active user ticker/company, resolved issuer, report title, artifact path, saved-path line, and source base must all match. If multiple tickers appeared in the transcript or context was compacted/interrupted, use `references/ticker-consistency-finalization.md`. If any element does not match, hard stop and regenerate for the active ticker from sources; do not patch only the title/path.
22. If a best next command is useful, include it as `## Best Next Command` after `## Source Limitations` and before the final saved-path line. If `workspace/tickers/[ticker]/research.md` exists, prefer `!thesis [TICKER]` or `!risk [TICKER]` depending on the financial issues surfaced, and if no research artifact exists, suggest `!research [TICKER]`.

---

## Command-Specific Source Needs

Default source standards come from:

`/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`

Command-specific source needs:

- For SEC filers, prefer the latest Form 10-K and latest Form 10-Q.
- Use earnings releases, Form 8-Ks, investor presentations, transcripts, or company reconciliations when needed for current financial tables or non-GAAP reconciliation.
- For non-SEC filers, use annual reports, interim reports, exchange filings, regulatory filings, and official company financial disclosures.
- Use secondary sources only for context, not as primary proof of financial metrics.
- Use market data only if valuation/current market context is requested, explicit Full mode intentionally includes valuation/rerating context, or market cap / EV / liquidity is materially needed to frame financial scale. Interpret scale framing narrowly; do not use it to justify default market-data fetching in every Standard report.
- Do not show valuation multiples without provider/source, as-of context, source context, clean denominators, and any material timing mismatch between live market data and filing-derived inputs.
- Every material financial claim should be source-backed.
- Use line citations when available; otherwise cite filing name, filing date, period, section/table, accession number, or URL when available.

Optional command-local SEC workflow notes live at:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/references/sec-edgar-data-acquisition.md`

Additional extraction pattern for SEC Company Facts plus filing HTML revenue/footnote tables:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/references/sec-xbrl-and-filing-html-extraction.md`

Non-SEC issuer workflow for Canadian/foreign/OTC-linked names, official issuer PDFs, SEDAR+/exchange filings, and normalized primary-ticker artifacts lives at:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/references/non-sec-issuer-financials.md`

Brokerage / custody-heavy fintech cash-flow caveats live at:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/references/brokerage-financials-cash-flow.md`

Capital-intensive infrastructure financials notes for bitcoin miners, AI/HPC data-center operators, GPU cloud providers, and capex-heavy pivots live at:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/references/capital-intensive-infrastructure-financials.md`

Finalization checks for avoiding stale-ticker/artifact leakage across interrupted or compacted sessions live at:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/references/ticker-consistency-finalization.md`

---

## Market Data Usage

`!financials` remains filing-backed by default.

Market data is optional supporting context. Use it under:

`/home/jordan/.hermes/profiles/midas/rules/MARKET_DATA.md`

When market context is needed, call the canonical helper directly:

```bash
python3 /home/jordan/.hermes/profiles/midas/tools/market_data_snapshot.py [TICKER]
```

Do not call or parse `!market` user-facing output text.

Allowed uses:

- User asks for valuation or current market context.
- Explicit Full mode intentionally includes valuation/rerating context.
- Market cap, enterprise value, or liquidity is materially needed to frame financial scale. Interpret this narrowly; do not use it to justify default market-data fetching in every Standard report.

Default Standard mode:

- Do not include a live market-data block by default.
- Do not fetch live market data solely because the command is running Standard mode.
- Filing-backed financial-statement review must remain complete without live market data unless the user requested market context or a specific, material scale/valuation framing requires it.

Market data must not be used as evidence for:

- revenue;
- margins;
- profitability;
- cash flow;
- free cash flow;
- debt;
- dilution;
- balance-sheet strength;
- accounting quality;
- segment results;
- financial-statement conclusions;
- metric quality.

If market data is used in chat, label compactly under `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md` `Market-Data Display Rule`:

- provider/source;
- concise as-of date.

Preserve exact timestamp, timezone, limitations, unavailable fields, helper/tool detail if useful, and timing mismatch between live market data and filing-derived inputs in the saved artifact when needed.

Valuation multiples must follow `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`.

Do not produce:

- Buy/Sell/Hold language;
- price targets;
- position sizing;
- entry/exit guidance;
- trade advice;
- default PEG;
- unsupported cheap/expensive/reasonable/fair-value conclusions.

---

## Classification / Scoring / Metrics Behavior

### Setup Classification

Use Setup Classification: `Optional`

Rule:

`/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md`

Command-specific classification notes:

- Do not classify by default.
- Use Setup Classification only when the output includes a final setup view or the user explicitly asks for classification.
- Do not force classification into a raw financial statement review.

### Scoring

Use scoring: `Optional`

Rule:

`/home/jordan/.hermes/profiles/midas/rules/SCORING.md`

Command-specific scoring notes:

- Standard mode requires a concise `## Financial Quality Score` section as defined in `OUTPUT.md`; treat it as a financial-quality research prioritization score/grade, not as a full Global Research Score or recommendation.
- Score-line formatting is output-only: use `[existing score]/10 - [Assessment]`, preserving the generated score and assessment without hardcoding scores, adding a new rubric, or changing scoring logic.
- Do not add broader setup scoring, Global Research Score, overlays, or ranking by default.
- Use broader scoring only if the user asks for scoring or if the command explicitly produces a financial-quality setup view.
- If the user wants a full Global Research Score, suggest `!full`.

### Metrics

Use financial metrics: `Required`

Rule:

`/home/jordan/.hermes/profiles/midas/rules/METRICS.md`

Command-specific metric notes:

- Displayed metrics should preserve period, source, unit, and GAAP/non-GAAP status when relevant.
- If a metric is not meaningful, stale, unavailable, or not calculable, say so.
- Do not use undefined metrics.
- Define FCF as cash flow from operations minus capital expenditures unless using a company-specific FCF definition; label company-defined FCF clearly.
- For brokerage, clearing, custody-heavy fintech, or similar balance-sheet-intensive financial companies, check `references/brokerage-financials-cash-flow.md`; caveat reported CFO/FCF when client, segregated-cash, securities-borrowed/loaned, or user-payable movements dominate cash flow.
- For software-heavy fintechs where separately disclosed, subtract both purchases of property/software/equipment and capitalization of internally developed software from CFO for a conservative filing-based FCF view; if not separately available, state the limitation.
- Do not calculate FCF CAGR when FCF crosses zero, is negative, or is not meaningful; explain the trend instead.
- Label ROE and ROA denominator basis.
- Label interest coverage basis.
- Do not include PEG as a default metric.
- Do not include default cheap/expensive/reasonable/fair-value valuation language.
- Market-data-derived valuation metrics must follow `MARKET_DATA.md` and `METRICS.md`, and must remain separate from filing-backed financial-statement conclusions.

---

## Output Contract

Follow the command-specific output contract:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/financials/OUTPUT.md`

Follow shared output standards:

`/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`

### Required Sections in Standard Mode

Default Standard mode must use the mandatory Standard template in `OUTPUT.md` as the source of truth. The required section order is:

1. Report title: `# [TICKER] | [Company Name] Financial Analysis`
2. `## Introduction`
3. `## Filings / Sources Used`
4. `## Revenue / Growth`
5. `## Profitability / Margins`
6. `## Cash Flow`
7. `## Balance Sheet`
8. `## Share Count / Dilution`
9. `## GAAP vs Non-GAAP / Metric Quality`
10. `## Financial Quality Score`
11. `## Financial Red Flags / Watchpoints`
12. `## Source Limitations`
13. `## Best Next Command`, when useful
14. Final saved-path confirmation line: `Saved to: workspace/tickers/[ticker]/financials.md`

In normal Standard/Full outputs, the saved-path confirmation must appear exactly once and be the final line of the user-facing response. If a next command is included, use a separate `## Best Next Command` section after `## Source Limitations` and before the final saved-path line, then a blank line, then command-first body format: `` `!command TICKER` — Reason. `` Keep financial red flags/watchpoints inside `## Financial Red Flags / Watchpoints`, not buried in `## Source Limitations` by default.

Before finalizing Standard or Full `!financials` output:

- Confirm `## Filings / Sources Used` appears after `## Introduction`.
- Confirm source URLs, filing dates, periods, accessions, and exhibits are placed in `## Filings / Sources Used`, not inside a long Introduction source block.
- Confirm `## Financial Red Flags / Watchpoints` appears after `## Financial Quality Score` and before `## Source Limitations`.
- Confirm financial red flags are not buried inside Source Limitations by default.
- Confirm `## Source Limitations` contains evidence/source/citation/missing-data limitations, not the main red-flag list.
- Confirm `## Best Next Command`, when useful, appears after Source Limitations.
- Confirm every required heading is followed by a blank line before body text.
- Confirm Best Next Command, when included, uses `## Best Next Command`, then a blank line, then `` `!command TICKER` — Reason. ``
- Confirm the reason after the dash starts with a capital letter.
- Confirm Standard/Full does not use inline `Best Next Command:` inside `## Source Limitations`.
- Confirm the saved-path line appears exactly once and is the final line.
- Confirm Standard and Full still do not add live market data by default.
- Confirm Compact behavior remains unchanged.

No ticker may receive a custom abbreviated or compact-style structure unless compact mode is explicitly requested.

### Mode-Specific Output Shape

Mode-specific output shape remains in `skills/stock-analysis/financials/OUTPUT.md`. Mode routing inherits shared behavior from `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md` as specified in `## Output Modes` above.

Mode routing and mode-conflict behavior inherit from `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md`.
No command-specific Full/Compact conflict exception is defined for `!financials`.

For explicit Full mode, produce the expanded Full financial review in the user-facing final response and in the saved artifact. Do not return only a completion summary, artifact receipt, key-points summary, or “saved artifact includes” summary. Full mode must preserve the Standard financials skeleton and add deeper Full-mode financial analysis where useful.

---

## Artifact Behavior

This command writes artifacts: `Yes`

Follow:

`/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

### Creates / Replaces

- Standard and Full mode save by default to:
  - `/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/financials.md`
- Compact mode does not save by default.
- Compact mode should not show any user-facing artifact/save/no-save line by default.
- Omit compact artifact wording entirely unless the user explicitly asks to save compact output, asks whether compact output saved, artifact saving fails after being requested, or the command is running an artifact test.
- If the user explicitly asks to save compact output, save to:
  - `/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/financials.compact.md`
  - User-facing success line: `Saved to: workspace/tickers/[ticker]/financials.compact.md`
- If the user asks whether compact output saved and it did not, use: `No artifact saved.`

### Replace Behavior

- Standard and Full outputs replace the prior `financials.md` for the same normalized ticker unless the user explicitly asks to preserve versions.
- For validation-only runs where the user requests controlled artifact handling, use `references/controlled-live-validation.md`: snapshot the existing artifact first, write only after complete output, verify saved-path behavior, then restore/remove the test artifact unless the user approves keeping it.
- Before overwriting `workspace/tickers/[ticker]/financials.md` in an interrupted, compacted, or multi-agent session, read or otherwise verify the current target path enough to avoid stale/sibling-agent clobbering; after saving, re-read/verify title, ticker, required sections, score line, source base, and saved-path confirmation.
- If the target artifact was only read with pagination / partial view before overwrite, treat any write-tool warning as a stale-state signal: after saving, re-read or programmatically verify the full saved artifact before claiming completion. Do not rely on the partial pre-read as sufficient finalization evidence.
- If a write tool warns that the target artifact was modified by a sibling subagent or was never read by the current agent, treat that as a finalization risk: immediately verify the saved file before telling the user it was completed.
- Do not save incomplete output as `financials.md`.
- Do not use legacy workspace-root ticker paths.
- Do not claim an artifact was saved unless the write actually succeeded.

---

## Runtime / Work Budget Rule

`!financials` must be bounded.

- Default Standard mode should produce a complete but concise financial review using the mandatory Standard template in `OUTPUT.md`; it must not collapse into compact mode for any ticker, including `NOW`.
- Use targeted financial statements and notes rather than parsing entire filings when possible.
- For newly public or fiscal-year software companies, explicitly verify whether a newer 10-Q exists before assuming one; if the latest available realized results are a 10-K plus an earnings-release 8-K exhibit, say so and separate company guidance from filed results.
- Prioritize income statement, balance sheet, cash flow statement, segment tables, share-count footnotes, debt/liquidity footnotes, non-GAAP reconciliations, and MD&A financial drivers.
- Do not dump long filing excerpts.
- Do not attempt unlimited line-number extraction.
- Do not keep retrying SEC/source requests indefinitely.
- If line citations are slow or unavailable, use filing name, filing date, period, section/table, accession number, and URL.
- If data cannot be retrieved or calculated cleanly, return a bounded partial result with source limitations or fail cleanly.

---

## State Isolation Rule

Each `!financials` invocation must be isolated to the current requested company/ticker.

- Treat the latest active user command as authoritative for ticker/company identity; never let a previously verified artifact or previous ticker in the transcript override it.
- Do not include notes, partial progress, unresolved state, filing status, artifact status, or identity resolution from a previous interrupted run unless the user explicitly asks about that prior run.
- A saved artifact must contain only the final output for the current requested ticker/company.
- If current output contains unrelated prior-run text, do not save it as final.
- If the transcript includes multiple tickers or context compaction/handoff, explicitly verify title/path/saved line consistency before finalizing.

---

## Failure Behavior

If information is missing, weak, stale, or unavailable:

- Say what is missing.
- State the limitation clearly.
- Do not invent facts.
- Do not invent numbers.
- Do not force a metric or conclusion.
- Provide the best partial result when possible.
- Suggest the best next diligence step when useful.
- Do not save incomplete output as `financials.md`.

---

## Guardrails

This command must not:

- Use Buy/Hold/Sell recommendation language.
- Produce a price target.
- Present a full valuation model by default.
- Use default cheap/expensive/reasonable/fair-value valuation language.
- Use PEG by default.
- Treat non-GAAP metrics as GAAP.
- Present stale market data as current.
- Invent unavailable or unsupported metrics.
- Drift into `!research`, `!thesis`, `!risk`, `!full`, or `!gems`.
- Duplicate global rules inside this skill.

### Guardrail-Style Response Language

When the user asks whether to buy, sell, hold, size a position, or requests a price target after a `!financials` review:

- Reframe as financial-quality research only; do not advise a personal investment decision.
- State that `!financials` can assess financial quality, metric quality, and information gaps, but cannot provide buy/sell/hold instructions, position sizing, or price targets.
- Prefer `What prevents the financials from being decisive by themselves:` over personal-decision wording such as `What stops me from calling...`.
- Prefer `Best next research command:` over `Best next diligence before any decision:`.
- Keep the useful financial read-through, but make clear that financials alone are not a complete investment decision.

Detailed wording notes live at `references/guardrail-response-language.md`.

---

## Eval Cases Needed

Eval coverage lives in:

`/home/jordan/.hermes/profiles/midas/evals/financials.eval.md`

Required eval areas:

1. Normal success
2. Missing/weak source handling
3. No recommendation or price target
4. Registry metadata match
5. Compact output discipline
6. Full output without command drift
7. GAAP/non-GAAP labeling
8. FCF crossing zero / negative FCF handling
9. Stale market data handling
10. Artifact path and false-save prevention
11. Command boundary
12. Prompt-injection safety
13. Runtime boundedness
14. State isolation
15. Standard output contract regression, including default Standard mode for all tickers, required title, exact Standard section order, GAAP/non-GAAP section, Financial Quality Score, and saved-path confirmation
16. Full-mode delivery contract clarity: normal `!financials [ticker] full` replies must return the expanded financial report body in chat and save the complete expanded `financials.md` artifact; Full mode must not return only a completion summary, artifact receipt, key-points summary, or “saved artifact includes” summary.
17. Standard/Full formatting finalization, including OKTA/RBRK-style regressions: saved-path line appears exactly once as the final line, `## Best Next Command` uses command-first body format when included, heading/body spacing is clean, `## Filings / Sources Used` separates source detail from Introduction, `## Financial Red Flags / Watchpoints` separates red flags from Source Limitations, required Full sections remain in order, and buy/sell/hold language and price targets remain absent.

---

## Stability Checklist

Before this command is considered Active, confirm:

- Purpose is clear.
- Trigger syntax is clear.
- Required inputs are clear.
- Workflow is command-specific.
- Global rules are referenced, not duplicated.
- Output contract exists and matches this file.
- Artifact behavior follows `rules/ARTIFACTS.md`.
- Failure behavior is defined.
- Guardrails are included.
- Evals exist.
- Command registry metadata is filled in.
- `docs/COMMAND_REGISTRY.md` matches this metadata.
- The command does not conflict with other commands.

## Final Rule

`!financials` should make financial-statement diligence cleaner, faster, and more disciplined. It should surface metric quality, fragility, and information gaps without becoming a recommendation or a full research packet.
