# !gems Output Contract

## Purpose

`!gems` returns a concise hidden-gem candidate list. It is a discovery and prioritization command, not a full research report, recommendation, trading command, price-target command, or watchlist mutation command.

Use this file for command-specific presentation. Do not duplicate the full global rules here. Apply these shared standards by reference:

- `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md` for general MIDAS output style and market-data display.
- `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md` for source discipline.
- `/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md` for approved setup classifications and modifiers.
- `/home/jordan/.hermes/profiles/midas/rules/SCORING.md` for Hidden-Gem Overlay and Evidence Confidence behavior.
- `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` plus `rulebook/artifacts.md` for artifact and index behavior.
- `/home/jordan/.hermes/profiles/midas/rules/METRICS.md` when financial, valuation, market-cap, enterprise-value, liquidity, or price-performance metrics appear.

## Output Modes

### Broad Mode

Use for `!gems` with no theme. Return a concise general candidate list, normally up to 5 candidates, and save to the broad gems artifact path defined by `SKILL.md` / `rulebook/artifacts.md`.

### Theme Mode

Use for `!gems [theme]`. Return a concise candidate list for the normalized theme, normally up to 5 candidates, and save to the theme artifact path defined by `SKILL.md` / `rulebook/artifacts.md`.

### Theme/Subtheme Mode

Use for `!gems [theme] [subtheme]`. Return a concise candidate list for the normalized theme/subtheme, normally up to 5 candidates, and save to the theme/subtheme artifact path defined by `SKILL.md` / `rulebook/artifacts.md`.

### Deep Mode

Use for `!gems [theme] --deep` or `!gems [theme] [subtheme] --deep`. Return fewer, better-supported candidates, normally up to 3. Do not pad the list if only 1–2 clean candidates exist.

### No-Clean-Candidate Mode

Use when the screen produces no clean hidden-gem candidates. Do not force candidate picks when evidence is weak, setups are overextended, names are social-only, or primary-source validation is insufficient.

## Default Output

Use this shape for normal successful chat output. Keep it concise and Telegram-readable.

```md
# Hidden Gems | [Theme]

[Short summary of the scan result. State whether clean candidates surfaced, whether evidence is thin, or whether the theme appears overextended. Do not label this lead paragraph `Bottom Line`.]

## Candidate List

1. TICKER | Company Name

[One or two plain-English sentences explaining why it surfaced and what still needs verification. Use selective evidence only; do not make this a field dump.]

Setup: [classification] | Hidden-Gem Overlay: [score]/25 | Confidence: [A/B/C/D]

Main risk: [one sentence.]
Best next command: `!research TICKER`

## Screened Out / Watch-Only

[Optional short list when useful. Include only the ticker and concise reason.]

## Source / Evidence Note

[Compact note about source base and limitations.]

Saved to: workspace/gems/[actual-path].md
Updated index: workspace/gems/index.md
```

Do not force every section if it would add clutter. The candidate list, source/evidence note, and artifact confirmation should remain readable first.

Title and opening rules:

- Use `# Hidden Gems | [Theme]` as the visible chat title.
- Do not use `MIDAS Gems` as the visible report title.
- Use a pipe separator, not an em dash.
- Keep the theme Title Case when possible.
- Place the short lead paragraph directly under the title.
- Do not show a visible `Bottom Line` heading in `!gems` chat output.
- Keep the lead paragraph short; do not expand it into a full report.

## Candidate List Rules

- Show 1–5 candidates by default.
- In Deep Mode, show up to 3 candidates by default.
- Do not pad the list if fewer clean candidates exist.
- Rank by hidden-gem quality, not just business quality, theme exposure, market cap, market excitement, or recent stock momentum.
- Do not produce full company reports per candidate.
- Do not use overwide tables by default.
- Do not turn candidate cards into metric dumps, source dumps, or label-heavy field dumps.
- Keep detailed source notes, score breakdowns, screened-out reasoning, and full supporting detail in the saved artifact unless the user asks for more in chat.

## Concise Candidate Format

Preferred chat format:

```md
1. TICKER | Company Name

[One or two plain-English sentences explaining why it surfaced and what still needs verification.]

Setup: [classification] | Hidden-Gem Overlay: [score]/25 | Confidence: [A/B/C/D]

Main risk: [one sentence.]
Best next command: `!research TICKER`
```

Avoid default cards that repeatedly label every idea with fields such as `Category`, `Evidence`, `Why it matters`, `Monitor`, or `Thesis impact`. Use plain-English synthesis instead.

## Scoring Display

User-facing chat display should use:

```md
Hidden-Gem Overlay: [score]/25
```

or, when extra clarity is useful:

```md
Hidden-Gem Overlay Score: [score]/25
```

Do not use legacy score labels in user-facing chat output. The underlying scoring process remains governed by `rulebook/scoring.md` and `/home/jordan/.hermes/profiles/midas/rules/SCORING.md`.

Score display rules:

- Use `/25`; do not convert to percentages, `/10`, decimals, or star ratings.
- Include Evidence Confidence when a score is displayed.
- Apply score caps and downgrades when evidence is weak, social-only, promotional, overextended, fragile, or valuation support is missing.
- Do not present a score as a recommendation.
- Do not allow famous investor ownership, influencer attention, social hype, or market excitement to justify a high score by itself.
- Optional Global Research Score should not appear by default; include it only when explicitly justified by the command context and evidence base.

## Classification Display

Each ranked candidate should show a concise setup classification:

```md
Setup: [approved classification]
```

Use approved classifications and modifiers from `/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md`. Do not invent recommendation-like labels.

Acceptable display patterns include:

```md
Setup: Hidden-Gem Candidate
```

```md
Setup: Hidden-Gem Candidate; Early Rerating
```

```md
Setup: Watchlist / Awaiting Better Setup; Post-Rerate / Overextended
```

Use modifiers selectively. Do not overload the chat response with long modifier chains.

## Evidence Confidence Display

When a candidate is scored or ranked, show:

```md
Confidence: [A/B/C/D]
```

Use `/home/jordan/.hermes/profiles/midas/rules/SCORING.md` for Evidence Confidence definitions.

General display expectations:

- `A` or `B` requires meaningful primary-source or company-source support.
- `C` is appropriate for partial, mixed, incomplete, or inference-heavy evidence.
- `D` is appropriate for weak, stale, promotional, social-only, or mostly unverified evidence.
- Low confidence should cap or downgrade score and classification.
- Do not hide weak confidence behind exciting language.

## Source / Evidence Note Behavior

`!gems` may use discovery signals, but material candidate claims should be anchored in primary or company-source evidence when available.

Chat source/evidence notes should be compact. They should explain the evidence base and limitations without becoming a citation dump.

Preferred examples:

```md
Source / Evidence Note: Candidates were ranked from primary/company disclosures where available, with market and social/crowding signals treated as supporting context only.
```

```md
Source / Evidence Note: Evidence is incomplete for several names; social or promotional signals were not treated as thesis proof.
```

Rules:

- Social/crowding sources can help discovery, but must not prove the thesis.
- Promotional sources, influencer mentions, famous-investor ownership, or market excitement are not proof.
- Underdiscovered status should not be assumed without evidence.
- Market data, if displayed, must follow `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md` `Market-Data Display Rule`.
- Full source detail belongs in the saved artifact when needed for auditability.

## Rerating / Valuation Display

`!gems` should show rerating and valuation discipline without turning chat into a valuation report.

Use concise language such as:

- `pre-rerate`
- `early rerating`
- `post-rerate / overextended`
- `consolidating`
- `awaiting pullback`
- `valuation reset`
- `valuation support unverified`

A hidden gem should not be rewarded just because it already had a vertical move. If a candidate is post-rerate or overextended, the card should make that clear and the score/classification should reflect it.

If valuation support is not verified, say so plainly. Do not invent valuation support or imply a stock is cheap without evidence.

## Screened Out / Watch-Only

Use this section only when useful. Keep it short.

Preferred shape when company name is known:

```md
## Screened Out / Watch-Only

- TICKER | Company Name — Reason sentence.
```

Preferred shape when company name is not known:

```md
## Screened Out / Watch-Only

- TICKER | Reason sentence.
```

Rules:

- Use the pipe separator after the ticker.
- Prefer company name when known: `TICKER | Company Name — Reason`.
- If the company name is not known, use: `TICKER | Reason`.
- Do not insert `watch-only` after the pipe.
- Capitalize the first letter of the reason sentence after the pipe or em dash.
- Keep each screened-out / watch-only note one sentence.
- Do not include long mini-reports for screened-out names.
- Do not imply watch-only names were added to the watchlist.
- Do not use watch-only status as a buy/sell/hold signal.

## Artifact / Index Display

Preserve the current `!gems` artifact and index behavior from `SKILL.md`, `rulebook/artifacts.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`.

The user-facing reply should show these lines only if the actions actually happen:

```md
Saved to: workspace/gems/[actual-path].md
Updated index: workspace/gems/index.md
```

Rules:

- Do not claim a save unless the artifact was written.
- Do not claim an index update unless the index was updated.
- Use the actual canonical path written.
- Do not expose internal artifact plumbing unless needed to explain a save/update/failure condition.
- Do not imply watchlist mutation.
- Do not auto-add gems to the watchlist.
- Do not treat watchlist status as a buy/sell signal.

## Watchlist Boundary

`!gems` does not mutate the watchlist by default.

Allowed:

```md
Best next command: `!wl add TICKER`
```

only if the user explicitly asks for watchlist-oriented next steps or if it is clearly framed as an optional manual action.

Preferred default:

```md
Best next command: `!research TICKER`
```

Never say or imply that a candidate was added to `data/midas_watchlist.json` unless the user explicitly requested that separate action and it actually happened.

## Failure / No-Candidate Behavior

If the command cannot complete, use:

```md
Unable to complete: [specific issue]

Reason: [why the screen could not run or why required evidence was unavailable.]

Best next step: [adjust theme, broaden/narrow scan, or research a specific ticker.]
```

For no clean candidates, use:

```md
# Hidden Gems | [Theme]

No clean hidden-gem candidates surfaced under the current screen.

Why: [short explanation — weak evidence, overextended setups, social-only signals, insufficient primary-source validation, no clean information gap, or similar.]

Best next step: [adjust screen or run research on a specific ticker.]

Saved to: workspace/gems/[actual-path].md
Updated index: workspace/gems/index.md
```

Only show `Saved to:` and `Updated index:` if those actions actually happened.

Do not force candidate picks when evidence is weak.

## Best Next Command Behavior

Use command-first next steps.

Preferred default:

```md
Best next command: `!research TICKER`
```

Other next commands may be used only when they fit the candidate’s information gap:

- `!financials TICKER` for financial-statement quality or balance-sheet questions.
- `!risk TICKER` for risk-first diligence.
- `!thesis TICKER` only after enough evidence exists to frame a thesis.
- `!wl add TICKER` only as an optional manual action, not as an automatic command.

Do not run the next command unless the user explicitly asks.

## No-Recommendation Guardrails

`!gems` output must not:

- use Buy/Sell/Hold language
- provide price targets
- suggest position sizing
- give trade advice
- call candidates recommendations
- treat social media as proof
- treat a famous investor or influencer mention as proof
- treat market excitement as evidence
- produce full reports per candidate by default
- auto-add candidates to the watchlist
- imply watchlist status is a recommendation

Use language such as:

- `candidate`
- `research candidate`
- `watch-only candidate`
- `screened out`
- `worth deeper research`
- `best next diligence step`

Avoid language such as:

- `buy`
- `sell`
- `hold`
- `strong buy`
- `price target`
- `entry`
- `exit`
- `position size`
- `trade setup`
- `recommendation`

## Saved Artifact Expectations

The saved artifact can be more detailed than chat. It may include:

- candidate universe notes
- screened-out names
- source detail
- scoring rationale
- rerating / valuation notes
- duplicate/cross-theme handling
- detailed information gaps
- detailed risks
- index update context

The chat response should summarize the artifact, not paste it.

## Final Verification Before Replying

Before finalizing a `!gems` response, verify:

- The response is concise and candidate-oriented.
- The candidate list has 1–5 names by default, or fewer if fewer clean candidates exist.
- Deep Mode does not exceed the intended smaller candidate count.
- No full company reports appear in chat by default.
- Candidate scoring uses `Hidden-Gem Overlay` or `Hidden-Gem Overlay Score` in user-facing chat.
- Every scored candidate has Evidence Confidence.
- Setup classifications come from the approved global classification system.
- Rerating/valuation status is not ignored for overextended names.
- Social/crowding/promotion signals are not treated as thesis proof.
- Market data, if present, follows the global Market-Data Display Rule.
- `Saved to:` appears only if the artifact was actually written.
- `Updated index:` appears only if the index was actually updated.
- No watchlist mutation is implied.
- No Buy/Sell/Hold, price target, position sizing, trade advice, or recommendation framing appears.
