# `!gems` Readiness Audit Notes

Use this reference when the user asks for a read-only readiness audit or activation check for `!gems`.

## Read-only audit guard

For audit-only requests:

- Do not patch or modify files unless the user separately asks to update the skill library.
- Do not run a real `!gems` screen.
- Do not retrieve filings, prices, market data, SEC documents, or company data.
- Do not modify workspace artifacts or watchlist files.
- Inspect only `!gems` command files plus explicitly requested global rule sections.

## Activation readiness gates

Before saying `!gems` is ready to activate, verify:

1. `skills/stock-analysis/gems/SKILL.md` remains a concise controller / dispatcher.
2. Detailed screening, scoring, artifact, deep-mode, and maintenance logic remains in `rulebook/` or references; do not bloat `SKILL.md`.
3. `skills/stock-analysis/gems/OUTPUT.md` exists and defines:
   - output modes;
   - concise Telegram candidate-card format;
   - source/evidence notes;
   - Hidden-Gem Overlay Score display;
   - Setup Classification and Evidence Confidence display;
   - artifact/index confirmation lines;
   - watchlist boundary;
   - failure/no-clean-candidate behavior;
   - Best Next Command format.
4. `evals/gems.eval.md` exists and covers:
   - normal success;
   - compact candidate list;
   - weak evidence / social-hype-only cap or screen-out;
   - overextended/post-rerate cap;
   - no full report per candidate;
   - no Buy/Sell/Hold, price targets, position sizing, or trade advice;
   - no false artifact/index claims;
   - Best Next Command formatting;
   - registry metadata.
5. `docs/COMMAND_REGISTRY.md` `!gems` row points to files that exist before status is promoted.

If OUTPUT.md is missing, use readiness conclusion: `Needs OUTPUT.md first`.
If evals are missing but output contract exists, use: `Needs eval coverage first`.
Do not answer `Ready to activate` unless the output contract, eval coverage, registry, and guardrails are all present.

## Candidate-card audit standard

`!gems` should stay discovery-oriented and concise. Prefer candidate cards like:

```md
1. TICKER — Company Name

Bottom Line: [1 sentence.]

Why it surfaced: [short explanation.]

Setup Classification: [classification]
Hidden-Gem Overlay Score: [X]/25
Evidence Confidence: [A/B/C/D]

Rerating status: [Pre-Rerate / Early-Rerate / Post-Rerate / Overextended / Consolidating]
Main gap: [what needs verification]
Main risk: [most important risk]

Best next command: `!research TICKER`
```

Do not recommend full company reports per candidate by default. Detailed support belongs in the saved artifact.

## Artifact/index audit standard

Preserve existing `!gems` artifact architecture unless the user explicitly asks to change it:

- save detailed scan artifacts under `workspace/gems/...`;
- update `workspace/gems/index.md`;
- end successful user-facing output with:

```md
Saved to: workspace/gems/[actual path].md
Updated index: workspace/gems/index.md
```

Only show those lines after the write/update is actually supported by the command behavior. Never imply watchlist mutation; `!gems` candidates are research leads only.
