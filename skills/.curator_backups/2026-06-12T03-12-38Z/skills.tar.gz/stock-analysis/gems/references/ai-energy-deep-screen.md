# AI / Energy Deep Screen Notes

Use this reference when a user runs `!gems ai energy --deep` or an adjacent AI-power/data-center-electrification screen.

## What worked

- Treat AI energy as a crowded theme by default. Include obvious winners during screening, but usually screen out mega-cap or already-rerated leaders such as VRT, ETN, GEV, PWR, EME, NVT, POWL, MOD, and BE unless the user explicitly asks for comps.
- Prefer enabling-layer companies over headline AI-energy names when hidden-gem quality matters:
  - grid and transmission/distribution components;
  - telecom/fiber/data-communication physical infrastructure;
  - rack-level AI server integration, power, and cooling services;
  - electrical contractors with explicit AI/electrification demand evidence;
  - UPS/backup power and industrial energy-storage suppliers.
- Reuse adjacent `energy/data_centers.md` and `energy/infrastructure.md` artifacts when current, but re-rank for the AI-energy lens and explain what is incremental.

## Candidate evidence cues

Prioritize filing-backed evidence for:

- explicit AI, data-center, electrification, or load-growth commentary;
- backlog and backlog quality, including warnings that backlog is not a standalone indicator;
- customer concentration and termination rights, especially for small AI rack-integration names;
- facility power/cooling capex and whether customer payments cover fixed costs;
- revenue mix between one-time procurement, integration services, recurring maintenance, and construction/project work;
- shares outstanding for market-cap estimates when quote APIs do not return market cap.

## Useful SEC lookup fallback

If `https://www.sec.gov/files/company_tickers.json` returns 403 or unusable output, use SEC browse-edgar Atom lookup by ticker:

```text
https://www.sec.gov/cgi-bin/browse-edgar?CIK={TICKER}&owner=exclude&action=getcompany&output=atom&count=20
```

Then parse filing entry links and fetch the direct archive document URL rather than the `ix?doc=` wrapper when extracting text.

## Example classification from 2026-06-01 screen

- `PLPC` — cleaner researchable hidden-gem candidate: underfollowed grid/telecom/data-communication hardware supplier with Q1 energy/communication sales growth; indirect but credible AI-energy enabling-layer exposure.
- `TSSI` — speculative direct candidate: AI-enabled data-center rack integration, facility power/cooling investment, and largest-customer agreement economics; customer concentration and lease/debt obligations require `!risk` first.
- `MYRG` — researchable but less hidden: strong electrical contractor with explicit AI/electrification customer-investment language and backlog, but post-rerate.

## Pitfalls

- Do not rank pure/direct exposure above an enabling-layer company if the pure play is already post-rerate, crowded, fragile, or customer-concentrated.
- Do not treat procurement revenue as equivalent to high-margin integration or recurring service revenue.
- Do not treat backlog as guaranteed revenue; quote the filing caveat when available.
- Do not force a clean candidate if the theme is already rerated; a watch-only/screened-out result is acceptable.
