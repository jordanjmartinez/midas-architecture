# Command-Local Artifact Notes

This file is command-specific support material for the `!gems` workflow.

Global artifact behavior is controlled by:

`/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

This file must not override, duplicate, or compete with `rules/ARTIFACTS.md`.

If any instruction in this file conflicts with `rules/ARTIFACTS.md`, `rules/ARTIFACTS.md` wins.

## Gems Artifact Path Legacy Cleanup Note

When running `!gems` for a theme that previously used a legacy flat artifact path, preserve the old file but make the current run path rulebook-compliant.

Observed pattern:

- Legacy/stale references may point to flat files such as `space.md`, `semiconductor-equipment.md`, or `defense-drones.md`.
- Current rulebook-compliant paths should be folder-based, e.g. `space/general.md`, `semiconductors/equipment.md`, or `defense/drones.md`.

Operational rule:

1. Before saving, check the target folder-based artifact and any obvious legacy flat artifact / stale index row for the same theme.
2. Read legacy artifacts only for duplicate-candidate context.
3. Do not delete or migrate legacy files unless the user explicitly asks.
4. Save the current run to the correct folder-based path.
5. Update `workspace/gems/index.md` to point to the actual current path, not the stale legacy path.
6. Ensure the artifact's final `Saved to:` line exactly matches the path written.

This prevents confusing outputs where the artifact is physically saved under `workspace/gems/space/general.md` but the index or footer still says `space.md`.