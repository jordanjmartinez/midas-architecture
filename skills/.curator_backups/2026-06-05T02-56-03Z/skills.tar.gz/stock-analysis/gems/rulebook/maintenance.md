# MIDAS Gems Maintenance Notes

Use this rulebook when changing or troubleshooting the `!gems` discovery workflow.

## Core Intent

`!gems` is a discovery engine for asymmetric small/mid-cap research candidates.

It is not:

- a recommendation command
- a trading command
- a price-target command
- a position-sizing command
- a watchlist command

`!gems` finds candidates for deeper research. The user decides what to research or monitor next.

## Command Boundaries

Do not run other commands unless the user explicitly asks.

Do not automatically trigger:

- `!research`
- `!financials`
- `!thesis`
- `!thesis update`
- `!risk`
- `!earnings`
- `!updates`
- `!full`
- `!wl add`

It is okay to suggest the best next command, such as:

`!research [ticker]`

## Recommendation Boundaries

Do not give:

- Buy / Sell / Hold ratings
- price targets
- position sizing
- trade execution advice
- “you should buy” language

Do not call `!gems` candidates recommendations.

Use language like:

- research candidate
- watch-only candidate
- screened-out name
- candidate worth deeper research
- no clean pre-rerate candidate found

## Watchlist Boundary

Do not automatically add `!gems` candidates to the watchlist.

The user must choose candidates manually with:

`!wl add [ticker]`

`!gems` may include a section like:

`Candidates Worth Monitoring`

But it must not modify the watchlist itself.

## Skill and Rulebook Creation Boundary

Midas may suggest improvements when a repeated weakness, new pattern, or useful workflow appears.

Midas must not create new permanent skills, rulebooks, helper files, methodology files, or theme-specific reference files unless the user explicitly asks.

When Midas identifies a potential improvement, it should propose it first.

A proposal should include:

* What problem was observed.
* Why the improvement would help.
* Whether it should be added to an existing rulebook or become a new skill.
* Which file should be changed.
* The exact behavior change.

Default behavior:

* Prefer updating an existing rulebook over creating a new file.
* Prefer generic reusable rules over theme-specific rules.
* Prefer concise additions over large new frameworks.
* Do not create a new skill for a one-off screen.
* Do not create theme-specific rulebooks unless the user explicitly approves.

Approved places for `!gems` improvements:

* `rulebook/filters.md`
* `rulebook/scoring.md`
* `rulebook/artifacts.md`
* `rulebook/deep-mode.md`
* `rulebook/maintenance.md`
* `rulebook/update-rulebook.md`

If Midas believes a new skill or new rulebook file is needed, it should stop and ask for approval before creating it.

## Artifact Behavior

Theme artifacts live under:

`/home/jordan/.hermes/profiles/midas/workspace/gems/`

Use `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` for MIDAS-wide artifact standards and the folder-based `!gems` artifact structure from:

`rulebook/artifacts.md`

Global broad scan:

`workspace/gems/general.md`

Theme broad scan:

`workspace/gems/[theme]/general.md`

Theme/subtheme scan:

`workspace/gems/[theme]/[subtheme].md`

Examples:

- `!gems` → `workspace/gems/general.md`
- `!gems space` → `workspace/gems/space/general.md`
- `!gems semiconductor equipment --deep` → `workspace/gems/semiconductors/equipment.md`
- `!gems ai infrastructure` → `workspace/gems/ai/infrastructure.md`

Each run should overwrite the clean current artifact rather than append a long log.

Each run must also create or update:

`workspace/gems/index.md`

The final response should end with both:

`Saved to: workspace/gems/[actual path].md`

`Updated index: workspace/gems/index.md`

## Hidden-Gem Quality Guard

Do not confuse a good company or high-momentum stock with a hidden gem.

Before presenting a candidate, check recent stock performance and classify rerating status:

- Pre-Rerate Candidate
- Early-Rerate Candidate
- Post-Rerate Candidate
- Momentum-Only / Exclude

Prefer pre-rerate and early-rerate names.

Penalize post-rerate names unless fundamentals, backlog, asset value, revenue trajectory, commercialization progress, or another company-specific factor plausibly justify the move.

Exclude momentum-only names.

If the best-known names in a theme have already doubled/tripled or the theme has broadly rerated, say so clearly and return fewer candidates rather than forcing a weak full list.

It is acceptable to say:

`No clean pre-rerate candidates found in this theme right now.`

## Rulebook Structure

`SKILL.md` should remain the concise controller for `!gems`.

Detailed logic should live in the rulebook files:

- `rulebook/filters.md` — hidden-gem filters and quality checks
- `rulebook/scoring.md` — Hidden-Gem Quality Score and ranking discipline
- `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` — MIDAS-wide artifact standards
- `rulebook/artifacts.md` — `!gems`-specific artifact paths, folder rules, and index behavior
- `rulebook/deep-mode.md` — `--deep` screen process
- `rulebook/maintenance.md` — command boundaries and maintenance rules
- `rulebook/update-rulebook.md` — how to safely add future checks

Do not paste long detailed rule sections back into `SKILL.md` unless the user explicitly asks.

Do not weaken `!gems` when moving details into rulebook files.
