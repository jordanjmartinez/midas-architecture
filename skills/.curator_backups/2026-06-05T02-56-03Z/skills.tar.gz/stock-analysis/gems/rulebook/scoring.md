# MIDAS Gems Quality-Score Framework

Use this rulebook when extending or applying the `!gems` hidden-gem quality filters.

## Purpose

`!gems` should find underdiscovered, pre-rerate or early-rerate research candidates, not merely small companies, hot-theme stocks, or strong momentum charts.

A clean candidate must show:

* Underdiscovered status.
* A specific information gap.
* A non-obvious angle beyond the headline theme.
* Company-specific fundamental underreaction.
* Adequate liquidity, disclosure quality, and filing-backed evidence.
* Risk / fragility that does not overwhelm the setup.

## Five-Factor Score

Score every candidate 1-5 on:

1. Business Quality / Validation
2. Underdiscovered Status
3. Information Gap
4. Rerating / Consolidation Discipline
5. Risk / Fragility

Use:

* 1 = weak
* 3 = acceptable
* 5 = strong

Calculate:

`Total Hidden-Gem Score: [total] / 25`

Classification bands:

* 21-25: Strong clean gem candidate
* 17-20: Researchable candidate
* 13-16: Watch only / needs more evidence
* Below 13: Screened out

Do not let one strong category override weak scores elsewhere.

## Factor Guidance

### Business Quality / Validation

Higher score if the company has real revenue, credible commercialization progress, backlog, contracts, customer wins, improving margins, strong assets, or technical validation.

Lower score if the business case is mostly speculative, pre-revenue without validation, or dependent on hope.

### Underdiscovered Status

Higher score if the company has limited analyst/media coverage, low mainstream attention, a niche or complex business, or is not commonly grouped with obvious theme winners.

Lower score if the company is widely discussed, social-media popular, or already treated as an obvious winner.

Small market cap alone is not underdiscovered evidence.

### Information Gap

Higher score if there is a clear filing-backed or disclosure-backed gap between what the company is showing and what the market appears to recognize.

Lower score if the thesis is obvious, vague, or based only on cheap valuation, small size, or theme exposure.

The output should identify:

1. What the market may be missing.
2. Where that evidence appears.
3. Why it may not be reflected yet.

### Rerating / Consolidation Discipline

Higher score if the stock is pre-rerate, early-rerate, or has consolidated after a prior move while fundamentals continue improving.

Lower score if the stock already doubled/tripled, is still vertical, or appears momentum-driven.

A high-quality business with poor rerating discipline should not rank as a clean hidden gem.

### Risk / Fragility

Higher score if the company has manageable debt, reasonable liquidity, credible funding, good disclosure, and limited promotion/dilution risk.

Lower score if the company has weak disclosure, heavy dilution, high leverage, poor liquidity, promotional behavior, or fragile fundamentals.

High-risk candidates can be interesting, but should not be presented as clean unless validation and information gap are unusually strong.

## Supporting Checks

### Non-obvious angle

Prefer second-order beneficiaries, suppliers, infrastructure providers, tooling companies, data providers, software layers, components, or mission-critical inputs behind a larger theme.

Do not exclude AI, space, semiconductor, defense, energy, automation, robotics, or other high-growth names solely because of theme exposure.

Downgrade only when the thesis lacks a specific non-obvious angle, information gap, or underdiscovered evidence.

### Fundamental underreaction

Sector sentiment can be a tailwind, but the thesis must include company-specific improvement such as revenue acceleration, margin improvement, backlog growth, new contracts, lower cash burn, stronger balance sheet, commercialization milestones, or operating leverage.

### Insider / ownership alignment

Insider buying, founder ownership, owner-operator structure, management ownership, and compensation alignment are supporting evidence only.

They cannot override weak fundamentals, poor disclosure, heavy dilution, or a missing information gap.

### Liquidity / promotion risk

Illiquidity alone does not make a company underdiscovered.

Downgrade OTC, weak-disclosure, stock-promotion, retail-attention-driven, or capital-raise-into-stock-move setups unless the filing-backed business case is unusually strong.

### Special situations

Spin-offs, divestitures, restructurings, asset sales, new management, segment separations, merger integrations, and business transitions can support an information gap only when verified through filings or company disclosures.

Do not include a company only because of corporate action news.

## Score Modifiers

After calculating the five-factor Hidden-Gem Quality Score, apply judgment-based modifiers only when there is a clear reason.

Modifiers do not replace the score. They adjust the final classification when the setup has a specific quality that the simple score does not fully capture.

Positive modifiers:

* Special situation creates a real information gap.
* Founder/operator ownership or meaningful insider alignment supports the setup.
* Sector sentiment is improving while the company-specific thesis remains underdiscovered.
* The company has a clear non-obvious angle behind a larger theme.

Negative modifiers:

* Stock has already doubled or tripled without enough fundamental improvement.
* Stock is still vertical with no consolidation.
* Liquidity, dilution, promotion, or disclosure risk is elevated.
* The thesis is mostly theme exposure with weak company-specific evidence.
* The company is small but not truly underdiscovered.

Use modifiers to adjust the final classification among:

* Strong clean gem candidate
* Researchable candidate
* Watch only / needs more evidence
* Screened out

If a modifier changes the classification, explain why.

Do not allow one positive modifier to override weak fundamentals, poor disclosure, major dilution risk, or lack of information gap.

Do not allow one negative modifier to automatically eliminate a candidate if the filing-backed information gap and business validation are unusually strong.

## Ranking Discipline

Use the Hidden-Gem Quality Score to discipline ranking.

Do not rank candidates only by business quality, market cap, excitement, or theme relevance.

A lower-quality business with a stronger underdiscovered information gap and cleaner rerating setup may rank above a higher-quality company that has already fully rerated.

A company with a high Business Quality / Validation score but weak Information Gap or poor Rerating / Consolidation Discipline should not rank as a clean hidden-gem candidate.

If two candidates have similar scores, prefer the one with:

1. Stronger information gap.
2. Cleaner pre-rerate or early-rerate setup.
3. Better company-specific fundamental underreaction.
4. Lower liquidity, dilution, promotion, or disclosure risk.
5. More actionable next research question.

If no candidate reaches at least `17/25`, say that no clean or researchable hidden-gem candidate was found and move relevant names to `Watch Only / needs more evidence` or `Screened out`.

## Output Implication

The candidate output should include:

* Hidden-Gem Quality Score table.
* Total score out of 25.
* Score classification.
* Underdiscovered evidence.
* Information gap.
* Non-obvious angle.
* Fundamental underreaction.
* Insider / ownership alignment where relevant.
* Liquidity / promotion risk.
* Special situation status where relevant.

Use the score to discipline ranking and to avoid forcing weak names into the clean hidden-gem category.
