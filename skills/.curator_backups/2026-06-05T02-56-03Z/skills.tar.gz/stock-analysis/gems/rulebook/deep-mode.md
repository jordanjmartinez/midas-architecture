# MIDAS Gems Deep Mode

Use this rulebook when `!gems [theme] --deep` or `!gems [theme] [subtheme] --deep` asks for a deeper niche industry screen where obvious leaders may be too large, already discovered, or already rerated.

## Purpose

Deep mode is for higher-quality discovery passes.

It should prefer fewer, better-supported candidates over a padded list.

Deep mode should not force candidates if the theme is already crowded, fully rerated, too promotional, too fragile, or lacks clean information gaps.

It is acceptable to return:

`No clean pre-rerate candidates found in this theme right now.`

## Deep Mode Process

1. Build a candidate universe from the theme/subtheme.

2. Include obvious leaders during screening so they can be explicitly screened out if too large, too obvious, event-driven, post-rerate, or momentum-only.

3. Include smaller suppliers, second-order beneficiaries, infrastructure providers, tools, components, services, niche operators, and less obvious public companies where relevant.

4. Fetch or verify the latest 10-K / 10-Q for each candidate through SEC EDGAR when available.

5. Review investor relations materials, earnings releases, investor presentations, and company press releases when useful.

6. Pull market data with a quote/chart source and calculate recent performance windows when possible:

   * 1M
   * 3M
   * 6M
   * 1Y
   * YTD

7. Estimate market cap from reliable market data when available.

8. If market-cap data is unavailable or unreliable, estimate market cap from:

   `latest price × latest reported shares outstanding`

   Cite the filing source/date for shares and the market-data source/date for price.

9. Apply the hidden-gem quality filters from:

   `rulebook/filters.md`

10. Apply the scoring framework from:

`rulebook/scoring.md`

11. Explicitly screen out names that are:

* too large
* already rerated
* still vertical / momentum-only
* merger-arb or event-driven
* weak disclosure
* promotional
* too fragile
* lacking a clear information gap

12. Save the full artifact first.

13. Update `workspace/gems/index.md` after the artifact is saved.

14. Telegram/mobile users may type an em dash in `—deep`; normalize it to deep mode.

## Candidate Evaluation Buckets

Use these buckets only when they help explain the screen.

* **Best clean gem candidate**: strongest mix of business validation, underdiscovered status, information gap, non-obvious angle, rerating discipline, and manageable risk.
* **Researchable candidate**: interesting enough for `!research`, but not clean enough to call a strong gem.
* **Post-rerate watchlist candidate**: relevant company, but already moved too much or lacks enough consolidation.
* **Speculative moonshot**: below preferred size range or early-stage, only if there is concrete validation and a real asymmetric path.
* **Screened out / watch only**: too large, too obvious, already rerated, merger/event-driven, fragile, promotional, or momentum-only.

Do not force these buckets if they do not fit the theme.

## No Clean Candidate Behavior

If all credible companies in the theme are already post-rerate, too large, too promotional, too fragile, or lack a clear information gap, say so clearly.

It is acceptable for deep mode to return no clean hidden-gem candidates.

In that case, place relevant companies in `Watch Only / Screened Out` and explain why they failed the clean-gem test.

Do not force three candidates just because deep mode allows up to three.

## SEC-Backed Deep Screen Discipline

For deep screens, use primary filings whenever possible.

A deep screen should compare candidates using filing-backed evidence plus lightweight market-move checks, without turning the scan into a full `!research` or `!financials` memo.

Use this process:

1. Build a broad candidate universe first.

   * Include obvious peers, adjacent suppliers, software names, infrastructure providers, and likely near misses.
   * Keep screened-out or watch-only candidates in the artifact when they help explain why the top candidates are better.

2. Verify key candidate facts through primary sources when available.

   * Prefer the latest 10-K and 10-Q.
   * Use material 8-Ks, earnings releases, investor presentations, or company disclosures only when relevant.

3. Use filing-backed evidence for material claims.

   * Prefer filing evidence for business model, contracts, backlog, revenue, cash, debt, losses, cash flow, dilution, and risk statements.
   * Do not rely on promotional summaries when filings are available.

4. Pair filing evidence with recent stock performance.

   * Check 1M, 3M, 6M, 1Y, and YTD moves when available.
   * Use recent performance to classify pre-rerate, early-rerate, post-rerate, or momentum-only status.
   * Downgrade vertical or post-rerate names unless filing-backed execution clearly supports remaining asymmetry.

5. Separate direct theme exposure from hidden-gem quality.

   * A pure play can rank below an adjacent candidate if it is already crowded, post-rerate, fragile, or lacks an information gap.
   * An adjacent platform can rank highly only if the theme bridge is explicit and filing-backed.

6. Keep the chat response concise.

   * Save detailed reasoning and sources in the artifact.
   * The chat response should summarize top candidates, screened-out/watch-only names, best next command, saved artifact path, and updated index path.

Pitfalls:

* Do not confuse a large pipeline with awarded revenue.
* Do not treat non-cash fair-value gains as operating profitability.
* Do not let market momentum alone qualify a candidate as a gem.
* Do not rank large or institutional names as hidden gems just because they are high-quality theme leaders.
* Do not create flat multi-word artifact files when the artifact rulebook requires folder-based paths.

## Adjacent Theme Handling

Use this when a `!gems [theme] [subtheme] --deep` request overlaps a recently screened theme.

Reuse prior filing fetches, ticker universe notes, and candidate classifications when they are still current, but re-rank candidates for the new subtheme instead of copying the prior answer.

Separate candidates into:

* **Direct theme fit** — products, services, assets, contracts, or disclosures directly match the requested subtheme.
* **Adjacent layer** — enabling software, components, infrastructure, services, data, tools, systems, or supply-chain exposure that supports the requested subtheme.
* **Theme comp only** — useful comparator but too large, too obvious, post-rerate, fragile, or not hidden-gem quality.

Cross-theme candidates can appear again, but the artifact must explain why they remain relevant under the new lens.

Rank by hidden-gem quality for the requested subtheme, not by the prior screen’s ranking.

If a top candidate repeats from a prior theme, explain what is incremental about the new screen.

Do not pad with fragile pure plays just because they are thematically pure.

Use folder-based paths for new adjacent subthemes.

In `index.md`, include cross-theme notes when the same candidate appears across multiple screens.

## Enabling-Layer Discovery

For deep theme screens, do not screen only the obvious headline companies.

The better hidden-gem angle may be the enabling layer behind the theme.

Examples of enabling layers include:

* Supply chain.
* Components.
* Tooling.
* Software layer.
* Data layer.
* Infrastructure.
* Testing or qualification.
* Fabrication.
* Permits or approvals.
* Mission-critical suppliers.
* Customer-funded agreements.
* Backlog, assets, or operating leverage hidden behind a larger theme.

Rank companies by hidden-gem quality, not by headline theme purity.

A direct pure play can rank below an enabling-layer company if the pure play is already discovered, post-rerate, too promotional, too fragile, or lacks a clear information gap.

An enabling-layer company can rank highly only if the theme bridge is explicit and supported by filings, company disclosures, contracts, customer validation, backlog, permits, assets, or commercialization milestones.

Do not create a separate theme-specific rulebook unless the user explicitly asks.

## Industry-Specific Source Cues

For every deep screen, build source cues based on that industry’s actual business drivers.

Do not reuse one industry’s checklist for every theme.

For each theme, identify the concrete evidence that matters most, such as:

* Backlog.
* Contracts or customer wins.
* Revenue conversion.
* Asset ownership.
* Permits or interconnection progress.
* Technical validation.
* Commercial milestones.
* Recurring revenue.
* Installed base.
* Balance-sheet quality.
* Cash runway.
* Margin improvement.
* Operating leverage.
* Customer concentration.
* Sector-specific risks.

The source cues should come from filings, investor relations materials, earnings releases, investor presentations, and credible market data.

Avoid generic theme logic.

Do not include a candidate only because it has exposure to AI, space, semiconductors, defense, energy, automation, robotics, data centers, or another hot theme.

## Response Style

Use the concise response template defined in `SKILL.md`.

For deep-mode chat responses, apply these additional requirements:

* Title the response as `MIDAS Gems — [Theme / Sector] Deep Screen`.
* Include top candidates or clearly state that no clean candidates were found.
* Always display `Hidden-Gem Score: [X]/25` for each top candidate.
* Include rerating status for each top candidate.
* Include one-line rationale for each top candidate.
* Include screened-out / watch-only names if important.
* Include the best next command.
* End with the saved artifact path and updated index path.

Do not omit the score.

Do not use `/10`, `/100`, percentages, or decimal score formats.

Use `Screened Out / Watch Only`, not `Watchlist`, unless referring to the user manually running `!wl add [ticker]`.

Keep the Telegram/chat response concise.

Put detailed source-backed reasoning, scoring, quality filters, screened-out names, and verification details in the saved Markdown artifact.
