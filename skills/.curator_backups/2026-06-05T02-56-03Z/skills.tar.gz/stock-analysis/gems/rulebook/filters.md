# MIDAS Hidden-Gem Quality Filters

Use this rulebook when maintaining or applying the `!gems` skill. These filters keep MIDAS from confusing small-cap size, hot-theme exposure, or price momentum with a true hidden-gem research candidate.

## Purpose

A clean MIDAS gem should generally have:

1. A rerating status that is not pure momentum.
2. Evidence of consolidation if the stock already moved sharply.
3. Underdiscovered evidence beyond small market cap.
4. A specific information gap.
5. A non-obvious angle beyond the headline theme.
6. Company-specific fundamental underreaction.
7. Reasonable liquidity, disclosure quality, and promotion-risk discipline.
8. A filing-backed reason why the market may not fully recognize the setup yet.

These are research-quality controls, not trading signals.

## Universe Filters

Apply these filters before ranking candidates.

### Preferred Universe

Prefer:

* U.S.-listed public companies.
* Market cap ideally between `$500M` and `$2B`.
* Companies between `$2B` and `$5B` only if the setup is clearly asymmetric.
* Small-cap or mid-cap companies.
* Underfollowed or misunderstood companies.
* Companies with available filings and enough disclosure to verify the setup.
* Companies with improving fundamentals, credible commercialization progress, or a credible path to operating leverage.
* Companies with tangible assets, strategic infrastructure, signed contracts, backlog, permits, technical validation, customer commitments, government/commercial demand, or important milestones.

Preferred themes include:

* AI infrastructure.
* Data centers.
* Energy infrastructure.
* Automation.
* Cybersecurity.
* Robotics.
* Defense technology.
* Space.
* Industrial technology.
* Fintech infrastructure.
* Power / grid infrastructure.
* Critical minerals or infrastructure supply chains.

### Excluded Universe

Do not include:

* China-based companies.
* Retail companies.
* Biotech companies.
* Pharma companies.
* Healthcare companies.
* Binary FDA or clinical trial stories.
* Pre-revenue biotech or pharma companies.
* Pre-revenue healthcare companies.
* Companies where the main thesis depends on drug approvals.
* Companies where the main thesis depends on China macro/regulatory sentiment.
* Consumer retail turnaround stories.
* Obvious pump / hype stocks.
* Meme stocks with no fundamental setup.
* Companies with no reliable filings or poor disclosure.
* Companies that are only interesting because the stock recently moved.
* Companies with no credible commercialization path.

If the user explicitly asks for an excluded sector, explain that it violates the MIDAS gems filter and offer to scan an allowed adjacent theme instead.

## Market-Cap Rules

Preferred market cap:

`$500M to $2B`

Acceptable only with stronger asymmetric reasoning:

`$2B to $5B`

Avoid unless the setup is unusually compelling or the user explicitly asks:

* Below `$500M`, because the company may be too illiquid, speculative, or fragile.
* Above `$5B`, because it is less likely to be truly overlooked.

If including a company outside the preferred range, explain why it still qualifies.

Market cap alone does not make a company a hidden gem.

## Pre-Revenue / Early-Revenue Exception

Do not require every candidate to have meaningful current revenue.

MIDAS may include pre-revenue or early-revenue companies only when the company fits an allowed hard-tech, infrastructure, or asset-development profile.

Allowed exceptions include:

* Space and aerospace companies.
* Defense technology companies.
* Energy infrastructure companies.
* Data center or power infrastructure companies.
* Industrial automation companies.
* Robotics companies.
* Grid, battery, power, or critical infrastructure companies.
* Deep-tech companies with real commercial milestones.
* Asset-heavy companies with owned sites, permits, pipeline, backlog, contracts, or strategic infrastructure value.

A pre-revenue or early-revenue company must have at least 2-3 concrete validation points, such as:

* Signed contracts.
* Backlog.
* Customer commitments.
* Government awards.
* Commercial pilots.
* Technical milestones.
* Launch cadence.
* Owned infrastructure.
* Permits or interconnection progress.
* Strategic assets.
* Funded pipeline.
* Clear path to monetization.

If a company is pre-revenue or early-revenue, label it clearly as:

`Pre-Revenue / Early-Revenue Exception`

Then explain why it still qualifies.

Do not allow pre-revenue exceptions for biotech, pharma, healthcare, binary FDA stories, or hype-only companies.

## Rerating Status

Classify each candidate as one of:

* `Pre-Rerate Candidate` — stock has not made a major move, but business evidence is improving.
* `Early-Rerate Candidate` — stock has started moving, but the move may still be supported by improving fundamentals, backlog, contracts, revenue growth, asset value, or commercialization progress.
* `Post-Rerate Candidate` — stock has already moved significantly; may still be worth watching, but should not be presented as a clean hidden gem unless the remaining underreaction is clearly explained.
* `Momentum-Only / Exclude` — the stock appears interesting mostly because of price momentum, hype, social attention, or sector enthusiasm rather than company-specific evidence.

Prefer pre-rerate and early-rerate names. Return fewer candidates rather than forcing post-rerate or momentum-only ideas into the list.

## Consolidation Check

If a stock has already made a major move, check whether it has cooled off.

More attractive:

* Pulled back from a spike.
* Traded sideways for weeks or months.
* Built a base instead of staying vertical.
* Valuation cooled while fundamentals, backlog, contracts, or commercialization milestones kept improving.
* Reset after a prior rerate while the long-term thesis remains intact.

Less attractive:

* Still vertical or parabolic.
* Near recent highs after a massive move.
* Move appears mostly theme-driven or sector-driven.
* Not enough pause for fundamentals to catch up.
* Candidate appears only because of momentum.

A stock that moved sharply and then consolidated may be `Early-Rerate Candidate` or `Post-Rerate Watchlist Candidate`. A stock still moving vertically should usually be `Momentum-Only / Exclude`.

## Underdiscovered Status

A clean hidden-gem candidate should have at least two signs it may still be underdiscovered, such as:

* Limited analyst coverage.
* Limited mainstream financial media coverage.
* Low retail or social-media attention.
* Boring, niche, industrial, infrastructure, or complex business model.
* Not commonly included in the obvious peer basket.
* Improvement visible in filings but not widely discussed.
* Thesis requires work to understand: backlog, asset value, operating leverage, permits, commercialization milestones, or segment-level progress.
* Screens poorly on simple metrics, but deeper work shows improving quality.
* Market may be focused on the wrong segment, old narrative, or outdated risk.

Small market cap alone is not evidence of underdiscovery.

If a company is well-known and already post-rerate, move it to `Screened Out / Watch Only` unless a remaining underdiscovered angle is clearly explained.

## Social Media Discovery Signal

Social sources may be used only as discovery, sentiment, or crowding signals.

They are not primary evidence.

Use social sources to identify:

- Whether a company is already widely discussed.
- Whether retail attention or hype is driving the stock.
- Whether a ticker is becoming crowded.
- Whether an overlooked idea deserves filing-backed verification.

Do not use social sources as proof of:

- Revenue.
- Backlog.
- Contracts.
- Customer wins.
- Profitability.
- Cash runway.
- Government awards.
- Commercial milestones.
- Technical validation.

Any idea found through social media must be verified through SEC filings, company disclosures, investor relations materials, earnings releases, or other credible primary sources before it can be ranked as a candidate.

If social attention is high and the stock has already rerated, downgrade the candidate unless the filing-backed information gap remains strong.

Preferred social media sources:

- X
- Reddit
- Seeking Alpha

## Information Gap Requirement

A candidate must have a clear information gap.

Do not include a company only because it is cheap, small, or in the right theme.

The output should explain:

1. What the market may be missing.
2. Where that evidence appears.
3. Why the evidence may not be fully reflected in the stock yet.

Acceptable information gaps include:

* Backlog growth not reflected in valuation.
* Asset value not reflected in market cap.
* Segment improvement hidden inside a messy consolidated company.
* Operating leverage beginning before the market recognizes it.
* Commercial milestone not yet understood.
* Strong balance sheet overlooked because sentiment is poor.
* Niche leadership ignored because the company is boring or small.
* Permits, interconnection progress, customer commitments, or infrastructure progress not yet reflected in market value.
* Strategic pivot visible in filings or disclosures but not obvious in headline metrics.
* Business mix shift where a higher-quality segment is growing while consolidated numbers still look weak.

If the information gap is weak, vague, or only based on theme exposure, remove the candidate or move it to `Screened Out / Watch Only`.

## Non-Obvious Angle Preference

Prefer candidates with a non-obvious angle beyond the headline theme.

This does not exclude AI, space, semiconductor, defense, energy, automation, robotics, or other high-growth theme companies. It means the thesis must be more specific than:

* “AI beneficiary”
* “space stock”
* “semiconductor stock”
* “defense stock”
* “energy infrastructure play”
* “robotics play”

More attractive:

* Second-order or underappreciated beneficiary.
* Supplier, component maker, infrastructure provider, tooling company, data provider, software layer, or mission-critical input behind a larger theme.
* Filing-backed or disclosure-backed information gap.
* Underappreciated backlog, asset value, contracts, permits, commercialization milestones, operating leverage, segment improvement, or customer validation.
* Misunderstood, technically complex, niche, or not grouped with obvious winners.
* Market may be focused on the wrong narrative, peer group, or old risk profile.

Less attractive:

* Thesis is only that the company belongs to a hot theme.
* Popular mainly because of social media, momentum, or theme excitement.
* Market is discovering it faster than fundamentals are improving.
* Already treated as an obvious headline winner.
* Upside case depends mostly on buzzwords rather than evidence.

This is a preference, not a hard exclusion.

Do not reject a company solely because it has hot-theme exposure; downgrade it only if it lacks a specific non-obvious angle, information gap, or underdiscovered evidence.

## Fundamental Underreaction Check

A clean gem should show evidence that fundamentals, execution, commercialization, or business quality are improving while market perception may still lag.

Look for:

* Revenue acceleration.
* Margin improvement.
* Backlog growth.
* New contracts or customer wins.
* Lower cash burn.
* Better balance sheet.
* New commercialization milestone.
* Management execution improving after prior skepticism.
* Negative old narrative that may no longer be accurate.
* Segment-level improvement hidden inside weaker consolidated results.
* Operating leverage beginning before it is obvious in headline earnings.
* Customer demand, permits, infrastructure progress, or technical milestones improving before revenue fully shows up.
* Sector sentiment improving while company-specific evidence is still underappreciated.

Sector sentiment can be a valid tailwind, but it should not be the entire thesis.

If a stock has already moved sharply, explain whether company-specific fundamentals improved enough to justify the rerating.

Do not rank a company as a clean hidden gem if:

* The stock has moved sharply but there is no company-specific improvement.
* The thesis is based mostly on future hope with no recent evidence.
* The business is still deteriorating and there is no credible sign of inflection.
* The only argument is that the sector is hot.

Classification guidance:

* Sector sentiment improving + company-specific fundamentals improving: may qualify.
* Sector sentiment improving + company not yet rerated: may support a hidden-gem setup.
* Sector sentiment improving + company already rerated sharply: classify as `Post-Rerate Watchlist Candidate` unless remaining underreaction is clearly explained.
* Stock moved sharply only because the sector rerated: classify as `Momentum-Only / Exclude`.

## Insider / Ownership Alignment Check

Insider buying, founder ownership, owner-operator structure, or high management ownership may support a candidate, but it cannot be the main reason for inclusion.

Use insider alignment only as supporting evidence.

More attractive:

* Meaningful open-market insider purchases.
* Founder-led or owner-operator structure.
* Meaningful insider or management ownership.
* Management compensation tied to long-term performance, free cash flow, return on capital, profitability, stock ownership, or long-term shareholder value.
* Insider alignment supports an already strong underdiscovered setup, information gap, or fundamental underreaction.

Less attractive:

* Promotional insider buying with weak fundamentals.
* Tiny or symbolic purchases.
* Heavy dilution despite insider ownership.
* Insider selling combined with weak execution, cash burn, or deteriorating fundamentals.
* Insider alignment being used to distract from weak business evidence.

Insider alignment should never override weak fundamentals, poor disclosure, heavy dilution, or lack of information gap.

If insider alignment is relevant, mention it as supporting evidence, not the core thesis.

## Liquidity / Promotion Risk Check

Do not confuse illiquidity, poor disclosure, or stock promotion with hidden-gem status.

A candidate is less attractive if:

* It has very low trading volume.
* It trades OTC or has weak disclosure.
* It has recent stock promotion activity.
* The stock is more visible than the actual business.
* The company issues frequent promotional press releases with little financial substance.
* The thesis depends on retail attention rather than business execution.
* The company frequently raises capital into stock moves.
* The company has high dilution risk with limited operating progress.
* Management uses hype language without filing-backed evidence.

If liquidity or promotion risk is elevated, downgrade the candidate to `Screened Out / Watch Only` unless the filing-backed business case is unusually strong.

Illiquidity alone does not make a company underdiscovered.

A clean hidden-gem candidate should have enough trading liquidity, disclosure quality, and filing-backed evidence to support deeper research.

## Special Situation Check

A candidate may be more interesting if it is underfollowed because of a structural reason.

Special situations can create information gaps because old financials, old peer groups, old narratives, or old screening data may no longer reflect the current business.

Examples:

* Recent spin-off.
* Recent divestiture.
* Strategic repositioning.
* New management.
* Hidden asset sale.
* Segment separation.
* Balance sheet cleanup.
* Business transition that makes old financials misleading.
* Recent merger integration that may obscure the underlying business.
* Non-core asset sale that changes leverage, focus, or valuation.
* Legacy business decline masking a faster-growing segment.

Special situations are allowed only if the business case can be verified through filings or company disclosures.

More attractive:

* Market may still be using the old narrative.
* Historical financials make the company screen poorly.
* Current business mix is better than old business mix.
* Divestiture, spin-off, asset sale, or restructuring changed the risk profile.
* Setup creates a clear information gap.

Less attractive:

* Company is only interesting because of corporate action news.
* Business remains weak after the transaction.
* Transaction increases complexity without improving quality.
* Thesis depends on speculation rather than filing-backed evidence.

Do not include a company only because it is a spin-off, divestiture, or restructuring story.

Use special situation status as supporting evidence for the information gap, not as the entire thesis.

## Asymmetry Rules

A candidate should have at least 2-3 concrete reasons why the setup may be asymmetric.

The asymmetry case should include:

1. Why the business may be mispriced.
2. What the market may be missing.
3. Where the evidence appears.
4. Why the evidence may not be fully reflected in the stock yet.
5. Why the stock has not already fully reflected the opportunity.

Examples:

* Market may not be pricing in a new catalyst.
* Company owns scarce assets.
* Growth is improving while sentiment remains poor.
* Operating leverage is starting to appear.
* Business model is misunderstood.
* Strong balance sheet creates survival advantage.
* Niche leadership is not widely recognized.
* Strategic pivot is beginning to work.
* Pre-revenue company has tangible assets, contracts, infrastructure, backlog, or technical milestones that may not be fully reflected in market cap.

Do not include a company based only on theme exposure.

Do not include a company based only on cheap valuation.

Do not include a company based only on hype.

If the asymmetry case is weak, remove the candidate or move it to `Screened Out / Watch Only`.

## Candidate Output Blocks

When applying these filters, candidate-level output should include:

```md
Price move / rerating status:
[Pre-Rerate Candidate / Early-Rerate Candidate / Post-Rerate Candidate / Momentum-Only / Exclude]

Consolidation status:
[Not applicable / Still vertical / Pulling back / Consolidating / Base-building / Reset after rerate]

Consolidation judgment:
[Explain whether the stock has cooled enough to qualify, or whether it looks like momentum-chasing.]

Hidden-gem status:
[Clean hidden-gem candidate / Post-Rerate Watchlist Candidate / Screened Out / Watch Only / Not enough evidence]

Underdiscovered status:
[Underdiscovered / Partially discovered / Already discovered / Not enough evidence]

Underdiscovered evidence:
1. [Evidence]
2. [Evidence]

Information gap:
- What the market may be missing: [Answer]
- Where the evidence appears: [Filing / company disclosure / investor presentation / earnings release / market data]
- Why it may not be reflected yet: [Answer]

Non-obvious angle:
[Specific angle beyond the headline theme.]

Fundamental underreaction:
- Company-specific improvement: [Answer]
- Evidence source: [Answer]
- Market perception lag: [Answer]
- Rerating justification if stock moved sharply: [Answer]

Insider / ownership alignment:
- Alignment evidence: [Insider buying / founder-led / owner-operator / management ownership / long-term compensation alignment / not material]
- Supporting judgment: [Explain why this supports the thesis, or why it is not meaningful. Do not make this the core thesis.]
- Dilution / selling caveat: [Mention heavy dilution, insider selling, weak execution, or not applicable]

Liquidity / promotion risk:
- Trading liquidity: [Adequate / limited / very low / not enough evidence]
- Disclosure quality: [SEC filer / reliable public filings / weak disclosure / OTC or not applicable]
- Promotion risk: [Low / elevated / recent promotion activity / frequent promotional PRs / not enough evidence]
- Capital-raising risk: [Explain whether the company frequently raises capital into stock moves or has high dilution risk]
- Downgrade judgment: [Explain whether liquidity or promotion risk requires Screened Out / Watch Only]

Special situation status:
- Structural change: [Spin-off / divestiture / strategic repositioning / new management / asset sale / segment separation / balance-sheet cleanup / merger integration / business transition / not material]
- Filing-backed evidence: [Filing or company disclosure source]
- Old narrative or screening issue: [Explain whether old financials, old peer groups, old narratives, or old screening data may be misleading]
- Information-gap support: [Explain how the special situation supports the information gap, or why it does not]
- Quality judgment: [Explain whether the business quality improved, or whether the transaction only adds complexity]
```

## Verification Reminders

Before presenting final `!gems` candidates:

* Apply the universe filters before ranking candidates.
* Exclude China, retail, biotech, pharma, and healthcare companies.
* Apply the market-cap preference: `$500M-$2B` preferred, `$2B-$5B` only if clearly asymmetric.
* Include companies below `$500M` or above `$5B` only if unusually compelling and clearly explained.
* Include pre-revenue or early-revenue companies only if they qualify under the allowed hard-tech / infrastructure exception.
* Exclude pre-revenue biotech, pharma, healthcare, or FDA-dependent companies.
* Do not use small market cap alone as hidden-gem evidence.
* Do not use sector heat as the whole thesis.
* Do not include a name only because it is cheap or theme-exposed.
* Do not rank vertical/parabolic stocks as clean hidden gems.
* Downgrade obvious headline winners unless they still have a clear underdiscovered information gap or non-obvious angle.
* Prefer fewer high-quality candidates over a padded list.
* Use insider buying, founder ownership, owner-operator structure, or management alignment only as supporting evidence, not the core thesis.
* Do not allow insider alignment to override weak fundamentals, poor disclosure, heavy dilution, or lack of information gap.
* Check liquidity, disclosure quality, promotion risk, and capital-raising risk before ranking a candidate as clean.
* Do not confuse illiquidity or stock promotion with underdiscovered status.
* Use special situations only when verified through filings or company disclosures.
* Do not include a company only because it is a spin-off, divestiture, restructuring, or management-change story.
* Make sure every clean candidate has a real information gap and 2-3 concrete asymmetry reasons.
