# MIDAS Gems Update Rulebook

Use this rulebook when the user asks to add another `!gems` quality-control rule, screening check, candidate classification rule, score adjustment, output-field requirement, or workflow improvement.

## Purpose

This file explains how to safely update `!gems` without bloating `SKILL.md`.

`SKILL.md` should remain the controller / dispatcher.

Detailed `!gems` logic should live in the rulebook files.

## Scope

Update the class-level `gems` skill. Do not create a new narrow skill for each new check.

Preserve these boundaries unless the user explicitly asks to change them:

- Artifact folder rules under `workspace/gems/...`.
- `index.md` maintenance behavior.
- Watchlist boundaries: `!gems` must not auto-add tickers to the watchlist.
- Command boundaries: do not rerun `!gems` or trigger `!research`, `!financials`, `!thesis`, `!risk`, `!earnings`, `!updates`, or `!full` unless the user asks.
- Recommendation boundaries: do not give Buy/Sell/Hold ratings, price targets, position sizing, or trade execution advice.

## New Skill / New Rulebook Approval

Do not create new permanent skills, rulebook files, helper files, methodology files, reference files, or theme-specific `.md` files automatically.

When a new pattern appears, first decide whether it can be handled by an existing rulebook.

Default preference:

1. Add a concise generic rule to an existing rulebook.
2. Update the controller only if needed.
3. Create a new rulebook file only if the behavior is broad, recurring, and too large for an existing file.
4. Create a new skill only if it represents a separate command or workflow.

Before creating a new file, ask the user for approval and explain why the existing files are not enough.

Do not create theme-specific rulebooks for one-off screens.

Do not create helper/reference/methodology files just because a screen produced a useful lesson.

Instead, summarize the reusable lesson and propose where it should be added.

## Standard Update Pattern

When adding a new check, make the behavior enforceable end-to-end without bloating `SKILL.md`.

1. Add the new detailed rule to the correct rulebook file.

Usually use:

`rulebook/filters.md`

2. If the new check affects scoring, update:

`rulebook/scoring.md`

3. If the new check affects artifact paths, folder structure, slug behavior, old-file migration rules, or `index.md`, update:

`/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` for global artifact standards and `rulebook/artifacts.md` only for `!gems`-specific artifact mechanics

4. If the new check affects deep scans, universe construction, market-cap estimation, screened-out handling, or Telegram summary behavior, update:

`rulebook/deep-mode.md`

5. If the new check affects command boundaries, recommendation boundaries, watchlist behavior, maintenance rules, or safe controller behavior, update:

`rulebook/maintenance.md`

6. Update the relevant rulebook file so the new check is enforceable end-to-end:

- what evidence qualifies
- what evidence downgrades or excludes
- whether the signal is core thesis evidence or supporting evidence only
- where it appears in candidate output
- how it affects classification
- how it appears in verification

7. Only update `SKILL.md` if the controller needs a new high-level pointer, the workflow changes, or the command behavior changes.

8. Do not paste long detailed rule sections into `SKILL.md` unless the user explicitly asks.

9. Bump the skill version when behavior changes.

10. Verify the new rulebook heading is present and that `SKILL.md` still acts as a concise controller.

11. Do not rerun `!gems` unless the user explicitly requested a scan.

## Current Quality-Control Themes

Existing checks include:

- Rerating and price-move status.
- Consolidation after major moves.
- Underdiscovered status.
- Information gap requirement.
- Non-obvious angle preference.
- Fundamental underreaction.
- Insider / ownership alignment.
- Liquidity / promotion risk.
- Special situations.
- Hidden-Gem Quality Score.
- Score modifiers.
- Adjacent theme handling.
- Enabling-layer discovery.
- Deep-mode response discipline.

## Output Discipline

Each new check should answer:

- What evidence qualifies.
- What evidence disqualifies or downgrades.
- Whether it is core thesis evidence or supporting evidence only.
- How it changes classification: clean candidate, researchable candidate, post-rerate watchlist, screened out / watch only, or momentum-only / exclude.
- Whether it should appear in the concise Telegram response, the saved artifact only, or both.

Do not let a supporting attribute become the whole thesis.

Examples of supporting attributes that are not enough by themselves:

- Small market cap.
- Insider buying.
- Illiquidity.
- A spin-off.
- A divestiture.
- A hot theme.
- A single customer announcement.
- Sector sentiment.
- Recent stock momentum.

A clean hidden-gem candidate should still have:

- Business validation.
- Underdiscovered evidence.
- A specific information gap.
- A non-obvious angle.
- Reasonable rerating / consolidation discipline.
- Manageable risk or a clearly explained fragility profile.

## Controller Discipline

`SKILL.md` should remain the concise controller for `!gems`.

When updating `!gems`:

- Do not remove behavior unless it already exists in a rulebook file.
- Do not weaken `!gems`.
- Do not delete rulebook files.
- Do not change artifact or index behavior unless explicitly requested.
- Do not change watchlist behavior unless explicitly requested.
- Keep `SKILL.md` concise.
- Keep detailed quality-control logic in rulebook files.
- Preserve the ability for `!gems` to say: `No clean pre-rerate candidates found in this theme right now.`
