---
name: gems
description: Use when the user invokes !gems, !gems [theme], !gems [theme] [subtheme], !gems [theme] --deep, or !gems [theme] [subtheme] --deep to discover potentially overlooked, misunderstood, underfollowed, or asymmetric small/mid-cap public companies for further research. Applies MIDAS hidden-gem quality controls and saves discovery artifacts to the Midas workspace.
version: 1.13.3
author: Midas / Hermes Agent
license: MIT
tags:
  - stocks
  - discovery
  - gems
  - small-cap
  - mid-cap
  - asymmetric
  - undervalued
  - underfollowed
  - midas
related_skills:
  - research
  - financials
  - thesis
  - risk
  - earnings
  - updates
  - full
  - wl
---

# MIDAS Gems Command Prompt

## Purpose

`!gems` is MIDAS' asymmetric small/mid-cap discovery engine. Use it to find potentially overlooked, misunderstood, underfollowed, or mispriced public companies that may deserve deeper research.

This skill produces **research candidates only**. It does not make investment recommendations, build a full research memo, add tickers to the watchlist, give Buy/Sell/Hold ratings, give price targets, give position sizing, or provide trade-execution advice.

A strong `!gems` candidate generally has:

* A real or credible business setup.
* Evidence of underdiscovered status.
* A clear information gap.
* A non-obvious angle beyond the headline theme.
* Improving fundamentals, execution, commercialization, or business quality.
* Rerating / consolidation discipline.
* Manageable risk or a clearly explained fragility profile.
* A filing-backed or disclosure-backed reason why the market may not fully recognize the setup yet.

## Invocation Triggers

Use this skill when the user runs any of:

* `!gems`
* `!gems [theme, sector, industry, or opportunity type]`
* `!gems [theme] [subtheme]`
* `!gems [theme] --deep`
* `!gems [theme] [subtheme] --deep`

Treat command names case-insensitively. Normalize typographic dashes from Telegram/mobile input: `—deep`, `–deep`, and `--deep` all mean Deep mode.

Examples:

* `!gems`
* `!gems space`
* `!gems semiconductors`
* `!gems semiconductor equipment --deep`
* `!gems semiconductors equipment --deep`
* `!gems ai infrastructure`
* `!gems energy infrastructure --deep`

## Required Rulebook Files

Before running `!gems`, use the approved rulebook files in:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/gems/rulebook/`

Treat those files as part of this skill:

* `rulebook/filters.md` — universe filters, market-cap rules, pre-revenue exceptions, exclusions, rerating status, underdiscovered status, information gap, non-obvious angle, ownership support, liquidity / promotion risk, special situations, asymmetry checks.
* `rulebook/scoring.md` — five-factor Hidden-Gem Quality Score, score bands, modifiers, ranking discipline, final classification.
* `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` — MIDAS-wide artifact standards.
* `rulebook/artifacts.md` — `!gems`-specific theme/subtheme parsing, artifact folder paths, slug rules, anti-confusion, duplicate handling, saved artifact requirements, `index.md` behavior.
* `rulebook/deep-mode.md` — `--deep` process, universe construction, market-cap estimation, screened-out handling, no-clean-candidate behavior, adjacent-theme handling, enabling-layer discovery, concise Telegram delivery.
* `rulebook/maintenance.md` — command boundaries, recommendation boundaries, watchlist boundaries, artifact behavior, maintenance rules.
* `rulebook/update-rulebook.md` — safely adding future quality-control checks without bloating `SKILL.md`.

Optional support references:

* `references/ai-energy-deep-screen.md` — session-derived notes for AI energy / data-center-electrification deep screens, including enabling-layer candidate types, SEC lookup fallback, evidence cues, and pitfalls.

Do not create new rulebook, reference, helper, methodology, or theme-specific `.md` files unless the user explicitly asks.

Only use the approved rulebook files listed above.

## Global Setup Classification

When this command produces an evaluation, ranking, final view, research lead, or setup summary, use the global Setup Classification standard:

`/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md`

Do not duplicate the classification definitions inside this skill.

## Command Modes

### Broad Mode

If the user runs `!gems`:

* MODE: Broad
* THEME: General
* SUBTHEME: None
* MAX_CANDIDATES: 5
* ARTIFACT_PATH: `workspace/gems/general.md`

Run a broad discovery scan across acceptable themes.

### Theme Mode

If the user runs `!gems [theme]`:

* MODE: Theme
* THEME: normalized theme
* SUBTHEME: General
* MAX_CANDIDATES: 5
* ARTIFACT_PATH: `workspace/gems/[theme]/general.md`

Run a focused discovery scan for that theme.

### Theme/Subtheme Mode

If the user runs `!gems [theme] [subtheme]`:

* MODE: Theme/Subtheme
* THEME: normalized theme
* SUBTHEME: normalized subtheme
* MAX_CANDIDATES: 5
* ARTIFACT_PATH: `workspace/gems/[theme]/[subtheme].md`

Run a focused discovery scan for that theme/subtheme.

### Deep Mode

If the user runs `!gems [theme] --deep` or `!gems [theme] [subtheme] --deep`:

* MODE: Deep
* THEME: normalized theme
* SUBTHEME: general or normalized subtheme
* MAX_CANDIDATES: 3
* ARTIFACT_PATH: `workspace/gems/[theme]/[general-or-subtheme].md`

Run a deeper discovery pass using `rulebook/deep-mode.md`. Prefer fewer, better-supported candidates over a padded list. It is acceptable to return: `No clean pre-rerate candidates found in this theme right now.`

## Process

### Step 1 — Identify Mode and Artifact Path

Identify the command mode, parse theme/subtheme, follow `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`, and use `rulebook/artifacts.md` only for `!gems`-specific aliases, folder structure, slug rules, anti-confusion rules, and final artifact path.

Do not create flat multi-word artifact files such as `semiconductor-equipment.md` or `defense-drones.md` for new scans. Use folder-based paths such as `workspace/gems/semiconductors/equipment.md` or `workspace/gems/defense/drones.md` unless maintaining an already-existing legacy artifact.

### Step 2 — Build Candidate Universe

Search for public companies that match the mode, theme, and subtheme. Use current sources.

Prioritize:

* SEC filings.
* Company investor relations pages.
* Investor presentations.
* Earnings releases.
* Company press releases.
* Reliable financial data.
* Credible market/news sources only when needed.

For deep mode, use `rulebook/deep-mode.md`.

Do not create or use additional reference files, theme-specific rulebooks, helper methodology files, or new `.md` rule files unless the user explicitly asks.

### Step 3 — Apply Universe Filters and Exclusions

Apply `rulebook/filters.md`. Remove or downgrade companies that violate MIDAS filters. Exclude disallowed sectors, hype-only names, poor-disclosure names, promotion-driven names, and companies with no credible commercialization path.

Allow pre-revenue or early-revenue exceptions only when permitted by `rulebook/filters.md`.

### Step 4 — Check Market Cap and Recent Stock Move

Estimate market cap and check recent stock performance where possible:

* 1-month performance.
* 3-month performance.
* 6-month performance.
* 1-year performance.
* YTD performance.

Classify rerating status using `rulebook/filters.md`. Do not treat a company as a clean hidden gem if it already doubled/tripled or is still vertical unless company-specific fundamentals clearly justify the move.

### Step 5 — Validate Business Quality

Classify business stage:

* Revenue-generating.
* Early-revenue.
* Pre-revenue / Early-Revenue Exception.

Check relevant business-quality evidence:

* Revenue trend.
* Profitability.
* Cash/debt.
* Cash burn.
* Dilution risk.
* Contracts.
* Backlog.
* Customer validation.
* Commercial milestones.
* Balance-sheet quality.
* Funding runway.

Do not run `!financials` unless the user explicitly asks.

### Step 6 — Apply Hidden-Gem Quality Controls

Use `rulebook/filters.md`. Each clean candidate should be tested for:

* Underdiscovered status.
* Clear information gap.
* Non-obvious angle.
* Fundamental underreaction.
* Insider / ownership alignment as supporting evidence only.
* Liquidity / promotion risk.
* Special situation status if relevant.
* 2-3 concrete asymmetry reasons.

Move weak, vague, promotional, fragile, post-rerate, or momentum-only names to `Screened Out / Watch Only`.

### Step 7 — Score and Rank Candidates

Use `rulebook/scoring.md`. Score each remaining candidate across:

1. Business Quality / Validation
2. Underdiscovered Status
3. Information Gap
4. Rerating / Consolidation Discipline
5. Risk / Fragility

Calculate `Total Hidden-Gem Score: [total] / 25` and apply score modifiers only when justified.

Classify each candidate as:

* Strong clean gem candidate.
* Researchable candidate.
* Watch only / needs more evidence.
* Screened out.

Rank candidates by hidden-gem quality, not just business quality, theme exposure, or stock momentum.

### Step 8 — Handle Existing Artifact and Save

Follow `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md` and use `rulebook/artifacts.md` for `!gems`-specific duplicate handling. Before saving, check whether the target artifact already exists.

Save the full detailed artifact to the correct path:

* Global broad scan: `workspace/gems/general.md`
* Theme broad scan: `workspace/gems/[theme]/general.md`
* Theme/subtheme scan: `workspace/gems/[theme]/[subtheme].md`

Create folders if needed. Do not delete or migrate existing artifacts unless the user explicitly asks.

### Step 9 — Update Index

Update `workspace/gems/index.md` using the `!gems`-specific index behavior in `rulebook/artifacts.md`, while preserving the global artifact standards in `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`.

Keep the index as a clean dashboard, not an append-only log. Track:

* Existing scans.
* Last run date.
* Artifact path.
* Candidate count.
* Highest-interest names.
* Cross-theme candidates.
* Suggested next step.

If an existing `index.md` already uses a structured table/dashboard, update or add the appropriate row in that structure and update `Recently Updated` / highest-interest sections as needed. Do not append orphan theme sections below the dashboard unless the index is already organized that way.

When updating `Current Highest-Interest Candidates`, de-duplicate by ticker. If the same ticker already appears from an overlapping theme, merge the `Appears In` paths and refresh the reason/next-step instead of adding a second row. This is especially important for cross-theme candidates such as robotics/AI/defense names.

### Step 10 — Respond Concisely

The Telegram/chat response should be short and practical. Do not paste the full artifact unless the user asks.

Include:

* Theme / mode.
* Top candidates or “no clean candidates.”
* Hidden-Gem Score.
* Rerating status.
* One-line reason.
* Screened out / watch-only names if important.
* Best next command.
* Saved artifact path.
* Updated index path.

End with exactly:

`Saved to: workspace/gems/[actual path].md`

`Updated index: workspace/gems/index.md`

## Concise Response Template

```md
MIDAS Gems — [Theme]

Top candidates:

1. [TICKER] — [Company]
   - Hidden-Gem Score: [X]/25
   - Status: [Strong clean gem / Researchable / Watch only]
   - Rerating: [Pre-Rerate / Early-Rerate / Post-Rerate]
   - Why it stands out: [one-line explanation]
   - Best next command: `!research [ticker]`

Screened Out / Watch Only:
- [TICKER] — [reason]

Best next command: `!research [ticker]`

Saved to: workspace/gems/[actual path].md
Updated index: workspace/gems/index.md
```

If no clean candidates are found:

```md
No clean pre-rerate candidates found in this theme right now.

The strongest companies found were already post-rerate, too obvious, too fragile, momentum-only, or lacked a clear information gap.

Saved to: workspace/gems/[actual path].md
Updated index: workspace/gems/index.md
```

## Boundaries

Do not give Buy, Sell, or Hold ratings.

Do not give price targets.

Do not give position sizing.

Do not give direct trade execution advice.

Do not call candidates recommendations.

Do not automatically add candidates to the MIDAS watchlist.

Do not run these commands unless the user explicitly asks:

* `!research`
* `!financials`
* `!thesis`
* `!thesis update`
* `!risk`
* `!earnings`
* `!updates`
* `!full`
* `!wl add`

It is okay to suggest the best next command.

Every material claim must be cited. Prioritize company filings, investor relations materials, earnings releases, investor presentations, and other primary sources. Use credible market data only when needed for market cap, recent stock moves, liquidity, analyst coverage, or peer comparison.

Prefer fewer, higher-quality candidates over a long weak list. Do not force candidates if the theme is already fully rerated or lacks clean hidden-gem setups.

## Verification Checklist

Before finalizing, verify:

* Command mode was identified.
* Theme/subtheme path was parsed correctly.
* Correct approved rulebook files were applied.
* No unapproved reference files, helper methodology files, or theme-specific rulebooks were created.
* Universe filters and exclusions were applied.
* Market cap rules were applied.
* Recent stock performance was checked.
* Rerating and consolidation status were checked.
* Underdiscovered status was checked.
* Information gap was checked.
* Non-obvious angle was checked.
* Fundamental underreaction was checked.
* Liquidity / promotion risk was checked.
* Special situation status was checked when relevant.
* Hidden-Gem Quality Score was calculated for every top candidate and displayed as `Hidden-Gem Score: [X]/25` in the chat response.
* Saved artifacts use `Total Hidden-Gem Score: [X] / 25`; never convert scores to `/10`, decimals, percentages, or omit the score from the concise response.
* Score modifiers were applied only when justified.
* Candidates were ranked by hidden-gem quality, not just business quality, theme exposure, or momentum.
* Post-rerate names were not presented as clean hidden gems unless remaining asymmetry was clearly explained.
* Weak or vague candidates were moved to `Screened Out / Watch Only`.
* Every material claim was cited.
* No Buy/Sell/Hold rating, price target, position sizing, or trade execution advice was included.
* No candidates were automatically added to the watchlist.
* Full artifact was saved to the correct path.
* `index.md` was updated.
* Final response ends with the saved artifact path and updated index line.
