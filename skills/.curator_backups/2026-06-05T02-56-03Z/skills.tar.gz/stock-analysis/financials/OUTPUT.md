# !financials Output Contract

## Command

Command: `!financials`

Skill File: `skills/stock-analysis/financials/SKILL.md`

Output File: `skills/stock-analysis/financials/OUTPUT.md`

Registry Entry: `docs/COMMAND_REGISTRY.md`

Status: `Draft`

---

## Registry Consistency

This output contract should match the command’s Registry Metadata block in the command `SKILL.md` and the command row in:

`docs/COMMAND_REGISTRY.md`

Expected registry values:

- Command: `!financials`
- Aliases: `None`
- Category: `Financial Analysis`
- Status: `Draft`
- Skill path: `skills/stock-analysis/financials/SKILL.md`
- Output path: `skills/stock-analysis/financials/OUTPUT.md`
- Eval file: `evals/financials.eval.md`
- Classification: `Optional`
- Scoring: `Optional`
- Metrics: `Required`
- Artifacts: `Yes`

If this output file and the registry disagree, treat that as registry drift.

---

## Purpose

This file defines the command-specific output contract for `!financials`.

`!financials` output should present a filing-backed financial statement and metric-quality review. It should focus on revenue, margins, profitability, operating cash flow, free cash flow, balance sheet, liquidity, debt, dilution, capital returns, segment financials, GAAP/non-GAAP quality, source limitations, financial red flags, and best next diligence command.

This file does not redefine global output standards.

---

## Output / Workflow Boundary

This file defines output shape only.

Workflow steps belong in:

`skills/stock-analysis/financials/SKILL.md`

Metric definitions belong in:

`rules/METRICS.md`

Source hierarchy belongs in:

`rules/SOURCES.md`

Artifact policy belongs in:

`rules/ARTIFACTS.md`

---

## Global Output Inheritance

`!financials` must follow the global MIDAS output rules in:

- `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`
- `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`
- `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`
- `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`
- `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

When classification or scoring is used, also follow:

- `/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md`
- `/home/jordan/.hermes/profiles/midas/rules/SCORING.md`

If this file conflicts with a global rule file, the global rule file wins unless the exception is explicitly documented here.

---

## Output Philosophy

`!financials` output should be:

- Filing-backed
- Metric-aware
- Concise by default
- Clear about GAAP vs non-GAAP
- Clear about unavailable, stale, or non-meaningful metrics
- Focused on financial-statement quality, not thesis promotion
- Specific about the best next diligence step

Avoid:

- Hype
- False precision
- Recommendation language
- Default cheap/expensive/reasonable valuation framing
- Default PEG metrics
- Full valuation models by default
- Full business-model, thesis, risk, or hidden-gem outputs
- Long filing dumps

---

## Supported Output Modes

- Compact: Yes — quick financial snapshot or triage, only when explicitly requested with words such as `compact`, `quick`, `brief`, `short`, `summary`, or `concise`.
- Standard: Yes — default section-complete financial review for every ticker/company.
- Full: Yes — expanded financial review using the Standard section skeleton, only when explicitly requested with mode tokens such as `full`, `deep`, `detailed`, `expanded`, `deep-dive`, or `deepdive`.

Default mode: `Standard` for `!financials [ticker/company]` across all tickers, including uppercase ticker symbols that are also ordinary words such as `NOW` and ticker-like words such as `DEEP`.

Mode selection should follow `rules/OUTPUT.md`, but Compact or Full mode must not be inferred from ticker text, company identity, data availability, popularity, market cap, filing complexity, prior examples, or prior outputs. The first ticker/company argument after `!financials` remains the security identifier even if it matches a mode alias; for example, `!financials DEEP` is Standard mode for ticker `DEEP`, while `!financials DEEP full` is Full mode. Sample tickers in examples are non-binding; parser behavior must remain ticker-agnostic.

If explicit Compact and Full mode tokens both appear in the same request, do not silently guess. Use existing conflict-handling behavior if available; otherwise return a clear mode-conflict message and ask the user to choose one mode.

## Unsupported Mode Behavior

If the user asks for an unsupported or unclear mode, use the closest supported mode when safe and state the assumption briefly. If no explicit mode word or flag appears outside the ticker/company text, use Standard mode.

---

## Required Top-Level Output Contract

Every successful `!financials` response should include a clear financial-quality conclusion, source basis, financial statement review, metric-quality caveats, and material financial red flags or source limitations when relevant. In default Standard mode, these elements must be placed inside the exact mandatory Standard template sections rather than adding extra top-level headings. The Standard title must say `Financial Analysis`, not `Financials Analysis`.

Do not show empty sections. If a section is not applicable, omit it unless the command contract requires a clear `Not disclosed`, `Not meaningful`, or `Not calculable` statement.

---

## Required Title Format

Use:

```md
# [TICKER] | [Company Name] Financial Analysis
```

Example:

```md
# [TICKER] | [Company Name] Financial Analysis
```

---

## Required Introduction Section

Use:

```md
## Introduction
```

The introduction should be short, usually 2–4 sentences. It should explain:

- What the report is reviewing
- Which source base is being used
- The scope of `!financials`
- That this is a financial-statement and metric-quality review, not a business-model report, full valuation, price target, or buy/sell recommendation

Example:

```md
This report reviews [Company Name]’s filing-backed financial statements and metric quality using the latest reviewed annual and interim filings. It focuses on revenue trends, margins, profitability, cash flow, balance sheet strength, dilution, capital returns, GAAP/non-GAAP quality, and financial red flags. It is financials analysis, not a business-model report, full valuation, price target, or buy/sell recommendation.
```

---

## Evidence / Source Notes

Use this section when external evidence, filings, market data, company documents, or user-provided documents support the review.

Required source behavior:

- State the source base and as-of periods.
- List latest annual and interim sources reviewed.
- Include filing dates, report periods, accession numbers, URLs, or source identifiers when available.
- Use line citations when available.
- If line citations are unavailable, cite filing name, filing date, period, section/table, accession number, or URL when available.
- Label source limitations.
- Do not present secondary-source metrics as filing-backed facts.

In default Standard mode, source-basis detail belongs inside `## Introduction` and/or `## Source Limitations`; do not add a separate `## Filings / Sources Used`, `## Sources`, or other source-only top-level heading unless the user asks for a source audit trail or Full mode needs it.

---

## Classification Behavior

Classification usage: `Optional`

This command does not classify setups by default.

If the user explicitly asks for classification or the output includes a final setup view, output may include:

```md
Setup Classification: [classification]
Setup Modifiers: [modifier 1], [modifier 2]
```

Do not force classification into a raw financial statement review.

---

## Scoring Behavior

Scoring usage: `Optional`

Standard mode includes the required `## Financial Quality Score` section as a concise financial-quality research prioritization score/grade when evidence supports it. This is not a full Global Research Score and must not be framed as a recommendation.

If broader scoring is requested, scoring must follow `rules/SCORING.md`. If the user asks for a full Global Research Score, prefer suggesting `!full` unless the requested scope is clearly limited to financial quality.

Do not use a score as a recommendation.

Score-line formatting in Standard mode is output-only: `[existing score]/10 - [Assessment]`. Keep the score and assessment generated from the financial evidence; do not hardcode scores, add a scoring rubric, or alter scoring logic.

---

## Metrics Behavior

Metrics usage: `Required`

Required metric areas:

- Revenue trends and growth, when calculable
- Gross margin, operating margin, and net margin where meaningful
- Profitability trend
- Operating cash flow
- Free cash flow and FCF definition
- Cash, debt, liquidity, and solvency context
- Share count and dilution
- Buybacks, dividends, and capital returns when disclosed
- Segment financials when disclosed
- GAAP vs non-GAAP distinction and reconciliation quality

Optional metric areas:

- ROE and ROA, with denominator basis labeled
- Interest coverage, with basis labeled
- FCF conversion, with caveat if net income is negative
- Capital-return yield, clearly labeled as such and not called TSR
- Limited valuation context only when requested or when current market data is gathered and labeled

Metric constraints:

- Follow `rules/METRICS.md`.
- Preserve period, source, unit, and GAAP/non-GAAP status when relevant.
- If a metric is not meaningful, stale, unavailable, or not calculable, say so.
- Do not use undefined metrics.
- Do not calculate FCF CAGR when FCF crosses zero, is negative, or is not meaningful; explain the trend instead.
- Do not include PEG as a default metric.
- Do not use default cheap/expensive/reasonable valuation language.

---

## Risks / Caveats

Required risk behavior:

- Include financial red flags based on reviewed evidence.
- Identify metric-quality, accounting-quality, liquidity, solvency, dilution, margin, cash-conversion, and source limitation issues when material.
- If no major red flags are identified, say so only after the relevant areas were checked.
- Do not turn the output into a downside-only `!risk` report.

In normal Standard and Full mode, financial red flags belong inside `## Source Limitations` or another required financials skeleton section. Do not add a separate default top-level heading such as `## Main Red Flags / Watchpoints`, `Main Red Flags / Watchpoints`, or `## Financial Red Flags` unless the user explicitly asks for a red-flag-focused report.

---

## Best Next Command

Best Next Command is optional in default Standard mode and must not add an extra top-level heading to the mandatory Standard template. When useful, include the next most logical MIDAS command inside an existing required Standard section, usually `## Source Limitations`. Make this context-aware using the ticker workspace state:

- If `workspace/tickers/[ticker]/research.md` exists, prefer `!thesis [TICKER]` to turn the business-model and financial evidence into a thesis view, or `!risk [TICKER]` if the financial review surfaced debt, dilution, liquidity, cash-conversion, accounting, or margin fragility.
- If `workspace/tickers/[ticker]/research.md` does not exist, prefer `!research [TICKER]` to build the business-model view behind the financials.
- Use `!full [TICKER]` only when the user wants the complete MIDAS packet.

Examples:

- `Best Next Command: !research [TICKER] to build the business-model view behind these financials.`
- `Best Next Command: !thesis [TICKER] because a research artifact already exists and the next step is thesis synthesis.`
- `Best Next Command: !risk [TICKER] because the financial review surfaced dilution, liquidity, cash-conversion, or accounting pressure points.`
- `Best Next Command: !full [TICKER] if you want the complete MIDAS packet.`

Do not recommend a next command when it would be noisy or unnecessary.

Use exactly one normal Standard/Full label when included: `Best Next Command:`. Do not use `Best next command:`, `Best next research command:`, `Best next diligence command:`, or `Best next step:` in normal Standard/Full outputs.

---

## Compact Output Contract

Use compact mode only when the user explicitly asks for speed, triage, or a short financial snapshot using terms such as `compact`, `quick`, `brief`, `short`, `summary`, or `concise`. Do not infer compact mode from ticker text, including `NOW`, or from the company, data availability, market cap, popularity, or prior examples.

Compact output should include:

1. Optional short identity line:
   - `[TICKER] | [Company Name] Compact Financial Snapshot`
2. `Bottom Line`
3. `Revenue / Margin Snapshot`
4. `Cash Flow / FCF Snapshot`
5. `Balance Sheet / Dilution Flags`
6. `Key Metric-Quality Caveat`
7. `Evidence Base / As-of`
8. `Best Next Command`, when useful

Compact mode must use the same FCF definition used by Standard/Full for the same company.

- If Standard/Full defines FCF as CFO minus capex, compact mode must use that same definition.
- If Standard/Full uses company-defined FCF, compact mode must label it as company-defined FCF.
- If Standard/Full adjusts FCF for company-specific items, compact mode must use the same adjustment or say FCF is not calculated in compact mode.
- If required FCF inputs are unavailable, compact mode must say: `FCF not calculated in compact mode because required inputs were not available.`

Compact Evidence Base / As-of behavior:

- Compact mode should include a short, user-facing `Evidence Base / As-of` line.
- Do not show raw SEC URLs, long source lists, raw source dumps, full filing citations, or detailed accession/URL blocks by default.
- Allowed compact evidence details: filing type, filing period, filing date, accession number when useful, source limitation, and whether market-data valuation was included or excluded.
- If the user asks for sources, links, citations, or an audit trail, compact mode may include links and fuller citation detail.
- Standard and Full modes may continue to include filing URLs and richer source detail.

Preferred compact evidence format:

```md
Evidence Base / As-of: FY[YYYY] Form 10-K filed [YYYY-MM-DD] and Q[Q] [YYYY] Form 10-Q filed [YYYY-MM-DD]; no current market-data valuation included.
```

Do not include real ticker examples in this reusable output contract. Ticker-specific examples belong only in evals, runtime test notes, or command-specific fixture notes.

Compact output should not include:

- Full filing walkthrough
- Full metric tables
- Full valuation model
- Setup classification or scoring unless explicitly requested
- Long source discussion
- Full SEC URLs by default
- Long source lists by default
- Raw source dumps by default
- Full filing citations by default
- Detailed accession/URL blocks unless the user asks for links, citations, sources, or an audit trail
- Artifact save confirmation by default
- Artifact no-save wording by default

Compact mode artifact behavior:

- Compact mode should not save an artifact by default.
- Compact mode should not show any artifact, save, or no-save line by default.
- Omit artifact wording entirely in compact output unless:
  - The user explicitly asks to save compact output.
  - The user asks whether compact output saved.
  - Artifact saving fails after being requested.
  - The command is running an artifact test.

If the user explicitly asks to save compact output and the write succeeds, use:

```md
Saved to: workspace/tickers/[ticker]/financials.compact.md
```

If the user asks whether compact output saved and it did not, use:

```md
No artifact saved.
```

### Compact Format

```md
## [TICKER] | [Company Name] Compact Financial Snapshot

Bottom Line: [short financial-quality conclusion]

Revenue / Margin Snapshot:
- [Key revenue/margin point with period/source]

Cash Flow / FCF Snapshot:
- [CFO and FCF point; define FCF]

Balance Sheet / Dilution Flags:
- [Cash/debt/liquidity/share count point]

Key Metric-Quality Caveat:
- [GAAP/non-GAAP, missing data, stale data, or not-meaningful metric caveat]

Evidence Base / As-of: [FY/current interim filing type, period, filing date, optional accession if useful, and whether current market-data valuation is included/excluded; no raw URLs by default]

Best Next Command: [optional]
```

---

## Standard Output Contract

Standard mode is the mandatory default for `!financials [ticker]` across all tickers and companies. Use this section as the source of truth for normal/default output. No ticker may receive a custom abbreviated structure unless compact mode is explicitly requested.

Parser/output safeguard:

- Treat the first ticker/company argument after `!financials` as the security identifier.
- Uppercase ticker symbols such as `NOW` must not be interpreted semantically as a time keyword, shorthand, or mode.
- Compact output is allowed only when an explicit compact-mode word or flag appears outside the ticker text, such as `compact`, `quick`, `brief`, `short`, `summary`, or `concise`.
- Do not infer compact mode from ticker symbol, company, data availability, market cap, popularity, or prior examples.

Standard mode should be section-complete but bounded. It should not become a full filing audit, full valuation, full thesis, or filing dump.

Standard output must use this exact section order:

1. `# [TICKER] | [Company Name] Financial Analysis`
2. `## Introduction`
3. `## Revenue / Growth`
4. `## Profitability / Margins`
5. `## Cash Flow`
6. `## Balance Sheet`
7. `## Share Count / Dilution`
8. `## GAAP vs Non-GAAP / Metric Quality`
9. `## Financial Quality Score`
10. `## Source Limitations`
11. Final line: `Saved to: workspace/tickers/[ticker]/financials.md`

For normal Standard output, `Saved to: workspace/tickers/[ticker]/financials.md` must appear exactly once and only as the final line of the user-facing response after the report body is complete. It must not appear in or immediately after `## Introduction`, before `## Source Limitations`, before `Best Next Command:` when that label is included, or in a separate default Artifact section.

### Standard Format

```md
# [TICKER] | [Company Name] Financial Analysis

## Introduction
[2–4 sentence scope statement covering filings reviewed/source base, financials scope, and non-recommendation boundary. Mention the latest annual/interim sources or source basis here rather than creating a separate sources section.]

## Revenue / Growth
[Revenue trend, period labels, drivers, and calculations where useful.]

## Profitability / Margins
[Gross/operating/net margin and profitability trend where meaningful.]

## Cash Flow
[CFO, capex, FCF definition, FCF trend, and cash-conversion caveats.]

## Balance Sheet
[Cash, debt, net debt/cash, liquidity, maturities/covenants if disclosed.]

## Share Count / Dilution
[Share count trend, dilution, buybacks, dividends, and whether capital returns appear covered by earnings or cash flow.]

## GAAP vs Non-GAAP / Metric Quality
[Metric definitions, reconciliations, recurring adjustments, accounting-quality caveats, and source quality.]

## Financial Quality Score
[existing score]/10 - [Assessment]

Keep the generated financial-quality score and assessment; this is formatting only. Use a plain hyphen after the score and write the assessment cleanly after the dash, e.g. `8/10 - Strong financial quality, with margin/SBC/capital-return watchpoints.` Do not hardcode a score, add a new rubric, or change scoring logic. If evidence is insufficient to score, state why rather than inventing precision.

## Source Limitations
[Missing filings, stale data, unavailable metrics, source limitations, and any material red flags or disconfirming financial evidence that affect confidence.]

Financial Red Flags / Watchpoints:
- [watchpoint, if material]
- [watchpoint, if material]

Best Next Command: [optional context-aware next command]

Saved to: workspace/tickers/[ticker]/financials.md
```

---

## Full Output Contract

Use full mode when the user explicitly asks for a deep financial review, full financial artifact, or expanded audit trail using a Full-mode token such as `full`, `deep`, `detailed`, `expanded`, `deep-dive`, or `deepdive` outside the first ticker/company argument.

Full output must not become:

- `!full`
- `!research`
- `!thesis`
- `!risk`
- A valuation model
- A price target
- A buy/sell recommendation

Full mode saves by default to:

`workspace/tickers/[ticker]/financials.md`

### Full Saved Artifact Structure

Full mode uses the Standard section order as the required saved-artifact skeleton:

1. `# [TICKER] | [Company Name] Financial Analysis`
2. `## Introduction`
3. `## Revenue / Growth`
4. `## Profitability / Margins`
5. `## Cash Flow`
6. `## Balance Sheet`
7. `## Share Count / Dilution`
8. `## GAAP vs Non-GAAP / Metric Quality`
9. `## Financial Quality Score`
10. `## Source Limitations`
11. Final line: `Saved to: workspace/tickers/[ticker]/financials.md`

Full mode should expand inside these sections with deeper financial-statement analysis and must not become `!full`, `!research`, `!thesis`, `!risk`, a valuation model, price target, or buy/sell recommendation, including where available:

- Multi-year financial trends when available
- Quarter/YTD vs annual comparisons
- Segment financials when disclosed
- Working-capital and cash-conversion quality
- FCF definition and calculation
- Debt, liquidity, maturities, and covenants when disclosed
- Share-count, dilution, SBC, and repurchase/issuance detail
- GAAP vs non-GAAP reconciliation quality
- Accounting-quality red flags
- Source limitations and citation/source notes
- Optional limited valuation context only if current market data is gathered and labeled

Optional Full-only top-level headings may be added only when useful for source/audit trail or red-flag expansion. They must not replace the required saved-artifact sections above.

### Full User-Facing Response Contract

Full mode must show the expanded financial review in the user-facing final response by default.

A normal `!financials [ticker] full` response must not be a completion receipt, artifact summary, or key-points summary. The user-facing response itself must contain the expanded Full report.

Full mode must preserve the required Standard skeleton:

1. `# [TICKER] | [Company Name] Financial Analysis`
2. `## Introduction`
3. `## Revenue / Growth`
4. `## Profitability / Margins`
5. `## Cash Flow`
6. `## Balance Sheet`
7. `## Share Count / Dilution`
8. `## GAAP vs Non-GAAP / Metric Quality`
9. `## Financial Quality Score`
10. `## Source Limitations`
11. `Saved to: workspace/tickers/[ticker]/financials.md`

Full mode should expand inside those sections with deeper financial analysis, including multi-year trends, quarterly/YTD vs annual comparisons, segment financials, working-capital and cash-conversion quality, capex and investment intensity, liquidity, maturities/covenants, dilution/SBC, capital returns, non-GAAP reconciliation quality, and accounting-quality red flags when available.

If runtime limits prevent displaying a complete Full report, return a bounded Full report with all required sections. If even that cannot be completed, fail honestly and do not claim Full mode passed.

---

## Ticker Consistency Finalization

Before saving or sending a Standard/Full output, the active user ticker/company, resolved issuer, report title, artifact path, saved-path line, and source base must all match. If any element does not match, hard stop and regenerate for the active ticker from sources; do not patch only the title/path.

---

## Artifact Behavior

Writes artifacts: `Yes`

Artifact behavior follows:

`/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

Default artifact behavior:

- Standard mode saves by default when complete.
- Full mode saves by default when complete.
- Compact mode does not save by default.
- Compact mode saves only when explicitly requested.
- Compact mode should not show any artifact, save, or no-save line by default.

Artifact locations:

- Standard / Full: `workspace/tickers/[ticker]/financials.md` using the canonical ticker normalization from `rules/ARTIFACTS.md`.
- Compact when explicitly saved: `workspace/tickers/[ticker]/financials.compact.md`

When Standard or Full artifact is written, output should include exactly one saved-path confirmation, and in normal Standard/Full user-facing output it must be the final line:

```md
Saved to: workspace/tickers/[ticker]/financials.md
```

When compact output is explicitly saved and the write succeeds, output should include:

```md
Saved to: workspace/tickers/[ticker]/financials.compact.md
```

When the user asks whether compact output saved and it did not, output should include:

```md
No artifact saved.
```

Do not claim an artifact was written unless it was actually created.
Do not use artifact/no-save wording in compact output unless the user explicitly asks to save compact output, asks whether it saved, artifact saving fails after being requested, or the command is running an artifact test.
Do not use old artifact paths that place ticker folders directly under the workspace root.

---

## Failure Output Contract

Use failure output when the command cannot complete its intended task.

Common failure cases:

- Missing ticker/company/input
- Ambiguous ticker/company identity
- SEC or primary-source filings unavailable
- Latest financial source too stale for the requested claim
- Metric cannot be calculated or is not meaningful
- Market data unavailable when valuation context is requested
- Artifact write failure
- Current output contaminated by unrelated prior-run state

Failure output should include:

1. What failed
2. Why it failed
3. What evidence or input is missing
4. Best next step

Include artifact/no-save wording in failure output only when artifact state is user-relevant. For compact mode, omit `No artifact saved.` unless the user explicitly asked to save compact output, asked whether compact output saved, artifact saving failed after being requested, or the command is running an artifact test.

Failure format:

```md
Unable to complete: [specific failure]
Reason: [clear explanation]
Missing or needed: [input/evidence/data]
Best next step: [neutral command or user action]
[No artifact saved, only when artifact state is user-relevant.]
```

For unresolved company/ticker failures, use:

```md
Unable to complete: company identity could not be resolved.

Reason: I could not match [input] to a public-company ticker, legal company name, or SEC filer.

Missing or needed: a valid public-company ticker or exact company name.

Best next step: Send a valid public-company ticker or exact company name.

[No artifact saved, only when artifact state is user-relevant.]
```

Recovery language must be neutral. Do not suggest a specific real ticker or company as an example unless the user explicitly asked for examples, the ticker/company is part of the current request, or the output is command help/menu text rather than a failed company lookup.

Do not fabricate results to avoid a failure state.

Do not save incomplete output as `financials.md`.

---

## Command-Specific Required Sections

Required for Standard mode, in this exact order:

- `# [TICKER] | [Company Name] Financial Analysis`
- `## Introduction`
- `## Revenue / Growth`
- `## Profitability / Margins`
- `## Cash Flow`
- `## Balance Sheet`
- `## Share Count / Dilution`
- `## GAAP vs Non-GAAP / Metric Quality`
- `## Financial Quality Score`
- `## Source Limitations`
- Final line: `Saved to: workspace/tickers/[ticker]/financials.md` after successful save

Optional content may be included inside the required sections when useful, but do not add or substitute a compact-style structure by default:

- Segment financials, if disclosed
- Financial red flags or disconfirming evidence, placed inside `## Source Limitations` or another required Standard/Full skeleton section rather than as a separate default top-level heading
- Limited valuation context, only when requested or when current market data is gathered and labeled
- Setup Classification, only when requested or when a final setup view is included
- Best Next Command, when useful, using the exact label `Best Next Command:` in normal Standard/Full output and placing it inside an existing required section

Prohibited by default:

- Price targets
- Buy/sell/hold recommendations
- Default cheap/expensive/reasonable language
- Default PEG
- Full business-model report
- Bull/base/bear thesis
- Downside-only risk report
- Complete MIDAS packet
- Hidden-gem ranking

---

## Command-Specific Table Standards

Use tables only when they improve scanability.

Required tables: `None`

Optional tables:

- Compact financial trend table
- Segment financial table
- Debt maturity table
- Share-count / capital-return table
- GAAP vs non-GAAP reconciliation summary

Table rules:

- Keep tables compact.
- Include period/date context.
- Include units.
- Label GAAP vs non-GAAP.
- Do not show unavailable metrics as known.
- Use `Not disclosed`, `Not meaningful`, or `Not calculable` when needed.

---

## Command-Specific Language Standards

Preferred language:

- `Financial quality appears...`
- `The filing-backed evidence shows...`
- `FCF is defined here as...`
- `This metric is not meaningful because...`
- `Source limitation: ...`
- `Best Next Command: ...`
- `What prevents the financials from being decisive by themselves: ...`
- `Best Next Command: ...`

Guardrail-style response language:

- If the user asks whether to buy, sell, hold, size, or requests a price target, reframe as research only.
- Do not advise a personal investment decision.
- State that `!financials` can assess financial quality, metric quality, and information gaps, but cannot provide buy/sell/hold instructions, position sizing, or price targets.
- Prefer the heading/phrase `What prevents the financials from being decisive by themselves:` over `What stops me from calling...` or similar personal-decision language.
- Prefer `Best Next Command:` over `Best next diligence before any decision:` in normal Standard/Full output. Guardrail-only refusals that are not a completed Standard/Full report may use neutral research-command wording when needed, but must not imply buy/sell/hold, sizing, or price-target advice.

Avoid:

- `Buy`, `Sell`, `Hold`, `Strong Buy`
- `Price target`
- `Cheap`, `expensive`, or `reasonable` as default valuation conclusions
- `Guaranteed`, `no-brainer`, `must own`, or hype language
- Treating adjusted metrics as GAAP
- Treating valuation context as a recommendation
- Personal decision language that implies MIDAS is advising what the user should do with capital

Required caveat in Standard `## Introduction`:

- State that the report is a financial-statement and metric-quality review, not a full valuation, price target, or buy/sell recommendation.

---

## Examples Needed

Examples and regression cases live in:

`evals/financials.eval.md`

The eval file should test that this output contract is followed.

---

## Placeholder Cleanup Rule

This Draft output file should not contain unresolved template placeholders. Before marking `!financials` Active, confirm evals pass and the command registry matches the metadata.

---

## Stability Checklist

Before marking this output contract Active, confirm:

- It references global output rules instead of duplicating them.
- It defines compact, standard, and full output behavior.
- It clearly states classification is optional.
- It clearly states scoring is optional.
- It clearly states metrics are required.
- It clearly states artifacts are written in Standard/Full by default.
- It defines failure behavior.
- It avoids command workflow instructions that belong in `SKILL.md`.
- It avoids source hierarchy rules that belong in `rules/SOURCES.md`.
- It avoids scoring rubric details that belong in `rules/SCORING.md`.
- It avoids metric formula libraries that belong in `rules/METRICS.md`.
- Registry metadata matches `docs/COMMAND_REGISTRY.md`.
- Unsupported or unclear mode behavior is defined.
- Empty sections are omitted unless explicitly required.
- Artifact paths use `workspace/tickers/[ticker]/financials.md`.
- This file defines output shape only and does not duplicate command workflow logic.
