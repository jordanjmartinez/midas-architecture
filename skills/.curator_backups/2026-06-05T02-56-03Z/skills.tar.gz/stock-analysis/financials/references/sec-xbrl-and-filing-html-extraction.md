# SEC XBRL + Filing HTML Extraction Notes for `!financials`

Status: Promoted Command Reference. Narrow trigger only; supports `!financials` extraction/sector handling and defers to `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`, `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`, `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`, `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`, and `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`. This file is not global MIDAS policy and must not override command `SKILL.md` or `OUTPUT.md`.

Use this reference when producing filing-backed financial reviews from SEC filings where standard financial statement facts are available but segment/revenue-mix detail is embedded in filing HTML.

## Durable workflow pattern

1. Resolve ticker to CIK using SEC `company_tickers.json`.
2. Use `data.sec.gov/submissions/CIK##########.json` to identify latest 10-K / 10-Q, filing dates, report periods, accessions, and primary documents.
3. Check for nearby amended filings (`10-K/A`, `10-Q/A`) and note their existence when relevant. Do not assume the original filing is final for amended items.
4. Pull SEC Company Facts / Inline XBRL for core GAAP totals:
   - `Revenues`
   - `NetIncomeLoss`
   - `IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest` when operating income is not available
   - `NetCashProvidedByUsedInOperatingActivities`
   - `CashAndCashEquivalentsAtCarryingValue`
   - `Assets`, `Liabilities`
   - `WeightedAverageNumberOfSharesOutstandingBasic`
   - `WeightedAverageNumberOfDilutedSharesOutstanding`
   - `ShareBasedCompensation`
   - buyback / repurchase concepts when available
5. Use filing HTML text extraction for tables not easily represented as common US-GAAP concepts:
   - revenue disaggregation by product/source
   - segment tables and product/service splits
   - subscription / professional-services mix, ARR, dollar-based net retention, RPO, deferred revenue, and region tables for software companies
   - backlog / remaining performance obligation tables and recognition timing
   - customer concentration / accounts receivable concentration tables
   - key operating metrics
   - credit facilities / liquidity footnotes
   - senior notes, convertible notes, conversions, capped calls, and debt extinguishment footnotes
   - stock-based compensation by function, buyback authorizations, subsequent repurchases, and post-period acquisition cash outflows
   - ATM/equity offering, forward-sale, share-count, warrant, and equity award footnotes
   - post-quarter financing filings when they materially alter liquidity/dilution capacity
6. When SEC Company Facts has sparse or issuer-specific XBRL tags, do not stall on the API. Fall back to the latest filing HTML and extract targeted statement/footnote tables with filing date, accession, URL, and local line/table evidence. Capital-intensive/custom-tag issuers often disclose the useful financial story in inline tables even when standard facts are incomplete.
7. If a table parser dependency such as pandas is unavailable, do not stop or save a thin artifact. Use plain filing text extraction instead: fetch the SEC filing HTML, strip it with BeautifulSoup or similar, search for distinctive headings/phrases, and extract bounded snippets around the relevant tables. The durable lesson is the fallback pattern, not the missing dependency.
8. For software/subscription companies, explicitly bridge GAAP results to cash-flow quality:
   - compare revenue growth with ARR/RPO/deferred-revenue growth when disclosed
   - separate GAAP operating/net losses from CFO/FCF strength
   - calculate SBC as a percentage of revenue when SBC is material
   - caveat CFO/FCF when deferred revenue and subscription billing mechanics are a major source of cash conversion
   - treat repurchase authorization as dilution mitigation only after checking actual repurchase activity and share-count/SBC trends
9. Calculate only simple, explicitly labeled metrics:
   - revenue growth
   - gross margin when cost of revenue/gross profit is clearly disclosed
   - operating margin and net margin when operating loss/net loss are disclosed
   - segment gross margins when segment revenue and cost/gross profit are disclosed
   - expense ratio when useful
   - FCF = CFO minus property/software/equipment purchases minus capitalized internal software, if both are disclosed; if capex line is titled “purchases of property, equipment and software,” use that exact label and state the formula
   - net cash/liquidity = cash + marketable securities minus balance-sheet borrowings when useful
   - dilution = weighted-average shares YoY and/or period-end shares sequentially when equity issuance is material
8. Preserve period/source labels for every material number.

## Important pitfall: financial / brokerage platforms

For brokerages, fintech platforms, banks, insurers, and other balance-sheet businesses, do not treat CFO / FCF like industrial or software owner earnings without a caveat. User payables, segregated cash, securities borrowed/loaned, margin lending, credit-card receivables, and other balance-sheet flows can dominate reported CFO.

Preferred wording:

> FCF is mechanically positive/negative by CFO minus capex, but cash-flow quality is affected by brokerage balance-sheet mechanics and should not be read like simple owner earnings.

## Important pitfall: no standard gross margin

Some financial platforms report net revenues and operating expenses rather than cost of revenue / gross profit. If cost of revenue is not clearly disclosed, say gross margin is not meaningful rather than forcing a software-style gross margin.

## Important pitfall: growth funded by equity issuance

For unprofitable issuers using ATM programs, converts, forward sales, or repeated equity offerings, separate liquidity strength from internally generated financial strength. A large cash balance can be real and useful, but if it was created by equity issuance while CFO/FCF remain negative, the financial read should explicitly discuss dilution, share-count growth, and whether backlog/revenue conversion is reducing dependence on capital markets.

Checklist:

- Compare cash + marketable securities to debt / convertible notes.
- Show recent ATM proceeds and share issuance when disclosed.
- Check post-quarter prospectus supplements / 8-Ks for new ATM capacity.
- Calculate weighted-average share growth YoY and period-end share growth sequentially when material.
- Frame strong liquidity as a positive while flagging equity-funded liquidity as a quality caveat.

## Output discipline

- If a Form 10-K/A or 10-Q/A exists, either use the amended filing for affected claims or explicitly state that the amendment was only noted and not separately parsed.
- Do not include valuation unless market data was gathered with as-of dates.
- Do not save incomplete output as `financials.md`.
