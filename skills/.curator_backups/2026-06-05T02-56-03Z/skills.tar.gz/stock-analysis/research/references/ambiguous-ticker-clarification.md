# Ambiguous / Unresolved Ticker Clarification Pattern

Use this reference when `!research` cannot verify the requested ticker/company or when the input appears to be a typo that maps to multiple plausible public companies.

## Trigger

- SEC ticker data, exchange pages, or issuer searches do not confirm the requested ticker.
- The input resembles multiple tickers or names, e.g. one-letter typo candidates.
- A clarification prompt has already been sent and no explicit user answer is available.
- Temporary research has been gathered for a likely candidate before identity is confirmed.

## Required Behavior

1. Treat identity resolution as a hard prerequisite for Standard/Full research output.
2. If there is no clear issuer match, state that the ticker/company could not be verified and ask for clarification.
3. Offer likely alternatives only as options, not substitutions.
4. Do not save `workspace/tickers/[candidate]/research.md` for a likely candidate unless the user explicitly confirms that candidate or the command input itself clearly identifies it.
5. Do not write phrases like “resolved per your clarification” unless the user actually supplied a clarification in the active conversation.
6. If tentative evidence has already been collected for a candidate, label it as tentative internal work and either discard it or continue only after confirmation.
7. If the user issues a new command before clarifying, abandon the unresolved prior ticker unless the new command resolves it.

## Safe Output Pattern

```md
Could not verify: [INPUT] as a public-company ticker from the checked primary sources.

Possible matches:
- [TICKER] — [Company]
- [TICKER] — [Company]

Best next step: confirm the exact ticker/company and I’ll run the filing-backed report.
```

## Pitfall

Do not let tool/context compaction, tentative downloaded filings, or a likely typo candidate create a false confirmation. A final `!research` artifact must correspond to a verified target.