# Artifact overwrite safety for `!research`

Use this when saving the canonical Standard/Full artifact at `workspace/tickers/[ticker]/research.md`.

## Why this exists

During a HOOD `!research` run, the write tool warned that `research.md` had been modified by a sibling subagent while the current agent had not read it. The command's default behavior is still to replace the canonical generated artifact, but a write warning is a signal to inspect before overwriting.

## Safe pattern

1. Build the final clean Markdown artifact in working context or a temp file.
2. Before writing `workspace/tickers/[ticker]/research.md`, check for overwrite risk:
   - a write/read tool warning about sibling or user modification;
   - unexpected existing content/customization;
   - user explicitly asked to preserve versions;
   - concurrent/subagent workflow is active.
3. If overwrite risk exists, read the existing artifact before writing.
4. Preserve the normal canonical path unless the user asked for versioning, but do not silently discard newer user/sibling work.
5. After writing, read back the saved artifact header/first section to verify the correct ticker, title, sources, and saved path.

## What not to do

- Do not let Compact mode overwrite `research.md`; compact remains chat-only by default or uses `research.compact.md` only on explicit save request.
- Do not create a new versioned artifact unless the user requested preservation or the existing artifact contains material newer work that should not be replaced.
- Do not ignore tool warnings about sibling/user modification.