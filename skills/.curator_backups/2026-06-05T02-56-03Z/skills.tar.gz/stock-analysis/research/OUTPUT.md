# MIDAS Command Output Contract — !research

Template source: `/home/jordan/.hermes/profiles/midas/templates/COMMAND_OUTPUT_TEMPLATE.md`

---

## Command

Command: `!research`

Skill File: `skills/stock-analysis/research/SKILL.md`

Output File: `skills/stock-analysis/research/OUTPUT.md`

Registry Entry: `docs/COMMAND_REGISTRY.md`

Status: `Active`

---

## Registry Consistency

This output contract should match the command’s Registry Metadata block in `skills/stock-analysis/research/SKILL.md` and the command row in:

`docs/COMMAND_REGISTRY.md`

Check:

- Command name: `!research`
- Skill path: `skills/stock-analysis/research/SKILL.md`
- Output path: `skills/stock-analysis/research/OUTPUT.md`
- Status: `Active`
- Classification usage: `Optional`
- Scoring usage: `Optional`
- Metrics usage: `Optional`
- Artifact behavior: `Yes`

If this output file and the registry disagree, treat that as registry drift.

---

## Purpose

This file defines the command-specific output contract for `!research`.

It explains what the business-model research note should return, which output modes it supports, which sections are required or prohibited, and how artifacts, optional classifications, optional scores, optional metrics, sources, risks, and failures should appear.

This file should not redefine global output standards.

---

## Output / Workflow Boundary

This file defines output shape only.

Workflow steps belong in `skills/stock-analysis/research/SKILL.md`.

Do not add source-gathering workflow, scoring workflow, research workflow, metric-calculation workflow, or artifact-writing procedure here unless it is strictly about how the result appears in the output.

This file should answer:

- What sections should appear?
- Which sections are required, optional, or prohibited?
- Which output modes are supported?
- How should scores, classifications, metrics, sources, risks, failures, and artifacts be displayed?

This file should not answer:

- How sources are gathered
- How companies are screened
- How scores are calculated
- How metrics are computed
- How artifacts are written
- How the command routes or executes

---

## Global Output Inheritance

`!research` must follow the global MIDAS output rules in:

- `rules/GLOBAL.md`
- `rules/OUTPUT.md`

Depending on command behavior, it may also inherit from:

- `rules/SOURCES.md`
- `rules/CLASSIFICATIONS.md`
- `rules/SCORING.md`
- `rules/METRICS.md`
- `rules/ARTIFACTS.md`

If this file conflicts with a global rule file, the global rule file wins unless the exception is explicitly documented here.

---

## Output Philosophy

`!research` output should be:

- Plain-English and filing-backed.
- Useful before it is exhaustive.
- Clear about what is disclosed, inferred, and not disclosed.
- Compact by default only when requested; standard mode is the default.
- Specific enough to support deeper diligence with `!financials`, `!thesis`, `!risk`, or `!full`.

Avoid:

- Hype.
- False precision.
- Unsupported conviction.
- Long generic market commentary.
- Repeating global rule language.
- Dumping raw filing excerpts without interpretation.
- Turning business-model research into a full financial analysis or valuation model.

---

## Supported Output Modes

`!research` supports the following output modes:

| Mode | Supported? | Use Case |
|---|---:|---|
| Compact | Yes | Fast business-model triage or quick company overview |
| Standard | Yes | Default filing-backed business-model research note |
| Full | Yes | Deeper business-model note with expanded evidence, citations, risks, and optional setup view |

Default mode:

`Standard`

Mode-boundary enforcement:

- Compact mode = short business-model snapshot.
- Standard mode = default filing-backed business-model report.
- Full mode = expanded business-model report.
- `!research [ticker]` must use Standard mode unless the user explicitly asks for compact, quick, brief, short, full, deep, detailed, or similar mode wording.
- Compact summaries are allowed only on explicit compact-style request or when the command enters a concise failure state.
- Standard mode must not collapse into a citation-free compact summary.
- Standard mode must include the command-specific required section list below, including report title, Introduction, source-visible sections, and saved-path confirmation.
- Standard and Full mode must begin the visible report body with the required report title and `Introduction` before `Bottom Line`.
- Compact mode may start with `Bottom Line`, does not require the full report title or `## Introduction`, and may optionally begin with a short identity line such as `[TICKER] | [Company Name] Compact Business Snapshot`.

Mode selection should follow `rules/OUTPUT.md`.

## Unsupported Mode Behavior

If the user asks for an unsupported output mode:

- Use the closest supported mode when safe, or
- Explain that the mode is not supported for this command.

Because compact, standard, and full are all supported, unsupported-mode failures should be rare.

Do not pretend to support an output mode that this command does not support.

---

## Required Top-Level Output Contract

Every successful `!research` response should include the standard sections unless the user requests compact mode or the command cannot complete.

Do not show empty sections.

If a section is not applicable, omit it unless the command contract requires a clear `Not disclosed` or `Not applicable` statement.

Do not leave placeholder text in active command outputs.

### 1. Report Title

For Standard and Full mode, the visible report body must begin with a report title before `Introduction` and `Bottom Line`. Compact mode does not require this full report title.

Required title format:

`# [TICKER] | [Company Name] Business Analysis`

Example:

`# HOOD | Robinhood Markets, Inc. Business Analysis`

If a Standard or Full saved artifact includes the metadata header required by `rules/ARTIFACTS.md`, preserve that artifact header first, then begin the visible report body with this required report title.

### 2. Introduction

For Standard and Full mode, include a short `## Introduction` section before `Bottom Line`. Do not force `## Introduction` in compact mode unless the user explicitly asks for report-style compact output.

The introduction should usually be 2-4 sentences and explain:

- What the report is analyzing.
- Which source base is being used.
- The scope of `!research`.
- That the command is focused on business-model research, not full financial analysis, valuation, or buy/sell advice.

Example:

`This report reviews Robinhood’s filing-backed business model using the latest reviewed 10-K and 10-Q. It focuses on how the company makes money, customer/end-market exposure, revenue character, pricing power, cyclicality, recent business trends, and key business-model risks. It is a business-model research note, not a full valuation or buy/sell recommendation.`

### 3. Bottom Line

For `!research`, this should state the practical business-model conclusion in 1-3 sentences. In Standard and Full mode, it must appear after the required report title and `Introduction`. Compact mode may start with `Bottom Line` unless the user asks for report-style compact output.

Format:

`Bottom Line: [1-3 sentence business-model conclusion]`

---

### 4. Command Result

The main result should be labeled as a business-model research note.

Use the Standard section list unless Compact or Full mode changes depth.

Required Standard/Full content:

- Report title.
- Introduction.
- Filing/source list.
- Plain-English company summary.
- Business model and monetization.
- Segments or revenue categories.
- Customers/end markets.
- Geography.
- Revenue recurrence, transactionality, cyclicality, or project orientation.
- Filing-backed pricing-power view or explicit limitation.
- Recession/cyclicality view.
- Recent business-performance snapshot.
- Key business risks/red flags.
- Bottom-line business-model view.

Required Compact content is defined separately in the Compact Output Contract and does not require the full report title or `## Introduction`.

Optional content:

- Setup Classification, Setup Modifiers, and Evidence Confidence if the output includes a setup or final research view.
- Lightweight business-performance metrics that support the business-model discussion.
- A separate Artifact section only when there is extra artifact context beyond a normal save confirmation.

Do not include:

- Buy/Hold/Sell language.
- Price-target-style recommendation.
- Full valuation model.
- Full financial statement analysis.
- Hidden-gem ranking.
- Tracker/copy-trading framing.

---

### 5. Evidence / Source Notes

Use this section because `!research` uses external evidence, filings, market data, company documents, or user-provided documents.

Follow:

- `rules/SOURCES.md`
- `rules/OUTPUT.md`

Required source behavior:

- State which primary filings or official company sources were used.
- For SEC filers, include the latest 10-K and latest 10-Q when available.
- Include filing dates, report periods, accession numbers, or URLs where available.
- If a 10-K, 10-Q, or primary-source equivalent is unavailable, state the limitation.
- Every material factual claim should remain citation-backed.
- If line citations are available, use them; otherwise cite filing name, filing date, section, accession number or URL when available.
- If a relevant business-model fact is not disclosed in reviewed filings, explicitly say `not disclosed in the reviewed filings`.

Example source note language:

`Evidence base: latest Form 10-K and latest Form 10-Q as of [date], plus company materials where noted.`

---

### 4. Classification Behavior

Use this section only if the command applies setup classification.

Follow:

- `rules/CLASSIFICATIONS.md`

Classification usage:

`Optional`

If used, output should include:

`Setup Classification: [classification]`

Optional:

`Setup Modifiers: [modifier 1], [modifier 2]`

Command-specific classification notes:

- Do not classify by default when the output is purely factual business-model research.
- Use classification only when the response includes a setup view or final research view.
- Keep classification clearly secondary to the filing-backed business-model evidence.

If classification is not used, omit the classification section unless the user asked why no classification was shown.

---

### 5. Scoring Behavior

Use this section only if the command applies MIDAS scoring.

Follow:

- `rules/SCORING.md`

Scoring usage:

`Optional`

If used, output may include:

`Global Research Score: [score]/100`

Evidence confidence:

`Evidence Confidence: [A / B / C / D]`

Command-specific scoring notes:

- Do not score by default.
- Use scoring only if the user asks for a score or if the output explicitly includes setup evaluation.
- If full scoring is needed, suggest `!full`.

If scoring is not used, omit the scoring section unless the user asked for score behavior.

---

### 6. Metrics Behavior

Use this section only if the command displays, calculates, compares, or interprets financial metrics.

Follow:

- `rules/METRICS.md`
- `rules/ARTIFACTS.md`

Metrics usage:

`Optional`

Required metrics:

`None by default`

Optional metrics:

- Revenue trend.
- Segment or revenue category mix.
- Customer concentration if disclosed.
- Geography mix if disclosed.
- Backlog, RPO, deferred revenue, retention, order trends, or similar business-visibility metrics if disclosed.

Metric constraints:

- Include period and source context.
- Preserve GAAP/non-GAAP labels when relevant.
- Use metrics only to support the business-model discussion.
- Do not provide full margin, balance-sheet, cash-flow, valuation, or shareholder-return analysis; redirect to `!financials`.

If metrics are not used, omit the metrics section.

---

### 7. Risks / Caveats

Use this section because `!research` can influence investment judgment.

Required risk behavior:

- Include key filing-backed business risks or red flags.
- Surface evidence limitations.
- State what could disconfirm the business-model view.
- Do not bury customer concentration, pricing pressure, cyclicality, regulation, supplier dependence, or demand fragility when disclosed.

---

### 8. Best Next Command

When useful, end with the next most logical MIDAS command before the saved-path confirmation.

Format:

`Best next command: ![command] [reason]`

Examples:

- `Best next command: !financials to verify margins, cash conversion, balance sheet, and valuation context.`
- `Best next command: !thesis to turn the business-model view into bull/base/bear cases.`
- `Best next command: !risk to pressure-test the key business-model risks.`
- `Best next command: !full for a complete research packet with scoring and classification.`

Do not recommend a next command when it would be noisy or unnecessary.

The final line after Standard or Full artifact saving must be:

`Saved to: workspace/tickers/[ticker]/research.md`

If compact output is explicitly saved, the final line must be:

`Saved to: workspace/tickers/[ticker]/research.compact.md`

If compact output is not saved, omit the saved-path confirmation. If the user asks about saving, use `No artifact saved for compact mode.`

---

## Compact Output Contract

Use compact mode when the user wants speed, navigation, triage, or a short answer.

Compact mode is not the default. Do not use this compact contract for a plain `!research [ticker]` request unless the user asks for compact/quick/brief output.

Compact output should include:

1. Optional short identity line: `[TICKER] | [Company Name] Compact Business Snapshot`
2. `Bottom Line`
3. `Business Model Snapshot`
4. `Key Evidence / Limits`
5. `Best Next Command`, if useful

Compact output does not require the full Standard/Full report title or `## Introduction`. Compact mode may start with `Bottom Line`.

Compact output should not include:

- Full Standard section list.
- Full scoring detail.
- Long source discussion.
- Full metric tables.
- Expanded thesis/risk sections.
- Large artifact summaries.
- Saved-path confirmation unless the user explicitly asked to save compact output.

Compact artifact behavior:

- Compact mode should not save an artifact by default.
- Compact mode must not overwrite `workspace/tickers/[ticker]/research.md`.
- If the user explicitly asks to save compact output, save to `workspace/tickers/[ticker]/research.compact.md`.
- If compact output is explicitly saved, confirm with `Saved to: workspace/tickers/[ticker]/research.compact.md`.
- If compact output is not saved, omit the saved-path confirmation. If the user asks about saving, state `No artifact saved for compact mode.`

### Compact Format

`[Optional: TICKER | Company Name Compact Business Snapshot]`

`Bottom Line: [short business-model conclusion]`

`Business Model Snapshot: [what it does, how it makes money, customers/end markets, recurrence/cyclicality in compact form]`

`Key Evidence / Limits: [primary sources used and the most important limitation]`

`Best next command: [optional]`

`[Only if explicitly saved: Saved to: workspace/tickers/[ticker]/research.compact.md]`

---

## Standard Output Contract

Use standard mode as the default for `!research`.

Standard mode is mandatory for a plain `!research [ticker]` request. It must include the required sections below and must keep the evidence trail visible. Do not replace Standard mode with a compact-style response unless the user explicitly requested compact/quick/brief output.

Standard output should include, in this order:

1. Report title
2. Introduction
3. Bottom Line
4. Filings / Sources Used
5. Plain-English Summary
6. What the Company Does
7. How the Company Makes Money
8. Segment / Revenue Breakdown
9. Customers and End Markets
10. Geography
11. Purchase Frequency / Recurrence / Contract Structure
12. Pricing Power
13. Recession and Cyclicality
14. Recent Business Performance Snapshot
15. Key Business Risks / Red Flags
16. Bottom-Line Business Model View
17. Source Notes
18. Best Next Command, when useful
19. Saved-path confirmation

### Standard Format

#### Report Title

`# [TICKER] | [Company Name] Business Analysis`

Example:

`# HOOD | Robinhood Markets, Inc. Business Analysis`

#### Introduction

`[2-4 sentence explanation of what the report analyzes, source base used, scope of !research, and that it is business-model research rather than full financial analysis, valuation, or buy/sell advice]`

#### Bottom Line

`[1-3 sentence business-model conclusion]`

#### Filings / Sources Used

`[Primary filings and official sources used, with dates, periods, accession numbers or URLs where available]`

This section is required in Standard mode. For SEC filers, include the latest 10-K and latest 10-Q when available, with filing date, report period, accession number or URL. If a primary filing is unavailable, state the source limitation.

#### Plain-English Summary

`[Concise description of the business, products/services, customers, and monetization]`

#### What the Company Does

`[Products/services, platform/assets/operations, value-chain position, disclosed differentiators]`

#### How the Company Makes Money

`[Revenue streams, monetization mechanics, revenue recognition when relevant]`

#### Segment / Revenue Breakdown

`[Segments, revenue categories, contribution, growth/decline, and undisclosed items]`

#### Customers and End Markets

`[Customer types, concentration, industries/verticals, channel, contract structure if disclosed]`

#### Geography

`[Revenue by geography, operating regions, international exposure, region-specific risks or growth drivers]`

#### Purchase Frequency / Recurrence / Contract Structure

`[Recurring/repeat/transactional/project/cyclical nature, contract length, renewals, backlog/RPO/deferred revenue/retention if disclosed]`

#### Pricing Power

`[Evidence for or against pricing power; conclusion should be strong, moderate, weak, mixed, or not enough information]`

#### Recession and Cyclicality

`[Economic sensitivity, seasonality, discretionary/nondiscretionary demand, risk-factor support]`

#### Recent Business Performance Snapshot

`[Latest annual and quarterly business trends; not a full financial analysis]`

#### Key Business Risks / Red Flags

`[Most important filing-backed business risks and evidence limitations]`

#### Bottom-Line Business Model View

`[What the business really is, what must go right, what could break the thesis, and key model traits]`

#### Source Notes

`[Citation approach, source freshness, missing disclosures, source limitations]`

This section is required in Standard mode. It should state the evidence base, freshness/as-of limitation, citation approach, and material facts that were `not disclosed in the reviewed filings` when applicable.

#### Best Next Command

`[Optional next command]`

`Saved to: workspace/tickers/[ticker]/research.md`

---

## Full Output Contract

Use full mode when the user asks for a deep dive, complete artifact, full business-model view, or detailed audit trail.

Full output may include:

1. Report title
2. Introduction
3. Bottom Line
4. Filings / Sources Used
5. Expanded business-model research sections from standard mode
6. Expanded evidence base
7. Optional Setup Classification and modifiers if the output includes setup view
8. Optional scoring only if requested or clearly setup-evaluative
9. Relevant business-performance metrics
10. Risks and disconfirming evidence
11. Open questions
12. Best next command
13. Saved-path confirmation
14. Separate Artifact section only if there is extra artifact context beyond a normal save confirmation.

### Full Format

Use the standard section list with expanded detail. Full mode must also begin the visible report body with `# [TICKER] | [Company Name] Business Analysis` and `## Introduction` before `Bottom Line`. Add these sections when useful:

#### Evidence Base

`[Primary sources, secondary context if used, freshness, conflicts, missing evidence]`

#### Setup Classification

`[Classification and modifiers, if used]`

#### Scoring

`[Global score, evidence confidence, score caps/gates, if used]`

#### Metrics

`[Relevant business-performance metrics, periods, source notes, if used]`

#### Risks and Disconfirming Evidence

`[Key risks, what would break the business-model view, what needs verification]`

#### Open Questions

`[Unresolved research items]`

#### Best Next Command

`[Optional next command]`

`Saved to: workspace/tickers/[ticker]/research.md`

---

## Artifact Behavior

Artifact output must follow:

`/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

Writes artifacts:

`Yes`

Default artifact behavior:

Standard and Full mode write the canonical Markdown research artifact automatically after the final answer is complete and verified.

Compact mode should not save an artifact by default and must not overwrite the canonical Standard/Full artifact at `workspace/tickers/[ticker]/research.md`. If the user explicitly asks to save compact output, write it to `workspace/tickers/[ticker]/research.compact.md` instead.

Saved Standard and Full artifacts must include the required report title and `Introduction` section. If `rules/ARTIFACTS.md` requires a metadata header, preserve that header; the visible report body immediately after the metadata header must begin with `# [TICKER] | [Company Name] Business Analysis`, followed by `## Introduction`, then `## Bottom Line`.

Standard / Full artifact location:

`/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/research.md`

Standard / Full user-facing relative path:

`workspace/tickers/[ticker]/research.md`

Explicitly saved compact artifact location:

`/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/research.compact.md`

Explicitly saved compact user-facing relative path:

`workspace/tickers/[ticker]/research.compact.md`

Artifact types:

`Markdown research note`

When a Standard or Full artifact is written, output should include the saved-path confirmation as the final line:

`Saved to: workspace/tickers/[ticker]/research.md`

Standard and Full mode must not include a separate Artifact section by default. The final `Saved to:` line is the uniform artifact confirmation.

Only include a separate Artifact section if there is extra artifact context beyond a normal save confirmation, such as:

- Multiple artifacts were created.
- A versioned artifact was preserved.
- The artifact path changed.
- A save failed.
- The user explicitly asked for artifact details.

Otherwise, end with exactly one saved-path confirmation line and no separate Artifact section.

When compact output is explicitly saved, output should include the saved-path confirmation as the final line:

`Saved to: workspace/tickers/[ticker]/research.compact.md`

When compact output is not saved, omit saved-path confirmation. If the user asks about saving, state `No artifact saved for compact mode.`

Do not claim an artifact was written unless it was actually created.

Legacy path handling follows `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`.

---

## Failure Output Contract

Use failure output when the command cannot complete its intended task.

Common failure cases:

- Missing ticker/company/input.
- Ambiguous company identity.
- Insufficient primary-source evidence.
- Conflicting evidence.
- Data too stale.
- Filing access failure after reasonable retry.
- Artifact write failure.

Failure output should include:

1. What failed.
2. Why it failed.
3. What evidence or input is missing.
4. Best next step.

### Failure Format

`Unable to complete: [specific failure]`

`Reason: [clear explanation]`

`Missing or needed: [input/evidence/data]`

`Best next step: [command or user action]`

Do not fabricate results to avoid a failure state.

Do not claim a saved artifact if no artifact was written.

---

## Command-Specific Required Sections

The following sections are required for standard `!research` output:

- Bottom Line
- Filings / Sources Used
- Plain-English Summary
- What the Company Does
- How the Company Makes Money
- Segment / Revenue Breakdown
- Customers and End Markets
- Geography
- Purchase Frequency / Recurrence / Contract Structure
- Pricing Power
- Recession and Cyclicality
- Recent Business Performance Snapshot
- Key Business Risks / Red Flags
- Bottom-Line Business Model View
- Source Notes
- Best Next Command
- Saved-path confirmation

The following sections are optional:

- Setup Classification
- Setup Modifiers
- Evidence Confidence
- Artifact section, only when extra artifact context is needed
- Open Questions
- Metrics

The following sections are prohibited by default:

- Buy/Hold/Sell recommendation
- Price target
- Full valuation model
- Full financial statement analysis
- Hidden-gem ranking
- Tracker/copy-trading framing

Standard source-visibility requirements:

- Include `Filings / Sources Used`.
- Include `Source Notes`.
- Include filing dates / report periods / accession numbers or URLs where available.
- Cite or source-reference material factual claims.
- Explicitly state `not disclosed in the reviewed filings` when a required business-model fact is missing.
- Do not allow Standard mode to collapse into a compact-only summary.
- Do not include citation-free material factual claims.

---

## Command-Specific Table Standards

Use tables only when they improve scanability.

Required tables:

`None`

Optional tables:

- Filings / Sources Used.
- Segment or revenue category breakdown.
- Geographic revenue breakdown.
- Customer concentration or end-market table.
- Business-performance snapshot.

Table rules:

- Keep tables compact.
- Do not include decorative columns.
- Do not show unavailable metrics as if known.
- Use `Not disclosed` when the reviewed filings do not disclose a relevant fact.
- Include period/date context when metrics are shown.

---

## Command-Specific Language Standards

Preferred language:

- Filing-backed.
- Plain English.
- Fact vs interpretation clearly separated.
- Use `not disclosed in the reviewed filings` when appropriate.
- Use measured conclusions such as `strong`, `moderate`, `weak`, `mixed`, or `not enough information` for pricing power only when supported.

Avoid:

- `Buy`, `Hold`, `Sell`, `Strong Buy`, or equivalent recommendation language.
- `I'd classify it as` or equivalent classification phrasing unless the output explicitly includes `Setup Classification: [approved classification]` using an approved classification from `rules/CLASSIFICATIONS.md`.
- `Guaranteed`, `no-brainer`, `must-own`, or promotional phrasing.
- `Moat`, `pricing power`, `recurring`, `mission-critical`, or `recession-proof` unless supported by the reviewed sources.
- Full valuation or price-target language.

When refusing buy/sell/price-target requests, `!research` may provide research framing. Use `Business-model characterization: ...` for non-classification framing. Use `I'd classify it as` only when the output explicitly includes `Setup Classification: [approved classification]`.

Required disclaimers or caveats:

- If primary filings are missing or stale, label the source limitation.
- If a relevant fact is not disclosed, state that it is not disclosed rather than guessing.

---

## Examples Needed

Each command-specific output contract should eventually include or reference examples for:

- Normal success case.
- Weak or incomplete evidence case.
- Failure case.
- Artifact-writing case.

Example coverage lives in the command eval file.

Eval file:

`evals/research.eval.md`

The eval file should test that this output contract is followed.

---

## Placeholder Cleanup Rule

Before this output contract is marked Active, all template placeholders should be replaced or removed.

This Draft output file has no unresolved template placeholders intended for runtime output.

An Active output file should not contain unresolved template placeholders.

---

## Stability Checklist

Before marking this output contract Active, confirm:

- [x] It references global output rules instead of duplicating them
- [x] It defines compact, standard, and full output behavior
- [x] It clearly states whether classification is used
- [x] It clearly states whether scoring is used
- [x] It clearly states whether metrics are used
- [x] It clearly states whether artifacts are written
- [x] It defines failure behavior
- [x] It avoids command workflow instructions that belong in `SKILL.md`
- [x] It avoids source hierarchy rules that belong in `rules/SOURCES.md`
- [x] It avoids scoring rubric details that belong in `rules/SCORING.md`
- [x] It avoids metric formulas that belong in `rules/METRICS.md`
- [x] Skill and output paths are command-specific, not generic `skills/[command]/...` placeholders
- [x] Registry metadata matches `docs/COMMAND_REGISTRY.md`
- [x] Unsupported output mode behavior is defined
- [x] Empty sections are omitted unless explicitly required
- [x] Artifact paths use command-specific workspace paths, not generic placeholders
- [x] All template placeholders have been replaced or removed before marking Active
- [x] This file defines output shape only and does not duplicate command workflow logic
- [x] It is concise enough to serve as an interface contract
