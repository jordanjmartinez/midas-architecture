---
name: research
description: Filing-backed business-model research for a public company or ticker. Use for !research [ticker/company], /research [ticker/company], or natural-language company research requests.
version: 2.0.0
author: Midas / Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [stocks, equity-research, sec-filings, business-model, company-research]
    related_skills: [financials, thesis, risk, full]
---

# MIDAS Command Skill — !research

## Command

`!research`

## Registry Metadata

Command: `!research`
Aliases: `/research`, `research`
Category: `Company Research`
Status: `Active`
Skill Path: `skills/stock-analysis/research/SKILL.md`
Output Path: `skills/stock-analysis/research/OUTPUT.md`
Eval File: `evals/research.eval.md`
Uses Classification: `Optional`
Uses Scoring: `Optional`
Uses Metrics: `Optional`
Writes Artifacts: `Yes`
Primary Global Rules: `GLOBAL.md, COMMAND_INTERFACE.md, SOURCES.md, CLASSIFICATIONS.md, SCORING.md, METRICS.md, OUTPUT.md, ARTIFACTS.md`

## Purpose

`!research` produces a filing-backed business-model research note for a public company or ticker. It helps the user understand what the company does, how it makes money, what the filings disclose about customers, segments, geography, recurrence, pricing power, cyclicality, recent business trends, and business-model risks before deciding which deeper diligence command to run next.

---

## When To Use

Use this command when:

- The user asks `!research [ticker/company]`, `/research [ticker/company]`, or naturally asks to research a company or ticker.
- The user needs a plain-English, filing-backed business-model view.
- The user wants to understand revenue mechanics, customers, end markets, geography, recurrence, pricing power, cyclicality, and key filing-backed business risks.

Do not use this command when:

- The user primarily wants financial statement analysis. Use `!financials` instead.
- The user wants bull/base/bear cases. Use `!thesis` instead.
- The user wants downside pressure-testing. Use `!risk` instead.
- The user wants a complete research packet with valuation, scoring, and classification. Use `!full` instead.
- The user wants hidden-gem ranking or screening. Use `!gems` instead.

---

## Inputs

### Required Inputs

- Company name or ticker.

### Optional Inputs

- Output depth: compact, standard, or full.
- Source preference if the user provides a specific filing, report, transcript, or company document.
- Artifact behavior only if the user explicitly asks to preserve versions or skip saving.
- Specific business-model focus such as customer concentration, geography, recurrence, pricing power, or cyclicality.

### Input Clarification Rules

Ask for clarification only when ambiguity would materially change the company being researched.

If a ticker/company match is clear enough to proceed, state the identity assumption and proceed.

If multiple companies plausibly match the same ticker/name and the likely match is not clear, ask the user to clarify before analysis.

If a requested ticker cannot be verified and a clarification prompt has already been sent, do not proceed with a likely typo candidate or imply the user confirmed a substitute unless an explicit user response confirms it. Any tentative research gathered for a likely candidate must remain clearly labeled as tentative and must not be saved or presented as the requested ticker’s final report.

---

## Aliases

Supported aliases:

- `/research`
- `research`
- Natural-language company research requests.

---

## Global Rules

This command must follow:

- `/home/jordan/.hermes/profiles/midas/rules/GLOBAL.md`
- `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md`
- `/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`
- `/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`
- `/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

Use when applicable:

- `/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md`
- `/home/jordan/.hermes/profiles/midas/rules/SCORING.md`
- `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`

Do not duplicate global rule content inside this command. Reference global rules instead.

---

## Workflow

Reference: `references/sec-filing-excerpt-workflow.md` covers the SEC filing manifest + excerpt-preservation workflow for filing-backed `!research` tasks. Use it when retrieval/parsing is done through temporary filing corpora or large scripts.

Reference: `references/sec-html-business-extraction.md` covers targeted SEC HTML/XBRL extraction for full business-model research when no line-stable filing corpus exists, including section-based citations, tool-calculated business metrics, and artifact-verification pitfalls.

Reference: `references/ambiguous-ticker-clarification.md` covers the recovery pattern for invalid/unresolved tickers, likely typos, and tentative candidate research. Use it before saving or presenting output when ticker identity was unresolved.

Reference: `references/large-filing-line-citation-recovery.md` covers the recovery pattern for Standard/Full `!research` runs when generated excerpt files are too sparse but local SEC filing text is available; use targeted searches, line-range reads, tool-calculated table percentages, and original filing line citations.

Reference: `references/artifact-overwrite-safety.md` covers safe handling of canonical `research.md` writes when a tool warns about sibling/user modification or another overwrite risk.

Follow this command-specific workflow:

1. Parse the request and identify the target company or ticker.
2. Resolve company identity before analysis: legal name, ticker, exchange if available, SEC CIK if applicable, and whether it is an SEC filer.
3. Decide whether the input is clear enough to proceed; clarify only if ambiguity changes the target company.
4. Gather primary evidence under `rules/SOURCES.md`.
5. For SEC filers, identify the most recent 10-K and most recent 10-Q when available; record form type, filing date, report period, accession number, and URL.
6. For non-SEC filers, identify the closest primary-source equivalents such as annual reports, interim reports, exchange filings, regulator filings, or official company disclosures.
7. Extract evidence relevant to business model, segment/revenue categories, customers, end markets, geography, revenue recognition, recurrence, contracts, backlog/RPO, pricing pressure or pricing power, cyclicality, seasonality, recent business trends, and business risks.
8. Separate filing-backed facts from interpretation.
9. Explicitly state when important facts are not disclosed in the reviewed sources.
10. Use only lightweight business-performance metrics when they support the business-model discussion; do not turn the output into `!financials`.
11. When deriving business-model percentages from filing tables (for example segment revenue mix, recognition mix, backlog mix, or year-over-year segment growth), calculate them with a tool, not mental math; label them as calculated from filing values and keep them clearly secondary to the business-model explanation.
12. Apply Setup Classification only when the response includes a setup view or final research view; do not force classification into a factual business-model explanation.
12. Apply scoring only if the user asks for a score or the output explicitly includes setup evaluation; suggest `!full` if full scoring is needed.
13. Produce the response using `skills/stock-analysis/research/OUTPUT.md` plus global output rules.
14. Save the final clean Markdown artifact after the final output is complete and verified.
15. If a prior `!research` run was interrupted and the user issues a new command, do not silently resume the old ticker or imply completion. Briefly state what, if anything, was completed for the interrupted run, then execute the new command. Do not save an artifact for the interrupted ticker unless its final output was actually completed and verified.
16. Before overwriting `workspace/tickers/[ticker]/research.md`, read or otherwise inspect the existing file when the tool reports potential sibling/user modification, unusual customization, or other overwrite risk. Preserve the command’s default replace behavior for normal generated artifacts, but avoid blindly overwriting a file that may contain newer user/sibling work.
17. End the response with the required saved-path confirmation.

Keep this command focused on business-model research.

---

## Command-Specific Source Needs

Default source standards come from:

`/home/jordan/.hermes/profiles/midas/rules/SOURCES.md`

Command-specific source needs:

- For SEC filers, prefer the latest Form 10-K and latest Form 10-Q.
- Use 8-Ks, S-1s, 20-Fs, 40-Fs, proxies, exhibits, investor presentations, earnings releases, or transcripts only when useful for current business context or when 10-K/10-Q coverage is insufficient.
- For non-SEC filers, use annual reports, interim reports, exchange filings, regulator filings, and official company disclosures.
- Use secondary sources only for context, not as the primary basis for business-model claims.
- Every material factual claim should be citation-backed.
- If line citations are available, use them.
- If line citations are unavailable, cite filing name, filing date, section, accession number or URL when available.

SEC access implementation note:

- Use a compliant descriptive SEC User-Agent when retrieving SEC data.
- If a SEC request fails due to headers or response format, retry with a compliant client/header pattern before treating the filing as unavailable.
- Do not expose personal contact details in skill output or stored artifacts.

---

## Classification / Scoring / Metrics Behavior

### Setup Classification

Use Setup Classification:

- Optional

Rule:

```md
Use `/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md`.
```

Command-specific classification notes:

- Use classification only when the response produces a setup view or final research view.
- Do not classify a purely factual business-model explanation.
- If classification is used, keep it secondary to the business-model evidence and clearly qualify confidence.

### Scoring

Use scoring:

- Optional

Rule:

```md
Use `/home/jordan/.hermes/profiles/midas/rules/SCORING.md`.
```

Command-specific scoring notes:

- Do not score by default.
- Use scoring only if the user asks for a score or if the output explicitly includes setup evaluation.
- If the user wants full scoring, suggest `!full`.

### Metrics

Use financial metrics:

- Optional

Rule:

```md
Use `/home/jordan/.hermes/profiles/midas/rules/METRICS.md`.
```

Command-specific metric notes:

- Use lightweight business-performance metrics only when they support the business-model discussion.
- Examples include revenue trend, segment revenue, revenue category mix, backlog/RPO, customer concentration, geography, retention, or other disclosed operating metrics.
- Do not produce a full margin, cash-flow, balance-sheet, valuation, or shareholder-return review; redirect to `!financials` for that.

---

## Output Contract

Follow the shared output standards:

`/home/jordan/.hermes/profiles/midas/rules/OUTPUT.md`

Follow the command-specific output contract:

`/home/jordan/.hermes/profiles/midas/skills/stock-analysis/research/OUTPUT.md`

### Required Sections

For Standard and Full mode, required sections begin with:

- Report title, formatted as `# [TICKER] | [Company Name] Business Analysis`
- Introduction
- Bottom Line
- Filings / Sources Used
- Plain-English Summary
- What the Company Does
- How the Company Makes Money
- Segment / Revenue Breakdown
- Customers and End Markets
- Geography
- Purchase Frequency / Recurrence / Contract Structure
- Pricing Power
- Recession and Cyclicality
- Recent Business Performance Snapshot
- Key Business Risks / Red Flags
- Bottom-Line Business Model View
- Source Notes
- Best Next Command

### Optional Sections

- Setup Classification
- Setup Modifiers
- Evidence Confidence
- Artifact section only when there is extra artifact context beyond a normal save confirmation, such as multiple files, versioning, path changes, save failure, or an explicit user request for artifact details.

### Output Modes

- Inherits shared mode behavior from `/home/jordan/.hermes/profiles/midas/rules/COMMAND_INTERFACE.md`.
- Supported modes: Compact, Standard, Full.
- Default mode: Standard.
- Command-specific exceptions: None.

---

## Artifact Behavior

This command writes artifacts:

- Yes

Follow the global artifact standards:

`/home/jordan/.hermes/profiles/midas/rules/ARTIFACTS.md`

### Creates / Updates

Standard and Full mode:

- `/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/research.md`

Compact mode:

- Does not save by default.
- If the user explicitly asks to save compact output, save to `/home/jordan/.hermes/profiles/midas/workspace/tickers/[ticker]/research.compact.md`.

### Replace Behavior

- Standard and Full mode may overwrite the prior `research.md` for the same normalized lowercase ticker unless the user explicitly asks to preserve versions.
- Compact mode must not overwrite `workspace/tickers/[ticker]/research.md`.
- Explicitly saved compact output may overwrite `research.compact.md` for the same normalized lowercase ticker unless the user explicitly asks to preserve versions.

### Command-Specific Rules

- Normalize ticker by removing a leading `$` and lowercasing the folder name.
- If the ticker folder does not exist, create it only when saving an artifact.
- Save only the clean final Markdown output after analysis is complete and verified.
- Use the required artifact header from `rules/ARTIFACTS.md`, with Analysis Type set to `Business Analysis`.
- Saved Standard and Full artifacts must include the required report title and `Introduction` section; if a metadata header is present, the visible report body immediately after the header must begin with `# [TICKER] | [Company Name] Business Analysis`, then `## Introduction`, then `## Bottom Line`.
- Artifact header pitfall: do not add an extra ad-hoc H1 such as `# Company (TICKER) — Business Analysis` before the canonical visible report title. Use the required `ARTIFACTS.md` metadata/header pattern if needed, then begin the visible body directly with the canonical `# [TICKER] | [Company Name] Business Analysis` title.
- Compact mode should omit saved-path confirmation unless the user explicitly asked to save compact output. If the user asks about saving, state `No artifact saved for compact mode.`
- Mode/artifact pitfall: never let a short compact snapshot replace the durable Standard/Full artifact. Treat `research.md` as the canonical business-analysis artifact for Standard/Full only; compact is chat-only by default and uses `research.compact.md` only on explicit save request.
- Standard and Full user-facing responses must not include a separate Artifact section by default. End with exactly one saved-path confirmation line:

```md
Saved to: workspace/tickers/[ticker]/research.md
```

- Only include a separate Artifact section if there is extra artifact context beyond a normal save confirmation, such as multiple artifacts created, a versioned artifact preserved, the artifact path changed, a save failed, or the user explicitly asked for artifact details. Otherwise use only the final saved-path confirmation line.

- Explicitly saved compact output must end with:

```md
Saved to: workspace/tickers/[ticker]/research.compact.md
```

---

## Failure Behavior

If information is missing, weak, stale, unavailable, or ambiguous:

- Say what is missing.
- State the limitation clearly.
- Do not invent facts.
- Do not invent numbers.
- Do not force a conclusion about moat, pricing power, recurrence, customer concentration, cyclicality, or geography.
- Provide the best partial result when possible.
- Suggest the best next diligence step when useful.

Useful phrases:

```md
Could not verify:
```

```md
Missing information:
```

```md
Source limitation:
```

```md
Partial result:
```

```md
Best next step:
```

---

## Guardrails

This command must not:

- Use Buy/Hold/Sell recommendation language.
- Treat tracked ownership or disclosures as copy-trading signals.
- Treat social media as thesis proof.
- Present unverified claims as facts.
- Hide material risks.
- Invent metrics or unsupported precision.
- Ignore stale data.
- Ignore source limitations.
- Overwrite important files outside its artifact contract.
- Duplicate global rules inside this skill.

Command-specific guardrails:

- Do not present a full valuation model or price target.
- When refusing buy/sell/price-target requests, provide research framing only. Do not use `I'd classify it as` or similar classification phrasing unless using an approved Setup Classification from `/home/jordan/.hermes/profiles/midas/rules/CLASSIFICATIONS.md` and explicitly outputting `Setup Classification: [approved classification]`.
- For non-classification framing, use `Business-model characterization: ...` instead of `I'd classify it as: ...`.
- Do not perform a full financial statement analysis; redirect to `!financials`.
- Do not build bull/base/bear cases unless the user explicitly asks and the scope is redirected to `!thesis`.
- Do not turn the company into a hidden-gem ranking or screen.
- Do not call revenue recurring unless reviewed filings support that conclusion.
- Do not assert pricing power, cyclicality, moat, customer concentration, segment mix, geography, or contract structure unless source-backed.

---

## Eval Cases Needed

Eval file:

```bash
/home/jordan/.hermes/profiles/midas/evals/research.eval.md
```

Required eval coverage:

1. Normal successful `!research TICKER` case.
2. Weak or missing evidence case.
3. Guardrail / clean failure case.
4. Registry metadata / registry drift case.
5. Source discipline case.
6. Negative capability case proving `!research` does not become `!financials`, `!thesis`, or `!full`.
7. Artifact behavior case.
8. Prompt-injection / external-content safety case for filings, PDFs, HTML, documents, or transcripts.

---

## Active Readiness / Monitoring Checklist

Active readiness is satisfied when:

- Purpose is clear.
- Trigger syntax is clear.
- Required inputs are clear.
- Workflow is command-specific.
- Global rules are referenced, not duplicated.
- Output contract is defined.
- Artifact behavior is defined.
- Failure behavior is defined.
- Guardrails are included.
- Evals exist or are planned.
- Command registry metadata is filled in.
- `docs/COMMAND_REGISTRY.md` is updated when the command is created, renamed, deprecated, or materially changed.
- Standard mode passes.
- Compact mode passes without overwriting `research.md`.
- Full mode passes.
- Artifact behavior is verified.
- Filing-backed source discipline passes on more than one normal ticker.
- The command does not conflict with `!financials`, `!thesis`, `!risk`, `!full`, or `!gems`.

Carried-forward monitoring items do not block Active status when normal tested tickers pass:

- Runtime-heavy tickers with slow filing retrieval or unusually large filings.
- Weak/missing-evidence fixtures.
- Clean-failure fixtures.
- Prompt-injection fixtures.
- Future unsupported-inference regressions.
- Buy/price-target guardrail spot checks.

## Final Rule

`!research` is a filing-backed business-model research command.

It should make the company understandable before deeper financial analysis, thesis construction, risk pressure-testing, or full scoring.

It should not become a second global rulebook or a full report command.
